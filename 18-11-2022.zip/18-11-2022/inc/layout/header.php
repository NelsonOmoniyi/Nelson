<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <link rel="shortcut icon" type="image/x-icon" href="home/img/icons/logo.png" />

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="assets/css/classic.css"> -->

    <link rel="stylesheet" href="assets/css/waves.min.css" media="all">

    <link rel="stylesheet" href="assets/icon/feather/css/feather.css">

    <link rel="stylesheet" href="assets/css/font-awesome-n.min.css">

    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/widget.css">
    <link rel="stylesheet" href="assets/css/qs.css">
    <!-- <link rel="stylesheet" href="assets/datepicker/datepicker.min.css" /> -->

    <style>
        @font-face {
            font-family: 'quicksand';
            src: url('assets/icon/quicksand/Quicksand-Regular.woff');
        }

        * {
            font-family: 'quicksand';
        }
    </style>