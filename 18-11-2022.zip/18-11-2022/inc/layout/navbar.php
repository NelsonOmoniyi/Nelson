<header class="main-header">
  <div class="top-bar theme-bg" style="background-color: #5FC27E;">
    <div class="container">
      <div class="row">
        <div class="col-xs-12">
          <div class="d-flex justify-end">
            <div class="left mr-auto">
              <ul class="clearfix">
                <li>
                  Phone:
                  <a href="tel:+2348033450329">+2348033450329</a>
                </li>
                <li>
                  Email:
                  <a href="mailto: rccenquiries@drts.gov.ng">rccenquiries@drts.gov.ng</a>
                </li>
              </ul>
            </div>
            <div class="right l-height">
              <ul class="clearfix d-inblock">
                <li><a href="login.php">Login</a></li>
                <li><a href="pay.php">Make Payment</a></li>
                <li><a href="confirm_bank.php">&nbsp;&nbsp;|&nbsp;&nbsp;Confirm Bank Payment</a></li>
                <li><a href="ref_payment.php">&nbsp;&nbsp;|&nbsp;&nbsp; Referral Note Payment</a></li>
                <li><a href="applicant_reschedule_training.php">&nbsp;&nbsp;|&nbsp;&nbsp;Reschedule Training</a></li>

              </ul>
            </div>
          </div>
        </div>
      </div>
      <!-- /.row -->

      <!-- Modal -->
      <div class="modal fade" id="register-owner" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" style="color: black;">Driver Registration</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form method="POST" action="#" name="form1" id="form1">
                <input type="hidden" name="operation" id="operation">
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="firstname">Firstname</label><input type="text" required name="firstname" id="firstname" value="" class="form-control" />
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="lastname">Lastname</label><input type="text" required name="lastname" id="lastname" value="" class="form-control" />
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="email">Email</label><input type="email" required name="email" id="email" value="" class="form-control" />
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="mobile_phone">Phone</label><input type="text" required name="mobile_phone" id="mobile_phone" value="" class="form-control" />
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="username">Username</label><input type="text" required name="username" id="username" value="" class="form-control" />
                        <span id="user-err" style="color: red !important; font-weight: bold;display:none"></span>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="password">Password</label><input type="password" data-parsley-minlength="6" name="password" required id="password" value="" class="form-control" />
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="npswd">Confirm password</label><input type="password" data-parsley-minlength="6" data-parsley-equalto="#password" name="npswd" required id="npswd" value="" class="form-control" />
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-primary">Save</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /.container -->
  </div>
  <div id="active-sticky" class="navgation-bar">
    <div class="container">
      <div class="row">
        <div class="col-xs-12">
          <div class="d-flex justify-end">
            <div class="logo mr-auto">
              <a href="index.php"><img src="home/img/icons/logo.png" style="height: 5em" alt="PTMS" style="width:80px;height:80px; padding-bottom:5px" /></a>
            </div>
            <!-- Static navbar -->
            <nav class="mainmenu">
              <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar">
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                </button>
              </div>
              <div id="navbar" class="navbar-collapse collapse no-padding">
                <ul class="navbar-nav dropdown">
                  <li>
                    <a href="index.php">Home</a>
                  </li>
                  <li>
                    <a href="about.php">About</a>
                  </li>
                  <li>
                    <a href="contact_us.php">Contact</a>
                  </li>
                  <li>
                    <!-- <a href="#">Contact Us</a> -->
                  </li>
<!--
                  <li>
                    <a href="javascript:viod(0)" class="dropdown-toggle" data-toggle="dropdown" title="Click Here">
                      Login <i class="zmdi zmdi-chevron-down"></i>
                    </a>
                    <ul class="dropdown-menu">
                      <li><a href="login.php">Owner's Corner</a></li>
                      <li><a href="admin_login.php">Admin Login</a></li>
                    </ul>
                  </li>
-->
                </ul>
              </div>
              <!--/.nav-collapse -->
            </nav>
          </div>
        </div>
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container -->
  </div>
</header>