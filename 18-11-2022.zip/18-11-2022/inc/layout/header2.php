<!DOCTYPE html>
<html lang="en">
<?php
include_once "lib/dbfunctions_new.php";
$dbobject = new dbobject; 
$payment_options = $dbobject->getPaymentCategory();

?>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="author" content="" />
  <title>FCT PTMS</title>
  <!-- favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="home/img/icons/logo.png" />
  <!-- style css -->

  <link rel="stylesheet" href="assets/css/font-awesome-n.min.css" />


</head>
<link rel="stylesheet" href="assets/css/classic.css">
<?php include_once 'inc/layout/scripts.php' ?>
<div class="container">
<br>
<p class="text-center h4">
    <a href="index.php"><img src="assets/img/fct.png" width="50px" height="50px"></a>
    <a href="index.php" class="font-weight-bold text-success">FCT Public Transport Management System</a>
    <a href="index.php"><img src="home/img/icons/logo.png" width="50px" height="50px"></a>
</p>
<hr>