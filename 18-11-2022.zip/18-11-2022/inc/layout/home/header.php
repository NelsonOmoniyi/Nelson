<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="author" content="" />
  <title>Home | PTMS</title>
  <!-- favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="img/nis-logo-2.png" />
  <!-- style css -->
  <link rel="stylesheet" href="home\style.css" />

  <link rel="stylesheet" href="assets/css/font-awesome-n.min.css" />

  <!-- modernizr js -->
  <script src="home/js/vendor/modernizr-2.8.3.min.js"></script>
  <link rel="stylesheet" href="assets/css/qs.css">

  <style>
    #navbar a {
      color: #5fc27e !important;
    }
  </style>
</head>