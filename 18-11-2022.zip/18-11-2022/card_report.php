<?php
session_start();
include_once "lib/dbfunctions_new.php";
$dbobject = new dbobject();
$user = $_SESSION['pts_role_id_sess'];

// New menu
$op = isset($_REQUEST['op']) ? $_REQUEST['op'] : 'new';

?>

<style>
    .bold {
        font-weight: 800;
    }

    .details {
        font-family: 'Segoe UI';
        font-weight: 700;
    }
</style>

<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="fas fa-taxi bg-c-blue"></i>
                <div class="d-inline">
                    <h5>Card Report List</h5>
                    <!--<span>View, add, delete vehicle</span>-->
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="index.php"><i class="feather icon-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Dashboard</a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="main-body">
    <div class="page-wrapper">

        <div class="page-body">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card" style="width: 100%; overflow: auto">
                        
                        <div class="card-block">
                            <!-- start search  -->
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label for="search">Search by</label>
                                    <select name="select" id="searchby" name="searchby" class="form-control">
                                        <option value="">All records</option>
                                        <option value="firstname">First Name</option>
                                        <option value="surname">Surname</option>
                                        <option value="rcn">R. C. N</option>
                                        <option value="phone_no">Phone Number</option>
                                         <option value="nin">NIN</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label for="keyword">Keyword</label>
                                    <input type="text" name="keyword" id="keyword" class="form-control">
                                </div>
                            </div>
                        <!-- end of search -->
                            <div class="row mt-2 mb-2">
                                <div class="col-md-3">
                                    <label for="start-date">Start date</label>
                                    <input type="date" name="start_date" value="<?php echo date('Y-m-d', strtotime('-22 year'))?>" id="start-date" class="form-control">
                                </div>
                                <div class="col-md-3">
                                    <label for="end-date">End date</label>
                                    <input type="date" name="end_date" value="<?php echo date('Y-m-d', strtotime('+5 day')); ?>" id="end-date" class="form-control">
                                </div>
                            </div>
                            <div class="row form-group">
                                <button class="btn btn-primary btn-sm" onclick="printReport('cb', 'Payment report', 'assets/print/css/style-print.css', ['th:nth-child(12)', 'td:nth-child(12)', 'th:nth-child(2)', 'td:nth-child(2)'])"><i class="fas fa-print"></i> Print selected record</button>
                            </div>
                             <!--   </div>-->
                            <hr>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-sm-12" id="cb" style="overflow-x: scroll;">
                                        <table id="tb" class="table table-hover">
                                            <thead>
                                                <tr class="visible">
                                                    <th>S/N</th>
                                                    <th>Select record</th>
                                                    <th>RCN</th>
                                                    <th>NIN</th>
                                                    <th>Title</th>
                                                    <th>Surname</th>
                                                    <th>Firstname</th>
                                                    <th>Gender</th>
                                                    <th>Phone Number</th>
                                                    <th>Date Registered</th>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </div>
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<script src="js/transactions.js"></script>
<script>
    $(document).ready(() => {
        datatable_init('tb', 'card_report');
        table.order([9, 'desc']).draw();

        $(document).on('change','#keyword, #searchby, #start-date, #end-date',() => {
            doFilter();
        })

        $(document).on('blur','#keyword, #searchby, #start-date, #end-date',() => {
            doFilter();
        })

        $(".dataTables_length").append("<br><br><div class='custom-control custom-checkbox'><input type='checkbox' value='chkall' class='custom-control-input' name='chkall' id='chkall' ><label class='custom-control-label btn badge badge-primary btn-sm' for='chkall'>Select all records</label></div>");
    })
</script>