<!-- new -->
<?php
include_once "lib/dbfunctions_new.php";
$dbobject = new dbobject();
function call(){
    $ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://fctevregendpointdemo.fctevreg.com/drts_selfservice/offencesList");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$json = curl_exec($ch);
$err = curl_error($ch);
curl_close($ch);

$data2 = json_decode($json, true);

return $data2['data']['list'];

}

$arr1 = call();

$keys = array_keys($arr1);
$collected = [];

foreach ($keys as $value) {
    array_push($collected, $value);
}
$got = [];
    foreach($collected as $bvalue){
        $stmt = $arr1[$bvalue];
    //   asort($stmt);
    foreach ($stmt as $offen) {
            array_push($got,$offen[name]);
    }
    }
sort($got);

$sql_veh = "SELECT veh_cat, veh_code FROM veh_cat ORDER BY veh_cat ASC";
$veh = $dbobject->dbQuery($sql_veh);
$sql_com = "SELECT name FROM lga_communities ORDER BY name ASC";
$com = $dbobject->dbQuery($sql_com);
// var_dump($veh);
// exit;
$op = isset($_REQUEST['op']) ? $_REQUEST['op'] : 'new';
if (!isset($_REQUEST['op'])) {

   $sql_type = "SELECT itemtype_id, payitem_id, payitem_name FROM tb_vregrate_tbl WHERE regcat_id = 'OFFEN' GROUP BY payitem_name ASC";
    $type = $dbobject->dbQuery($sql_type);

$id = 'cart';
$id = $id + 1;
}
?>


<script src="http://parsleyjs.org/dist/parsley.js"></script>
<script src="js/parsley.js"></script>
<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="fas fa-tasks bg-c-blue"></i>
                <div class="d-inline">
                    <h5>Referral List</h5>
                    <span>Add Referral</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="index.php"><i class="feather icon-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Dashboard</a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="main-body">
    <div class="page-wrapper">

        <div class="page-body">
            <!-- Modal start -->

            <!-- Modal -->
            <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Referral List <i class="fas fa-bars"></i></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form method="POST" id="form1" name="form1">
                            <input type="hidden" name="op" value="Referal.check">
                                <input type="hidden" id="check" name="check" value="">
                                <div class="form-group row">
                                    <div class="col-md-6">
                                        <label>Remitta Reference</label>
                                        <input type="text" id="pin" required value="" name="pin" class="form-control" >
                                    </div>
                                    <div class="col-md-6">
                                        <label>Phone Number</label>
                                        <input type="number" id="phone" required value="" name="phone" class="form-control" minlength="11">
                                    </div>
                                </div>
                            </form>
                            <div id="err"></div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal" id="close">Close</button>
                            <button type="button" class="btn btn-warning" onclick="checkPP('Referal', 'check', 'referal_form.php')">Next</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Modal end -->

            <div class="row">
                <div class="col-sm-12">

                    <div class="card" style="width: 100%; overflow: auto">
                        <div class="card-header">
                            <h5> Referral</h5>
                            <span>Add class of <code>.form-control</code> with <code>&lt;input&gt;</code> tag</span>
                        </div>
                        <div class="card-block">
                             <!-- start search  -->
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label for="search">Search by</label>
                                    <select name="select" id="searchby" name="searchby" class="form-control">
                                        <option value="">All records</option>
                                        <option value="name">Name</option>
                                        <option value="plate">Plate Number</option>
                                        <option value="nin">NIN</option>
                                        <option value="phone">Phone Number</option>
                                        <option value="location">L. G. A</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label for="keyword">Keyword</label>
                                    <input type="text" name="keyword" id="keyword" class="form-control">
                                </div>
                            </div>
                        <!-- end of search -->
                            <div class="row form-group">
                                <div class="col-4">
                                    <button class="btn btn-warning" id="new-referal" data-toggle="modal" data-target="#modal"><i class="fas fa-plus"></i> Add New Referral</button>
                                </div>
                            </div>

                            <hr>
                            <div class="row">
                                <div class="col-md-12">
                                    <table id="tb" class="table table-hover">
                                        <thead>
                                            <tr>
                                            <th>S/N</th>
                                            <th>First Name</th>
                                            <th>Plate Number</th>
                                            <th>NIN</th>
                                            <th>Phone Number</th>
                                            <th>Address</th>
                                            <th>Gender</th>
                                            <th>Vehicle Type</th>
                                            <th>Location</th>
                                            <th>Created</th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    <script src="./js/referal_list.js"></script>                                         
