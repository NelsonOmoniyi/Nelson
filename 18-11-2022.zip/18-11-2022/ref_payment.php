<?php include_once 'inc/layout/header2.php' ?>
<style>
.req {
    display: block;
    font-weight: bold;
}
.req-card {
    background-color: white;
    margin: 10px;
    padding: 10px;
    flex-wrap: nowrap;
}
@media only screen and (max-device-width: 480px){
    .bdr {
        padding: 0px !important;
        margin-top: -10px !important;
     }
     .bdr2 {
        padding-bottom: 10px !important;
     }
}
</style>
<div class="row">
    <aside class="col-md-6">
        <div class="row req-card">
                <i class="fa fa-info fa-10x text-info"></i>&nbsp;&nbsp;
                <div class="req">
                    <span>Kindly note the following:</span>
                    <ol type="i">
                        <li>This payment is for Referral Only.</li>
                    </ol>
                </div>
        </div>
    </aside>
	<aside class="col-md-6">
        <article class="card">
            <div class="card-body p-5">
                <!--<form id="form1">-->
                    <div class="form-group">
                        <label for="payment_category">Payment Category <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fa fa-list"></i></span>
                            </div>
                            <select name="payment_category" id="payment_category" class="form-control">
                                <option value="">::Select Payment Category::</option>
                                <option value="ref_trn"><?php echo "Referral Note"; ?></option>
                               
                            </select>
                        </div> <!-- input-group.// -->
                    </div> <!-- form-group.// -->
                    <div class="form-group">
                        <label for="customer_name">Name <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fa fa-user"></i></span>
                            </div>
                            <input type="text" id="customer_name" name="customer_name" required class="form-control" placeholder="Enter customer name" value="" title="Customer Name">
                        </div> <!-- input-group.// -->
                    </div> <!-- form-group.// -->
                    <div class="form-group">
                        <label for="customer_phone">Phone Number <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fa fa-mobile"></i></span>
                            </div>
                            <input type="text" id="customer_phone" name="customer_phone" required class="form-control" placeholder="Enter customer phone number" value="" title="Customer Phone Number" maxlength="11">
                        </div> <!-- input-group.// -->
                    </div> <!-- form-group.// -->
                    <div class="form-group">
                        <label for="customer_email">Email Address <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fa fa-address-book"></i></span>
                            </div>
                            <input type="email" id="customer_email" name="customer_email" required class="form-control" placeholder="Enter Customer Email Address" value="" title="Email Address">
                        </div> <!-- input-group.// -->
                    </div> <!-- form-group.// -->
                    <div class="row bdr2">
                        <div class="col-md-6">
                            <button class="btn btn-info btn-lg btn-block" type="button"  id="pay_evreg"> Pay Using eVreg PIN<br><small class="text-muted">powered by eTranzact</small></button>
                        </div>
                        <div class="col-md-6">
                            <button class="btn btn-dark btn-lg btn-block" type="button"  id="pay_card_remita"> Pay With Remita<br>&nbsp;</button>
                        </div>
                    </div>
                    <div class="row">&nbsp;&nbsp;</div>
            </div> <!-- card-body.// -->
        </article> <!-- card.// -->
	</aside>
</div> <!-- row.// -->
<?php include_once 'inc/layout/footer2.php' ?>
