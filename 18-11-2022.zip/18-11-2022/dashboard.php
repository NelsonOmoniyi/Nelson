<?php
/*error_reporting(E_ALL);
ini_set('display_errors',1);*/
include_once 'lib/dbfunctions_new.php';
include_once 'classes/Vehicle.php';
$vehicle = new Vehicle;
$dbobject = new dbobject();
// 😒
@session_start();
$role_id            = $_SESSION['pts_role_id_sess'];
$username           = $_SESSION['pts_username_sess'];
$license_operator   = $_SESSION['pts_license_operator'];



?>
<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="feather icon-home bg-c-blue"></i>
                <div class="d-inline">
                    <h5>Dashboard</h5>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="index.php"><i class="feather icon-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Dashboard</a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="pcoded-inner-content">
    <div class="main-body">
        <div class="page-wrapper">
            <div class="page-body">
                <div class="row">

                    <?php
                    if ($role_id == '503') {///licensed operators
                    ?>
                        <div class="col-xl-3 col-md-6">
                            <div class="card prod-p-card card-success">
                                <div class="card-body">
                                    <div class="row align-items-center m-b-30">
                                        <div class="col">
                                            <h6 class="m-b-5 text-white">Registered Vehicles</h6>
                                            <h3 class="m-b-0 f-w-700 text-white"><?php echo $vehicle->registeredVehicles(); ?></h3>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-car text-c-green f-18"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="card prod-p-card card-blue">
                                <div class="card-body">
                                    <div class="row align-items-center m-b-30">
                                        <div class="col">
                                            <h6 class="m-b-5 text-white">Approved Registrations</h6>
                                            <h3 class="m-b-0 f-w-700 text-white"><?php echo $vehicle->approvedRegisteredVehicles() ?></h3>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-registered text-c-blue f-18"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="card prod-p-card bg-dark">
                                <div class="card-body">
                                    <div class="row align-items-center m-b-30">
                                        <div class="col">
                                            <h6 class="m-b-5 text-white">Pending Approval</h6>
                                            <h3 class="m-b-0 f-w-700 text-white"><?php echo $vehicle->pendingRegisteredVehicles() ?></h3>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-hourglass text-c-black f-18"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="card prod-p-card card-red">
                                <div class="card-body">
                                    <div class="row align-items-center m-b-30">
                                        <div class="col">
                                            <h6 class="m-b-5 text-white">Flagged Registrations</h6>
                                            <h3 class="m-b-0 f-w-700 text-white"><?php echo $vehicle->flaggedRegisteredVehicles() ?></h3>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-flag text-c-red f-18"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php
                    } else 
                    {
                    ?>
                        <div class="col-xl-3 col-md-6">
                            <div class="card prod-p-card card-success">
                                <div class="card-body">
                                    <div class="row align-items-center m-b-30">
                                        <div class="col">
                                            <h6 class="m-b-5 text-white">Registered Vehicles</h6>
                                            <h3 class="m-b-0 f-w-700 text-white"><?php echo $vehicle->registeredVehicles(true); ?></h3>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-car text-c-green f-18"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="card prod-p-card card-blue">
                                <div class="card-body">
                                    <div class="row align-items-center m-b-30">
                                        <div class="col">
                                            <h6 class="m-b-5 text-white">Approved Registrations</h6>
                                            <h3 class="m-b-0 f-w-700 text-white"><?php echo $vehicle->approvedRegisteredVehicles(true); ?></h3>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-registered text-c-blue f-18"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="card prod-p-card bg-dark">
                                <div class="card-body">
                                    <div class="row align-items-center m-b-30">
                                        <div class="col">
                                            <h6 class="m-b-5 text-white">Pending Approval</h6>
                                            <h3 class="m-b-0 f-w-700 text-white"><?php echo $vehicle->pendingRegisteredVehicles(true) ?></h3>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-hourglass text-c-black f-18"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="card prod-p-card card-red">
                                <div class="card-body">
                                    <div class="row align-items-center m-b-30">
                                        <div class="col">
                                            <h6 class="m-b-5 text-white">Flagged Registrations</h6>
                                            <h3 class="m-b-0 f-w-700 text-white"><?php echo $vehicle->flaggedRegisteredVehicles(true) ?></h3>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-flag text-c-red f-18"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php
                    } ?>

                    <?php
                    //switch ($role_id) {
                        //case '001':
                    ?>
                            <!--<div class="col-xl-6 col-md-6 col-sm-12">
                                <div class="card latest-update-card">
                                    <div class="card-header">
                                        <div class="card-header-right">
                                            <ul class="list-unstyled card-option">
                                                <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                                <li><i class="feather icon-maximize full-card"></i></li>
                                                <li><i class="feather icon-minus minimize-card"></i></li>
                                                <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                                <li><i class="feather icon-trash close-card"></i></li>
                                                <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="card-block">
                                        <div class="latest-update-box">
                                            <br>
                                            <div class="row p-b-30">
                                                <div class="col-auto text-right update-meta p-r-0">
                                                    <i class="feather icon-users bg-c-red update-icon"></i>
                                                </div>
                                                <div class="col p-l-5">
                                                    <a href="#!">
                                                        <h6><?php //echo $vehicle->numberOfUsers('userdata'); ?> Users</h6>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>-->
                        <?php
                           // break;
                    switch ($role_id) {
                        case '501':
                        case '502':
                        case '507':
                        case '001':
                        ?>
                            <div class="col-xl-6 col-md-6 col-sm-12">
                                <div class="card latest-update-card">
                                    <div class="card-header">
                                        <div class="card-header-right">
                                            <ul class="list-unstyled card-option">
                                                <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                                <li><i class="feather icon-maximize full-card"></i></li>
                                                <li><i class="feather icon-minus minimize-card"></i></li>
                                                <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                                <li><i class="feather icon-trash close-card"></i></li>
                                                <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="card-block">
                                        <div class="latest-update-box">
                                            <br>
                                            <div class="row p-b-30">
                                                <div class="col-auto text-right update-meta p-r-0">
                                                    <i class="fa fa-car bg-c-blue update-icon"></i>
                                                </div>
                                                <div class="col p-l-5">
                                                    <a href="#!">
                                                        <h6><?php echo $vehicle->approvedRegisteredVehicles(true); ?> Vehicle(s) approved</h6>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="row p-b-30">
                                                <div class="col-auto text-right update-meta p-r-0">
                                                    <i class="fa fa-car bg-c-blue update-icon"></i>
                                                </div>
                                                <div class="col p-l-5">
                                                    <a href="#!">
                                                        <h6><?php echo $vehicle->getVehicleWithSideNumber(true); ?> Vehicle(s) with side number</h6>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="row p-b-30">
                                                <div class="col-auto text-right update-meta p-r-0">
                                                    <i class="fa fa-car bg-c-blue update-icon"></i>
                                                </div>
                                                <div class="col p-l-5">
                                                    <a href="#!">
                                                        <h6><?php echo $vehicle->getVehicleExpiredRWC(true); ?> Vehicle(s) with expired road worthiness</h6>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- New Graph by Nelson -->
                            <div class="col-sm-12" >
                                <div class="card latest-update-card">
                                    <div class="card-header">
                                    <h5 class="card-title mb-0">Referral</h5>
                                        <div class="card-header-right">
                                            <ul class="list-unstyled card-option">
                                                <li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
                                                <li><i class="feather icon-maximize full-card"></i></li>
                                                <li><i class="feather icon-minus minimize-card"></i></li>
                                                <li><i class="feather icon-refresh-cw reload-card"></i></li>
                                                <li><i class="feather icon-trash close-card"></i></li>
                                                <li><i class="feather icon-chevron-left open-card-option"></i></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="card-block" >
                                        <div class="card-body">
                                            <div class="chart chart-lg" style="height: 300px;">
                                                <canvas id="chartjs-dashboard-line"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php
                            break;
                        //case '502':
                        ?>
                          
                        <?php
                            //break;
                        case '503':
                        ?>
                            
                        <?php
                            break;
                       // case '505':
                        ?>
                            
                        <?php
                           // break;
                        default:
                            break;
                    }
                    ?>
                </div>



            </div>
        </div>
    </div>
</div>

<?php 

$sql_lga="SELECT * FROM `offenders` ORDER BY location ASC";
$lgas = $dbobject->dbQuery($sql_lga);
// print_r(count($lgas));

$Abaji = array();
$Municipal = array();
$Bwari = array();
$Gwagwalada = array();
$Kuje = array();
$Kwali = array();

foreach ($lgas as $value) {
    $place = $value['location'];
    // print_r($place."</br>");
    if ($place == 'Abaji') {
        $Abaji[] = $place;
    } elseif ($place == 'Municipal Area Council') {
        $Municipal[] = $place;
    } elseif ($place == 'Bwari'){
        $Bwari[] = $place;
    }elseif ($place == 'Gwagwalada') {
        $Gwagwalada[] = $place;
    } elseif ($place == 'Kuje'){
        $Kuje[] = $place;
    }elseif ($place == 'Kwali') {
        $Kwali[] = $place;
    }
    
}

?>


<script>
		$(function() {
			// Line chart
			new Chart(document.getElementById("chartjs-dashboard-line"), {
				type: "line",
				data: {
					labels: ["Abaji", "Municipal Area Council", "Bwari", "Gwagwalada", "Kuje", "Kwali"],
					datasets: [{
						label: "Referral",
						fill: true,
						backgroundColor: "transparent",
						borderColor: window.theme.primary,
						data: [<?php echo count($Abaji); ?>, <?php echo count($Municipal); ?>, <?php echo count($Bwari); ?>, <?php echo count($Gwagwalada); ?>, <?php echo count($Kuje); ?>, <?php echo count($Kwali); ?>]
					}]
				},
				options: {
					maintainAspectRatio: false,
					legend: {
						display: false
					},
					tooltips: {
						intersect: false
					},
					hover: {
						intersect: true
					},
					plugins: {
						filler: {
							propagate: false
						}
					},
					scales: {
						xAxes: [{
							reverse: true,
							gridLines: {
								color: "rgba(0,0,0,0.05)"
							}
						}],
						yAxes: [{
							ticks: {
								stepSize: 10
							},
							display: true,
							borderDash: [5, 5],
							gridLines: {
								color: "rgba(0,0,0,0)",
								fontColor: "#fff"
							}
						}]
					}
				}
			});
		});
	</script>