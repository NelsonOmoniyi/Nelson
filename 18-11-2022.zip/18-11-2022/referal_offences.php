<div class="row">
                <div class="col-sm-12">

                    <div class="card" style="width: 100%; overflow: auto">
                        <div class="card-header">
                            <h5> Referal</h5>
                            <span>Add class of <code>.form-control</code> with <code>&lt;input&gt;</code> tag</span>
                        </div>
                        <div class="card-block">
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label for="search">Search by</label>
                                    <select name="select" id="searchby" name="searchby" class="form-control">
                                        <option value="phone">Phone Number</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label for="keyword">Keyword</label>
                                    <input type="text" name="keyword" id="keyword" class="form-control">
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col-4">
                                    <button class="btn btn-warning" id="new-referal" data-toggle="modal" data-target="#modal"><i class="fas fa-plus"></i> Add New Referal</button>
                                </div>
                            </div>

                            <hr>
                            <div class="row">
                                <div class="col-md-12">
                                    <table id="tb" class="table table-hover">
                                        <thead>
                                            <tr>
                                            <th>S/N</th>
                                            <th>First Name</th>
                                            <th>Plate Number</th>
                                            <th>NIN</th>
                                            <th>Phone Number</th>
                                            <th>Address</th>
                                            <th>Gender</th>
                                            <th>Vehicle Type</th>
                                            <th>Location</th>
                                            <th>Created</th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>