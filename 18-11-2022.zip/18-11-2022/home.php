<?php
// error_reporting(0);

include_once 'session.php'; ?>
<?php
include_once 'inc/layout/header.php';
?>
<head>
<link rel="stylesheet" href="assets/css/datatable.bootstrap4.min.css" />

<?php include_once 'inc/layout/scripts.php' ?>

<title>Admin | PTMS</title>
<style>
    .parsley-required {
        color: red !important;
        font-weight: bolder;
    }
</style>
</head>

<body>

    <div class="loader-bg">
        <div class="loader-bar"></div>
    </div>

    <div id="pcoded" class="pcoded">
        <div class="pcoded-overlay-box"></div>
        <div class="pcoded-container navbar-wrapper">

            <nav class="navbar header-navbar pcoded-header" style="background-color: #263544 !important; color:white !important">
                <div class="navbar-wrapper">
                    <div class="navbar-logo">
                        <a href="index.php">
                            <span>
                                <img class="img-fluid " src="home/img/icons/logo.png" style="height: 5em" alt="Public Transport Management System" />
                            </span>
                        </a>
                        <a class="mobile-menu" id="mobile-collapse" href="#!">
                            <i class="feather icon-menu icon-toggle-right"></i>
                        </a>
                        <a class="mobile-options waves-effect waves-light">
                            <i class="feather icon-more-horizontal"></i>
                        </a>
                    </div>
                    <div class="navbar-container container-fluid">
                        <ul class="nav-left">
                            <li>
                                <a href="#!" onclick="if (!window.__cfRLUnblockHandlers) return false; javascript:toggleFullScreen()" class="waves-effect waves-light" data-cf-modified-3ee7385a746719e963fad07a-="">
                                    <i class="full-screen feather icon-maximize" style="color:white"></i>
                                </a>
                            </li>
                            <li>
                                <label class="label label-primary">ROLE</label><span style="font-weight: bolder"><?php echo strtoupper($_SESSION['pts_role_name_sess']); ?></span>
                            </li>
                            <?php
                            if ($_SESSION['pts_role_id_sess'] == '503') {
                            ?>
                                <li>
                                    <label class="label label-primary">LICENSE OPERATOR</label><span style="font-weight: bolder"><?php echo strtoupper($_SESSION['pts_license_operator_name']); ?></span>
                                </li>
                            <?php
                            }
                            else if ($_SESSION['pts_role_id_sess'] == '502') {
                            ?>
                                <li>
                                    <label class="label label-primary">CENTRE NAME</label><span style="font-weight: bolder"><?php echo strtoupper($_SESSION['pts_registration_centre']); ?></span>
                                </li>
                            <?php
                            }
                            ?>
                        </ul>
                        <ul class="nav-right">
                            <li class="user-profile header-notification">
                                <div class="dropdown-primary dropdown">
                                    <div class="dropdown-toggle" data-toggle="dropdown">
                                        <span><?php echo ucfirst($_SESSION['pts_username_sess']); ?></span>
                                        <i class="feather icon-chevron-down"></i>
                                    </div>
                                    <ul class="show-notification profile-notification dropdown-menu" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
                                        <li>
                                            <a href="#" onclick="getPage('profile.php','box')">
                                                <i class="feather icon-user"></i> Profile
                                            </a>
                                        </li>
                                        <li>
                                            <a href="logout.php"><!---<?php echo $_SESSION['pts_role_id_sess'] == '505' ? 'login.php' : 'logout.php' ?>--->
                                                <i class="feather icon-log-out"></i> Logout
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>

            <div id="sidebar" class="users p-chat-user showChat">
                <div class="had-container">
                    <div class="p-fixed users-main">
                        <div class="user-box">
                            <div class="chat-search-box">
                                <a class="back_friendlist">
                                    <i class="feather icon-x"></i>
                                </a>
                                <div class="right-icon-control">
                                    <div class="input-group input-group-button">
                                        <input type="text" id="search-friends" name="footer-email" class="form-control" placeholder="Search Friend">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary waves-effect waves-light" type="button"><i class="feather icon-search"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="pcoded-main-container">
                <div class="pcoded-wrapper">
                    <?php include_once 'inc/layout/sidebar.php'; ?>
                    <div class="pcoded-content" id="box">
                        <?php include_once './dashboard.php'; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/datatable.bootstrap4.min.js"></script>
    <script src="js/datatable.init.js"></script>
    <script src="js/print-record.js"></script>
    <script src="js/clear-user-input.min.js"></script>
    
    

    <?php //include 'inc/check_owner_reg.php' ?>
</body>


</html>