<?php

class Referal extends dbobject{

   public function saveReferal($data){

         $name = $data['name'];
         $address = $data['address'];
         $phone = $data['phone'];
         $nin = $data['nin'];
         $dob = $data['dob'];
         $gender = $data['gender'];
         $vehtype = $data['VehType'];
         $plate = $data['plate'];
         $location = $data['location'];
         $others = $data['others'];
         $checkOff = $data['check'];
         $offences = $data['offences'];
         $payment = $data['pin'];
         $date = date('Y-m-d H:i:s');

      $validation = $this->validate($data,
         array(
               'name'=>'required',
               'address'=>'required',
               'phone'=>'required',
               'nin'=>'required',
               'dob'=>'required',
               'gender'=>'required',
               'VehType'=>'required',
               'plate'=>'required',
               'location'=>'required',
               'check'=>'required',
               'pin' => 'required'
         ),
         array('check'=>'Violation','name'=>'Violator`s Name','address'=>'Violator`s Address','phone'=>'Violator`s Phone Number', 'nin'=>'Violator`s NIN Number', 'dob'=>'Date Of Birth', 'gender'=>'Violator`s Gender', 'VehType'=>'Vehicle Type', 'plate'=>'Plate Number', 'location'=>'Location Of Violation', 'pin'=>'Payment Pin')
         );
         // validate pin
         $sql_pin = "SELECT * FROM transaction_table WHERE rrr = '$payment'";
         $result = $this->dbQuery($sql_pin);
         if ($result == NULL) {
            // Pin Not found
            return json_encode(
               array(
                     "response_code" => 1,
                     "response_message" => "Not Found !!",
                     "elem" => "Pin",
                     "data" => [],
               )
            );
         } else {
            // ?pin found
            if ($result[0]['response_code'] == '200' || $result[0]['response_code'] == '0') {
               // Transaction successful
              if ($result[0]['settlement_status'] == '0') {
               // pin have not been used
               if ($result[0]['transaction_amount'] >= '1750') {
                  // if amount paid is equal the required price
                  if (strlen($phone) !=11 ) {
                     return json_encode(
                        array(
                              "response_code" => 1,
                              "response_message" => "Wrong Phone Number Format",
                              "elem" => " ",
                              "data" => [],
                        )
                     );
                  } else {
                     $first_3 = substr($phone, 0, 3);
                     if ($first_3 == '080' || $first_3 == '090' || $first_3 == '081' || $first_3 == '091' || $first_3 == '070' || $first_3 == '071') {
                        if ($checkOff < 1) {
                           return json_encode(
                              array(
                                 "response_code" => 1,
                                 "response_message" => "Data was not saved, please add a violation",
                                 "elem" => "Referral",
                                 "data" => [],
                              )
                           );
                        }else{
                        
            
                           if(!$validation['error']){
                              
                              if ($offences == NULL) {
                                    return json_encode(
                                       array(
                                          "response_code" => 1,
                                          "response_message" => "Data was not saved, please add a violation",
                                          "elem" => "Referal",
                                          "data" => [],
                                       )
                                 );
                                 }else{
                                 
                                 ob_start();
                              
                                 foreach ($offences as $value) {
                                    $arr='';
                                    $check = $value.',';
                                    $arr = $arr."".$check;
                                    echo $arr; 
                                 }
                                 $arr1 = ob_get_clean();
                                 
                                 // $array = str_split($arr1, 3);
                                 $arra = explode(",", $arr1);
                                 $array = array_pop($arra);
                              
                                 if (max(array_count_values($arra)) > 1) {
                                    
                                    return json_encode(array('response_code'=>-1,'response_message'=>'Duplicated Records Are Not Allowed In The Violation Section',"elem" => "Referal","data" => []));
                                 }else{
                                    $used = 1;
                                    $insert = "INSERT INTO offenders (name, address, phone, nin, dob, gender, VehType, plate, location, others, date, pin, status)
                                    VALUES ('$name', '$address', '$phone', '$nin', '$dob', '$gender', '$vehtype', '$plate', '$location', '$others', '$date', '$payment', '1')";
                                    $result = $this->dbQuery($insert);
                                    $getLastID = "SELECT id FROM offenders ORDER BY id DESC LIMIT 1";
                                    $ret = $this->dbQuery($getLastID);
                                    $form_id = $ret[0]['id'];
                                    
                                    foreach($offences as $me){
                                       $sql_cate = "SELECT itemtype_id, payitem_name FROM tb_vregrate_tbl WHERE regcat_id = 'OFFEN' AND payitem_id = '$me' GROUP BY payitem_name ASC";
                                       $type = $this->dbQuery($sql_cate);
                                       $cat = $type[0]['itemtype_id'];
                                       $insert = "INSERT INTO offences (nin, offence_cart, offence_name, form_id) VALUES ('$nin', '$cat', '$me', '$form_id')";
                                       $this->dbQuery($insert);
                                       // echo " Here ".$cat.", ";
                                    }
                                       $query_data = "UPDATE transaction_table SET settlement_status='$used' WHERE rrr = '$payment'";
                                       $result_data = $this->dbQuery($query_data, false);

                                    if(count($result) == 0)
                                    {
                                       return json_encode(array('response_code'=>0,'response_message'=>'Created Successfully',"elem" => "Referral","data" => []));
                                    }else
                                    {
                                       return json_encode(array('response_code'=>1,'response_message'=>'Creation Failed',"elem" => "Referral","data" => []));
                                    }
                                 }
                              }
                           }else
                           {
                                 return json_encode(array("response_code"=>20,"response_message"=>$validation['messages'][0],"elem" => "saveReferral","data" => []));
                           }
                        }
            
                     } else {
                        return json_encode(
                           array(
                              "response_code" => 1,
                              "response_message" => "Wrong Phone Number Format",
                              "elem" => " ",
                              "data" => [],
                           )
                        );
                     }
                  }  
               }else{
                  return json_encode(
                     array(
                        "response_code" => 1,
                        "response_message" => "Incomplete payment.",
                        "elem" => "",
                        "data" => [],
                     )
                  );
               }
                  
              } else {
               // pin have been used
               return json_encode(
                  array(
                     "response_code" => 1,
                     "response_message" => "This pin have been used",
                     "elem" => "",
                     "data" => [],
                  )
               );
              }
              
            } else {
               // Transaction Not Successful
               return json_encode(
                  array(
                     "response_code" => 1,
                     "response_message" => "Transaction Not Successful",
                     "elem" => "Pin",
                     "data" => [],
                  )
               );
            }
         }
   }

   public function check($data){
     
      // var_dump($data);
      // exit;
      $phone_number = $data['phone'];
      $pin = str_replace('-', '', $data['pin']);

      $validation = $this->validate($data,
         array(
               'phone'=>'required',
               'pin' => 'required'
         ),
         array('phone'=>'Phone Number', 'pin'=>'Payment Pin')
         );

         if(!$validation['error']){
            // validate pin
            $sql_pin = "SELECT * FROM transaction_table WHERE rrr = '$pin'";
            $result = $this->dbQuery($sql_pin);
            if ($result == NULL) {
               // Pin Not found
               return json_encode(
                  array(
                        "response_code" => 1,
                        "response_message" => "Not Found !!",
                        "elem" => "Pin",
                        "data" => [],
                  )
               );

            } else {
               // ?pin found
               if ($result[0]['response_code'] == '200' || $result[0]['response_code'] == '0') {
                  // Transaction successful
               if ($result[0]['settlement_status'] == '0') {
                  // pin have not been used
                  if ($result[0]['transaction_amount'] >= '1750') {
                     // if amount paid is equal the required price
                     if (strlen($phone_number) !=11 ) {
                        return json_encode(
                           array(
                                 "response_code" => 1,
                                 "response_message" => "Wrong Phone Number Format",
                                 "elem" => " ",
                                 "data" => [],
                           )
                        );
                     } else {
                        $first_3 = substr($phone_number, 0, 3);
                        if ($first_3 == '080' || $first_3 == '090' || $first_3 == '081' || $first_3 == '091' || $first_3 == '070' || $first_3 == '071') {
                        // All fine
                        $sql_pin = "SELECT count(phone) FROM offenders WHERE phone = '$phone_number'";
                        $result = $this->dbQuery($sql_pin);
                        $ordinal = $this->ordinal($result[0]['count(phone)']+1);
                        if ($result[0]['count(phone)'] > 0) {
                           return json_encode(array('response_code'=>0,'response_message'=>'Hold On Please, This Is A '.$ordinal.' Time Offender',"elem" => "","data" => []));
                        } else {
                           return json_encode(array('response_code'=>0,'response_message'=>'Please Wait A Moment!',"elem" => "","data" => []));
                        }
                        
                        } else {
                           return json_encode(
                              array(
                                 "response_code" => 1,
                                 "response_message" => "Wrong Phone Number Format",
                                 "elem" => " ",
                                 "data" => [],
                              )
                           );
                        }
                     }  
                  }else{
                     return json_encode(
                        array(
                           "response_code" => 1,
                           "response_message" => "Incomplete payment.",
                           "elem" => "",
                           "data" => [],
                        )
                     );
                  }
                     
               } else {
                  // pin have been used
                  return json_encode(
                     array(
                        "response_code" => 1,
                        "response_message" => "This pin have been used",
                        "elem" => "",
                        "data" => [],
                     )
                  );
               }
               
               } else {
                  // Transaction Not Successful
                  return json_encode(
                     array(
                        "response_code" => 1,
                        "response_message" => "Transaction Not Successful",
                        "elem" => "Pin",
                        "data" => [],
                     )
                  );
               }
            }
         }else {
            return json_encode(array("response_code"=>1,"response_message"=>$validation['messages'][0],"elem" => "saveReferral","data" => []));
         }
   }


   function ordinal($a) {
      // return English ordinal number
      return $a.substr(date('jS', mktime(0,0,0,1,($a%10==0?9:($a%100>20?$a%10:$a%100)),2000)),-2);
    }
}
?>
 