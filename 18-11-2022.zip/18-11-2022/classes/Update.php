<?php 
class Update extends dbobject
{
  
    public function updateMissingRecord($data)
    {
        if ($data['title'] == '' || $data['surname']=='' || $data['firstname']=='' || $data['phone_no']=='' || $data['nin']=='' || $data['birthdate']=='' || $data['blood_group']==''|| $data['nationality']==''|| $data['email_address']==''|| $data['address_residence']=='') {
            return json_encode(
                array(
                    "response_code" => 1,
                    "response_message" => "Pls Fill All The Required Fields",
                    "elem" => "User",
                    "data" => [],
                )
            );
        } else {
            $query = "UPDATE tbl_riders set title='$data[title]',surname ='$data[surname]',firstname='$data[firstname]',gender='$data[gender]', phone_no='$data[phone_no]', native_lang='$data[native_lang]',nin='$data[nin]',othername='$data[othername]', birthdate='$data[birthdate]',blood_group='$data[blood_group]',marital_status='$data[marital_status]',nationality='$data[nationality]', edu_qual='$data[edu_qual]', contact_addr='$data[contact_addr]', email_address='$data[email_address]', pob='$data[pob]', lga_origin='$data[lga_origin]', home_origin='$data[home_origin]', state_origin='$data[state_origin]', address_residence='$data[address_residence]', birthcountry='$data[birthcountry]', birthlga='$data[birthlga]', height='$data[height]', employment_status='$data[employment_status]', profession='$data[profession]', religion='$data[religion]', residence_status='$data[residence_status]',residence_town='$data[residence_town]', residence_lga='$data[residence_lga]',residence_state='$data[residence_state]', nok_spokenlang='$data[nok_spokenlang]',nok_town='$data[nok_town]', nok_firstname='$data[nok_firstname]', nok_state='$data[nok_state]', nok_surname='$data[nok_surname]', nok_middlename='$data[nok_middlename]', nok_lga='$data[nok_lga]', nok_address1='$data[nok_address1]', nok_address2='$data[nok_address2]' WHERE rcn= '$data[rcn]'";
            $response = $this->dbQuery($query, false);
            if ($response > 0) {
                return json_encode(
                    array(
                        "response_code" => 0,
                        "response_message" => "Records Have Been Updated Successfully",
                        "elem" => "User",
                        "data" => [],
                    )
                );
            } else {
                return json_encode(
                    array(
                        "response_code" => 1,
                        "response_message" => "Error : Please Contact A Developer",
                        "elem" => "User",
                        "data" => []
                    )
                );
            }
        }
    }
}

?>