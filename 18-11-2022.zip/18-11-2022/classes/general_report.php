<?php
include_once 'engine.php';

$datatableEngine = new engine();

class general_report extends engine
{
    public function role($data)
    {
        $table_name = "role";
        $primary_key = "role_id";
        $columner = array(
            array('db' => 'role_id', 'dt' => 0),
            array('db' => 'role_id', 'dt' => 1),
            array('db' => 'role_name', 'dt' => 2),
            // array('db' => 'role_enabled', 'dt' => 3),
            array('db' => 'created', 'dt' => 3),
            array(
                'db' => 'role_id', 'dt' => 4, 'formatter' => function ($d, $row) {
                    return "<a href='#' data-toggle='modal' id='edit-role' data-target='#modal' class='btn btn-success btn-sm' onclick=\"saveRole('$d')\"><i class='fa fa-pencil-alt'></i> Edit</a>&nbsp;<button onclick=\"deleteRole('$d')\" class='btn btn-danger btn-sm'><i class='fa fa-trash'></i> Delete</button>";
                },
            ),
        );
        $filter = "";
        $search = $data['searchby'];
        $keyword = $data['keyword'];

        $search == '' ? $filter = "" : $filter = "AND $search like '%" . $keyword . "%'";
        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
    }

    public function menu($data)
    {
        $table_name = "menu";
        $primary_key = "menu_id";
        $columner = array(
            array('db' => 'menu_id', 'dt' => 0,),
            array('db' => 'menu_id', 'dt' => 1),
            array('db' => 'menu_name', 'dt' => 2),
            array('db' => 'menu_url', 'dt' => 3),
            array('db' => 'parent_id', 'dt' => 4),
            array('db' => 'created', 'dt' => 5),
            array(
                'db' => 'menu_id', 'dt' => 6, 'formatter' => function ($d, $row) {
                    return "<a href='#' data-toggle='modal' id='edit-menu' data-target='#menu-modal' class='btn btn-success btn-sm' onclick=\"editMenu('$row[menu_id]')\"><i class='fa fa-pencil-alt'></i> Edit</a>&nbsp;<button onclick=\"deleteMenu('$row[menu_id]')\" class='btn btn-danger btn-sm'><i class='fa fa-trash'></i> Delete</button>";
                },
            ),
        );
        $filter = "";
        $search = $data['searchby'];
        $keyword = $data['keyword'];

        $search == '' ? $filter = "" : $filter = "AND $search like '%" . $keyword . "%'";
        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
    }

    public function vehicleCategory($data)
    {
        $table_name = "veh_cat";
        $primary_key = "id";
        $columner = array(
            array('db' => 'id', 'dt' => 0,),
            array('db' => 'veh_cat_id', 'dt' => 1, 'formatter' => function ($d, $row) {
                return "<div class='custom-control custom-checkbox'><input type='checkbox' name='chkopt[]' value='$row[veh_cat_id]' class='custom-control-input chk' id='$row[veh_cat_id]'><label class='custom-control-label' for='$row[veh_cat_id]'></label></div>";
            }),
            array('db' => 'veh_cat_id', 'dt' => 2),
            array('db' => 'veh_cat', 'dt' => 3),
            array('db' => 'created', 'dt' => 4),
            array(
                'db' => 'id', 'dt' => 5, 'formatter' => function ($d, $row) {
                    return "<a href='#' data-toggle='modal' id='edit-menu' data-target='#modal' class='btn btn-success btn-sm' onclick=\"editVehicleCat('$row[veh_cat_id]')\"><i class='fa fa-pencil-alt'></i> Edit</a>&nbsp;<button onclick=\"deleteVehicleCat('$row[veh_cat_id]')\" class='btn btn-danger btn-sm'><i class='fa fa-trash'></i> Delete</button>";
                },
            ),
        );
        $filter = "";
        $search = $data['searchby'];
        $keyword = $data['keyword'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];

        $search == '' ? $filter = "" : $filter = "AND $search like '%" . $keyword . "%'";
        $filter .= " AND created BETWEEN '$start_date' AND '$end_date'";
        
        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
    }

    public function vehicleList($data)
    {
        $table_name = "vehicle_tbl";
        $primary_key = "chassis_no";
        $reg_status = '';
        $columner = array(
            array('db' => 'chassis_no', 'dt' => 0),
            array('db' => 'chassis_no', 'dt' => 1, 'formatter' => function ($d, $row) {
                return "<div class='custom-control custom-checkbox'><input type='checkbox' name='chkopt[]' value='$row[chassis_no]' class='custom-control-input chk' id='$row[chassis_no]'><label class='custom-control-label' for='$row[chassis_no]'></label></div>";
            }),
            array('db' => 'veh_make', 'dt' => 2),
            array('db' => 'veh_model', 'dt' => 3),
            array('db' => 'veh_type', 'dt' => 4),
            array('db' => 'veh_purpose', 'dt' => 5, function ($d, $r) {
                // return substr($d, 11, 6);
                return $d;
            }),
            array('db' => 'veh_colour', 'dt' => 6),
            array('db' => 'veh_side_no', 'dt' => 7, 'formatter' => function ($d, $r) {
                return strlen($d) > 0 ? $d : "Side number hasn't been generated; please go to a vehicle inspection office";
            }),
            array('db' => 'plate_no', 'dt' => 8),
            array('db' => 'reg_status', 'dt' => 9, 'formatter' => function ($d, $r) {
                if ($d == 1) {
                    $reg_status = "<b style='font-weight:800' class='text-success'>This owner/vehicle has been approved</b>";
                } else if ($d == 0) {
                    $reg_status = "<b style='font-weight:800' class='text-danger'>This owner/vehicle has not been approved</b>";
                } else {
                    $reg_status = "<b style='font-weight:800' class='text-info'>This owner/vehicle was flagged</b>";
                }
                return $reg_status;
            }),
            array('db' => 'created', 'dt' => 10),
            array(
                'db' => 'chassis_no', 'dt' => 11, 'formatter' => function ($d, $row) {
                    $operator_admin_roles   = $this->getAdminRoles('licensed_operator');
                    $approve_btn = "<a href='#' class='btn btn-info btn-sm' data-toggle='modal' id='view-vehicle-info' data-target='#vehicle-modal' onclick=\"viewVehicleInfo('$row[chassis_no]')\"><i class='fa fa-eye'></i> View Vehicle Info</a> ";
                    // license operator
                    //if ($_SESSION['pts_role_id_sess'] == '503' && $row['reg_status'] !== '1') {
                    if (in_array($_SESSION['pts_role_id_sess'],$operator_admin_roles) && $row['reg_status'] !== '1') {
                        $approve_btn .= "<a href='#' class='btn btn-primary btn-sm' onclick=\"confirmRegStatus('$row[chassis_no]')\"><i class='fa fa-check'></i> Confirm registration</a>";
                    //} else if ($_SESSION['pts_role_id_sess'] == '503' && $row['reg_status'] == '1') {
                    } else if (in_array($_SESSION['pts_role_id_sess'],$operator_admin_roles) && $row['reg_status'] == '1') {
                        $approve_btn .= "<a href='#' class='btn btn-danger btn-sm' onclick=\"declineVehicleReg('$row[chassis_no]')\"><i class='fa fa-check'></i> Decline registration</a>";
                    }
                    /*
                    <a href='#' class='btn btn-success btn-sm edit-veh' onclick=\"getPage('vehicle_setup.php?op=edit&amp;veh_id=" . $d . "','box')\"><i class='fa fa-pencil-alt'></i> Edit</a>
                    <button onclick=\"deleteVehicleList('$row[chassis_no]')\" class='btn btn-danger btn-sm'><i class='fa fa-trash'></i> Delete</button>
                    */
                    return " $approve_btn ";
                },
            ),
        );
        $filter = "";
        $search = $data['searchby'];
        $keyword = $data['keyword'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        $role_id = $_SESSION['pts_role_id_sess'];
        $username = trim($_SESSION['pts_username_sess']);
        $operator = trim($_SESSION['pts_license_operator']);
        
        $search == '' ? $filter = "" : $filter = "AND $search like '%" . $keyword . "%'";
        // $filter .= " AND created BETWEEN '$start_date' AND '$end_date'";

        if ($role_id == '505') {
            $filter .= " AND owner_username = '$username'";
        } else if ($role_id == '503') {
            $filter .= " AND license_operator = '$operator'";
        } else if ($role_id == '501') {
            // $filter .= " AND reg_status = '1'";
        } else {
            $filter .= "";
        }

        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
    }

    public function userlist($data)
    {
        $table_name = "userdata";
        $primary_key = "username";
        $columner = array(
            array('db' => 'role_id', 'dt' => 0),
            array('db' => 'username', 'dt' => 1),
            array('db' => 'role_id', 'dt' => 2, 'formatter' => function ($d, $row) {
                return $this->getItemLabel('role', 'role_id', $d, 'role_name');
            }),
            array('db' => 'firstname', 'dt' => 3),
            array('db' => 'lastname', 'dt' => 4),
            array('db' => 'posted_user', 'dt' => 5),
            array('db' => 'created', 'dt' => 6),
            array(
                'db' => 'user_disabled', 'dt' => 7, 'formatter' => function ($d, $row) {
                    if ($row['user_disabled'] == 1) {
                        return "<a href='#' data-toggle='modal' id='edit-user' data-target='#modal' class='btn btn-success btn-sm' onclick=\"editUser('$row[username]')\" class='btn btn-success btn-sm' style='margin-top:-10px'><i class='fa fa-pencil-alt'></i> Edit</a> 
                        <label class='form-switch'><input type='checkbox' onclick=\"javascript:enable_disable('$row[username]')\"><i></i></label>";
                    } else {
                        return "<a href='#' data-toggle='modal' id='edit-user' data-target='#modal' class='btn btn-success btn-sm' onclick=\"editUser('$row[username]')\" class='btn btn-success btn-sm' style='margin-top:-10px'><i class='fa fa-pencil-alt'></i>Edit</a> 
                        <label class='form-switch'><input type='checkbox' checked onclick=\"javascript:enable_disable('$row[username]')\"><i></i></label>";
                    }
                }
            ),
        );

        $filter = "";

        $search = $data['searchby'];
        $keyword = $data['keyword'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];

        $search == '' ? $filter = "" : $filter = "AND $search like '%" . $keyword . "%'";
        $filter .= " AND created BETWEEN '$start_date' AND '$end_date'";

        if ($_SESSION['pts_role_id_sess'] == 001) {
            $filter .= "";
        } else if ($_SESSION['pts_role_id_sess'] == 501) {
            $filter .= " AND role_id != '001' AND role_id != '501'";
        } else {
            $filter .= " AND role_id != '001' AND role_id != '501'";
        }
        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
    }

    public function licenseOperator($data)
    {
        $table_name = "license_operator";
        $primary_key = "operator_id";
        $columner = array(
            array('db' => 'operator_id', 'dt' => 0,),
            array('db' => 'operator_id', 'dt' => 1, 'formatter' => function ($d, $row) {
                return "<div class='custom-control custom-checkbox'>
                        <input type='checkbox' name='chkopt[]' value='$row[operator_id]' class='custom-control-input chk' id='$row[operator_id]'><label class='custom-control-label' for='$row[operator_id]'></label>
                </div>";
            }),
            array('db' => 'name', 'dt' => 2),
            array('db' => 'rc_no', 'dt' => 3),
            array('db' => 'email', 'dt' => 4),
            array('db' => 'phone_no', 'dt' => 5),
            array('db' => 'council', 'dt' => 6),
            array('db' => 'posted_user', 'dt' => 7),
            array('db' => 'created_at', 'dt' => 8),
            array('db' => 'is_disabled', 'dt' => 9,  'formatter' => function ($d, $row) {
                return $d==0?"<span class='text-success'>Active</span>":"<span class='text-danger'>Inactive</span>";
            }),
            array(
                'db' => 'is_disabled', 'dt' => 10, 'formatter' => function ($d, $row) {
                    $edit_btn = "<a href='#' data-toggle='modal' id='edit-operator' data-target='#operator-modal' class='btn btn-success btn-sm' onclick=\"editLicenseOperator('$row[operator_id]')\"><i class='fa fa-pencil-alt'></i> Edit</a>";

                    if ($row['is_disabled'] == 1) {
                        return "$edit_btn <label class='form-switch'><input type='checkbox' id='operator-$row[operator_id]' onclick=\"javascript:enableLicenseOperator('$row[operator_id]', 'operator-$row[operator_id]')\"><i></i></label>";
                    } else {
                        return "$edit_btn <label class='form-switch'><input type='checkbox' checked id='operator-$row[operator_id]' onclick=\"javascript:disableLicenseOperator('$row[operator_id]', 'operator-$row[operator_id]')\"><i></i></label>";
                    }
                },
            ),
        );
        $filter = "";
        $search = $data['searchby'];
        $keyword = $data['keyword'];

        $search == '' ? $filter = "" : $filter = "AND $search like '%" . $keyword . "%'";
        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
    }

    public function officers($data)
    {
        $table_name = "userdata";
        $primary_key = "username";
        $columner = array(
            array('db' => 'role_id', 'dt' => 0),
            array('db' => 'username', 'dt' => 1),
            array('db' => 'role_id', 'dt' => 2, 'formatter' => function ($d, $row) {
                return $this->getItemLabel('role', 'role_id', $d, 'role_name');
            }),
            array('db' => 'firstname', 'dt' => 3),
            array('db' => 'lastname', 'dt' => 4),
            array('db' => 'posted_user', 'dt' => 5),
            array('db' => 'created', 'dt' => 6),
            array(
                'db' => 'user_disabled', 'dt' => 7, 'formatter' => function ($d, $row) {
                    $actions = "<a href='#' data-toggle='modal' id='edit-user' data-target='#modal' class='btn btn-success btn-sm' onclick=\"editUser('$row[username]')\" style='margin-top:-10px'><i class='fa fa-pencil-alt'></i> Edit</a>";
                    if ($row['user_disabled'] == 1)
                    {
                        $actions .= "&nbsp;<label class='form-switch'><input type='checkbox' onclick=\"javascript:enable_disable('$row[username]')\"><i></i></label>";
                    } else {
                        $actions .= "&nbsp;<label class='form-switch'><input type='checkbox' checked onclick=\"javascript:enable_disable('$row[username]')\"><i></i></label>";
                    }
                    ///enable reset password for admin roles
                    $admin_roles    = $this->getAdminRoles('drts');
                    $current_role   = $_SESSION['pts_role_id_sess'];
                    if( in_array($current_role,$admin_roles) )
                    {
                        $actions    .= "&nbsp;<a href='#'  id='reset-user' class='btn btn-warning btn-sm' onclick=\"resetUserPassword('$row[username]')\"  style='margin-top:-10px'><i class='fa fa-recycle'></i> Reset Password</a>";
                    }
                    return $actions;
                }
            ),
        );

        $filter = "";

        $search = $data['searchby'];
        $keyword = $data['keyword'];

        $operator   = trim($_SESSION['pts_license_operator']);
        $user_role  = $_SESSION['pts_role_id_sess'];
        $registration_centre_code = $_SESSION['pts_registration_centre_code'];
        $search == '' ? $filter = "" : $filter = "AND $search like '%" . $keyword . "%'";
        if ($_SESSION['pts_role_id_sess'] == '001') {//system admin i.e. ASL
            $filter .= "";
        } 
        else if ($_SESSION['pts_role_id_sess'] == '501') {///global admin
            $filter .= " AND role_id <> '001' AND role_id <> '501'";
        }
        else if ($_SESSION['pts_role_id_sess'] == '502') {///DRTS staff
            $filter .= " AND role_id ='$user_role' AND registration_centre = '$registration_centre_code'";
        }
        else if ($_SESSION['pts_role_id_sess'] == '503') {///licensed operator staff
            $filter .= " AND role_id ='$user_role' AND license_operator = '$operator'";
        }
        else if ($_SESSION['pts_role_id_sess'] == '507') {///DRTS administrator
            $filter .= " AND role_id <> '001' AND role_id <> '501'";
        }
        else if ($_SESSION['pts_role_id_sess'] == '508') {//licensed operator admin
            $filter .= " AND role_id <> '001' AND role_id <> '501' AND license_operator = '$operator'";
        } 
        else if ($_SESSION['pts_role_id_sess'] == '509') {//DRTS centre admin
            $filter .= " AND role_id <> '001' AND role_id <> '501' AND registration_centre = '$registration_centre_code'";
        } 
        else {
            $filter .= " AND role_id = '$user_role'";
        }
        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
    }

    public function auditTrail($data)
    {
        $table_name = "audit_trail";
        $primary_key = "audit_id";
        $columner = array(
            array('db' => 'audit_id', 'dt' => 0,),
            array('db' => 'audit_id', 'dt' => 1,),
            array('db' => 'action', 'dt' => 2),
            array('db' => 'action', 'dt' => 3, 'formatter' => function ($d, $row) {
                $table_name = explode('=>', $d);
                return $table_name[1];
            }),
            array('db' => 'audit_id', 'dt' => 4, 'formatter' => function ($d, $row) {
                return "<a id=\"view\" data-toggle=\"modal\" data-target=\"#auditModal\" onclick=\"auditDetail('$row[audit_id]')\" class=\"btn btn-success text-white vw\">View</a>";
            }),
            array('db' => 'audit_by', 'dt' => 5),
            array('db' => 'date', 'dt' => 6),
        );
        $filter = "";
        $search = $data['searchby'];
        $keyword = $data['keyword'];

        $search == '' ? $filter = "" : $filter = "AND $search like '%" . $keyword . "%'";
        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
    }

    public function multi_report($data)
    {
        $table_name = "bio_data";
        $primary_key = "application_no";
        $columner = array(
            array('db' => 'application_no', 'dt' => 0),
            array('db' => 'application_no', 'dt' => 1, 'formatter' => function ($d, $row) {
                return '<input type="checkbox" name="chkopt" class="app_id" onclick = "ff()" data = "' . $row[application_no] . '" value="' . $row[application_no] . '"  />';
            }),
            array('db' => 'application_no', 'dt' => 2),
            array('db' => 'first_name', 'dt' => 3),
            array('db' => 'surname', 'dt' => 4),
            array('db' => 'mobile_no', 'dt' => 5),
            array('db' => 'state_of_origin', 'dt' => 6),
            array('db' => 'test_location', 'dt' => 7),
            array('db' => 'application_no', 'dt' => 8, 'formatter' => function ($d, $row) {
                $re = $this->dbQuery("SELECT degree_class FROM degree_class WHERE id = (SELECT grade_obtained FROM degree_cert WHERE app_id = '$d')");
                return $re[0][degree_class];
            }),
            array('db' => 'end_date', 'dt' => 9, 'formatter' => function ($d, $row) {

                return $d;
            }),
            array('db' => 'sex', 'dt' => 10),
            array('db' => 'reviewer_id', 'dt' => 11),
            array('db' => 'applicant_status', 'dt' => 12, 'formatter' => function ($d, $row) {
                $state = "";
                if ($row['applicant_status'] == "1") {
                    $state = "Shortlisted";
                } elseif ($row['applicant_status'] == "2") {
                    $state = "Disqualified";
                } elseif ($row['applicant_status'] == "4") {
                    $state = "Escalated";
                } elseif ($row['applicant_status'] == "0") {
                    $state = "Pending";
                }
                return $state;
            }),
            array('db' => 'application_no', 'dt' => 13, 'formatter' => function ($d, $row) {

                if ($row['applicant_status'] == "1") {
                    $sh = "<a class='dropdown-item' href='javascript:void(0)' onclick=\"take_action_sngl('discard_appl','" . $d . "')\"><i class='fa fa-times'></i> Disqualify Applicant</a>";
                } elseif ($row['applicant_status'] == "2") {
                    $sh = "<a class='dropdown-item' href='javascript:void(0)' onclick=\"take_action_sngl('shortlist_action','" . $d . "')\"><i class='fa fa-check'></i> Shortlist Applicant</a>";
                } else {
                    $sh = "<a class='dropdown-item' href='javascript:void(0)' onclick=\"take_action_sngl('shortlist_action','" . $d . "')\"><i class='fa fa-check'></i> Shortlist Applicant</a><a class='dropdown-item' href='javascript:void(0)' onclick=\"take_action_sngl('discard_appl','" . $d . "')\"><i class='fa fa-times'></i> Disqualify Applicant</a>";
                }
                return '<div class="dropdown">
								  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton' . $d . '" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									<i class="fa fa-list" aria-hidden="true"></i>
								  </button>
								  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton' . $d . '">
									' . $sh . '
								  </div>
								</div>';
            }),
            array('db' => 'application_no', 'dt' => 14, 'formatter' => function ($d, $row) {
                return "<a href='javascript:void(0)' class='btn btn-success' onclick = \"getPage('reviewer_applicant_profile.php?id=" . $d . "&return_page=multi_page.php','page')\"><i class='fa fa-user'></i> view profile</a> ";
            }),
        );

        $filter = "";
        if ($data['dob'] != null) {
            $filter = $filter . " AND age = '$data[dob]' ";
        }
        if ($data['positions'] != "") {
            $filter = $filter . " AND entry_position = '$data[positions]' ";
        }
        if ($data['gender'] != "") {
            $filter = $filter . " AND sex = '$data[gender]' ";
        }
        if ($data['yr_grad'] != "") {
            //            $filter = $filter." AND end_date = '$data[yr_grad]' ";
        }
        if ($data['mobile_no'] != "") {
            $filter = $filter . " AND mobile_no = '$data[mobile_no]' ";
        }
        if ($data['state_of_origin'] != null) {
            $filter = $filter . " AND state_of_origin = '$data[state_of_origin]' ";
        }
        if ($data['first_name'] != "") {
            $filter = $filter . " AND first_name = '$data[first_name]' ";
        }
        if ($data['surname'] != "") {
            $filter = $filter . " AND surname = '$data[surname]' ";
        }
        if ($data['test_location'] != "") {
            $filter = $filter . " AND test_location = '$data[test_location]' ";
        }
        if ($data['deg_class'] != "") {
            //            $filter = $filter." AND grade_obtained = '$data[deg_class]' ";
        }

        $filter = $filter . "  AND approve_record='1'  ";
        $join_type = "JOIN";
        $join_arr = array(array('degree_cert' => array('application_no', 'app_id')));
        echo $this->generic_multi_table($data, $table_name, $columner, $filter, $primary_key, $join_arr, $join_type);
    }

    public function multi_report1($data)
    {
        $table_name = "menu";
        $primary_key = "menu_id";
        $columner = array(
            array('db' => 'menu_id', 'dt' => 0),
            array('db' => 'menu_id', 'dt' => 1),
            array('db' => 'menu_name', 'dt' => 2),
            array('db' => 'menu_url', 'dt' => 3),
            array('db' => 'parent_id', 'dt' => 4),
            array('db' => 'parent_id2', 'dt' => 5),
            array('db' => 'menu_level', 'dt' => 6),
            array('db' => 'created', 'dt' => 7)
        );

        $filter = "";

        $join_type = "JOIN";
        $join_arr = array(array('role' => array('menu_id', 'role_id')));
        echo $this->generic_multi_table($data, $table_name, $columner, $filter, $primary_key, $join_arr, $join_type);
    }
    
    /////Tosin 02-11-20
    public function station($data)
    {
        $table_name = "station";
        $primary_key = "station_code";
        $columner = array(
            array('db' => 'station_code', 'dt' => 0),
            array('db' => 'station_code', 'dt' => 1),
            array('db' => 'station_name', 'dt' => 2),
            // array('db' => 'role_enabled', 'dt' => 3),
            array('db' => 'created', 'dt' => 3),
            array(
                'db' => 'station_code', 'dt' => 4, 'formatter' => function ($d, $row) {
                    return "<a href='#' data-toggle='modal' id='edit-centre' data-target='#modal' class='btn btn-success btn-sm' onclick=\"saveCentre('$d')\"><i class='fa fa-pencil-alt'></i> Edit</a>&nbsp;<button onclick=\"deleteCentre('$d')\" class='btn btn-danger btn-sm'><i class='fa fa-trash'></i> Delete</button>";
                },
            ),
        );
        $filter = "";
        $search = $data['searchby'];
        $keyword = $data['keyword'];

        $search == '' ? $filter = "" : $filter = "AND $search like '%" . $keyword . "%'";

        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
    }
    public function riderList($data)
    {
        $table_name = "tbl_riders";
        $primary_key = "rcn";
        $reg_status = '';
        $columner = array(
            array('db' => 'rcn', 'dt' => 0),
            array('db' => 'nin', 'dt' => 1, 'formatter' => function ($d, $row) {
                return "<div class='custom-control custom-checkbox'><input type='checkbox' name='chkopt[]' value='$row[nin]' class='custom-control-input chk' id='$row[nin]'><label class='custom-control-label' for='$row[nin]'></label></div>";
            }),
            array('db' => 'rcn', 'dt' => 2),
            array('db' => 'title', 'dt' => 3),
            array('db' => 'surname', 'dt' => 4),
            array('db' => 'firstname', 'dt' => 5),
            array('db' => 'gender', 'dt' => 6),
            array('db' => 'phone_no', 'dt' => 7),
            array('db' => 'license_no', 'dt' => 8),
            array('db' => 'license_expiry_date', 'dt' => 9),
            array('db' => 'native_lang', 'dt' => 10),
            array('db' => 'license_operator', 'dt' => 11, 'formatter' => function ($d, $row) {
                $lic_name = $this->getItemLabel('license_operator','operator_id',$d,'name');
                return $lic_name!=''?$lic_name:"NIL";
            }),
            array('db' => 'created', 'dt' => 12),
            array('db' => 'is_active', 'dt' => 13, 'formatter' => function ($d, $row) {
                    $drts_admin_roles   = $this->getAdminRoles('drts');
                    
                    $approve_btn = "<a href='#' class='btn btn-info btn-sm' data-toggle='modal' id='view-rider-info' data-target='#rider-modal' onclick=\"viewRiderInfo('$row[rcn]')\"><i class='fa fa-eye'></i> View Rider Info <?php echo $row[is_active] ;?></a> ";
                    // drts admin
                    if(in_array($_SESSION['pts_role_id_sess'],$drts_admin_roles)&&$d==0) {
                    //if($_SESSION['pts_role_id_sess']=='502'&&$d==0){
                        $approve_btn .= "<a href='#' class='btn btn-success btn-sm' onclick=\"approveRider('$row[rcn]')\"><i class='fa fa-check'></i> Activate Rider</a>";
                    } else if (in_array($_SESSION['pts_role_id_sess'],$drts_admin_roles)&&$d==1) {
                    //}else if($_SESSION['pts_role_id_sess']=='502'&&$d==1){
                        $approve_btn .= "<a href='#' class='btn btn-danger btn-sm' onclick=\"disApproveRider('$row[rcn]')\"><i class='fa fa-check'></i> De-activate Rider</a> ";
                        
                        $id = base64_encode($row['rcn']);
                        $approve_btn .= "<a href='#' class='btn btn-secondary btn-sm' id='print-rcc' onclick=\"window.open('receipts/rcn.php?q=".$id."')\"><i class='fa fa-print'></i> Print Card</a> ";
                    }
                    return " $approve_btn ";
                },
            ),
        );
        
        $filter = "";
        $search = $data['searchby'];
        $keyword = $data['keyword'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        $role_id = $_SESSION['pts_role_id_sess'];
        $username = trim($_SESSION['pts_username_sess']);
        $operator = trim($_SESSION['pts_license_operator']);

        $search == '' ? $filter = "" : $filter = "AND $search like '%" . $keyword . "%'";
        if ($role_id == '503'||$role_id == '508') {
            $filter .= " AND license_operator = '$operator'";
        } /*else if ($role_id == '501') {
            // $filter .= " AND reg_status = '1'";
        }  else if ($role_id == '509') {
            $filter .= " AND reg_status = '1'";
        } */ 
        else {
            $filter .= "";
        }
        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
    }
    public function vehicleAssignmentList($data)
    {
        //$db = new dbobject();
        $table_name = "tbl_vehicle_assigned_to_rider";
        $primary_key = "license_no";
        $columner = array(
            array('db' => 'license_no', 'dt' => 0),
            array('db' => 'license_no', 'dt' => 1, 'formatter' => function ($d, $row) {
                return "<div class='custom-control custom-checkbox'><input type='checkbox' name='chkopt[]' value='$row[license_no]' class='custom-control-input chk' id='$row[license_no]'><label class='custom-control-label' for='$row[license_no]'></label></div>";
            }),
            array('db' => 'license_no', 'dt' => 2, 'formatter' => function ($d, $row) {
                //file_put_contents('aab.txt','asas');
                return $this->getRiderName($d);
            }),
            array('db' => 'chassis_no', 'dt' => 3, 'formatter' => function ($d, $row) {
                return $this->getItemLabel('vehicle_tbl','chassis_no',$d,'owner_name');
            }),
            array('db' => 'plate_no', 'dt' => 4),
            array('db' => 'rcn', 'dt' => 5),
            array('db' => 'veh_side_no', 'dt' => 6),
            array(
                'db' => 'rcn', 'dt' => 7, 'formatter' => function ($d, $row) {
                    $approve_btn = "<a href='#' class='btn btn-secondary btn-sm' data-toggle='modal' id='view-rider-info' data-target='#rider-modal' onclick=\"viewRiderInfo('$row[rcn]')\"><i class='fa fa-eye'></i> View Rider Info</a> ";
                    $approve_btn .= "<a href='#' class='btn btn-info btn-sm' data-toggle='modal' id='view-vehicle-info' data-target='#vehicle-modal' onclick=\"viewVehicleInfo('$row[chassis_no]')\"><i class='fa fa-eye'></i> View Vehicle Info</a> ";
                    // license operator
                    if ($_SESSION['pts_role_id_sess'] == '503') {
                        $approve_btn .= "<a href='#' class='btn btn-primary btn-sm'  data-toggle='modal' data-target='#unassign-rider' id='".$d."' onclick = \"$('#reason_id').val('".$row[chassis_no]."')\"><i class='fa fa-check'></i> Unassign Vehicle from Rider</a>";
                    }
                    return $approve_btn;
                },
            ),
        );
     
        $filter = "";
        $search = $data['searchby'];
        $keyword = $data['keyword'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        $role_id = $_SESSION['pts_role_id_sess'];
        $username = trim($_SESSION['pts_username_sess']);
        $operator = trim($_SESSION['pts_license_operator']);
        
        $search == '' ? $filter = "" : $filter = "AND $search like '%" . $keyword . "%'";
        // $filter .= " AND created BETWEEN '$start_date' AND '$end_date'";

        if ($role_id == '505') {
            $filter .= " AND owner_username = '$username'";
        } else if ($role_id == '503') {
            $filter .= " AND license_operator = '$operator'";
        } else if ($role_id == '501') {
            // $filter .= " AND reg_status = '1'";
        } else {
            $filter .= "";
        }
        $filter_btwn = 'created';
        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key, $filter_btwn);
    }
    
    public function transactionList($data)
    {
        $table_name = "transaction_table";
        $primary_key = "transaction_id";
        $columner = array(
            array('db' => 'transaction_id', 'dt' => 0),
            array('db' => 'transaction_id', 'dt' => 1, 'formatter' => function ($d, $row) {
                return "<div class='custom-control custom-checkbox'><input type='checkbox' name='chkopt[]' value='$row[transaction_id]' class='custom-control-input chk' id='$row[transaction_id]'><label class='custom-control-label' for='$row[transaction_id]'></label></div>";
            }),
            array('db' => 'transaction_id', 'dt' => 2),
            array('db' => 'rrr', 'dt' => 3),
            array('db' => 'tranx_desc', 'dt' => 4, 'formatter' => function($d, $row) {
                $content    = explode('~',$d);///payer's name
                return $content[0];
            }),
            array('db' => 'tranx_desc', 'dt' => 5, 'formatter' => function($d, $row) {
                $content    = explode('~',$d);///payer's number
                return $content[1];
            }),
            array('db' => 'transaction_desc', 'dt' => 6),
            array('db' => 'trans_type', 'dt' => 7, 'formatter' => function($d, $row) {
                return ucwords(str_replace('_',' ',$d));
            }),
            array('db' => 'transaction_amount', 'dt' => 8, 'formatter' => function($d, $row) {
                return number_format($d,2);
            }),
            array('db' => 'response_code', 'dt' => 9, 'formatter' => function($d, $row) {
                $status = '';
                if($d==99){
                    $status = 'Transaction Initiated';
                }
                else if($d==51){
                    $status = 'Insufficient Funds';
                }
                else if($d=='0'||$d=='00'){
                    $status = 'Successful';
                }
                else if($d=='200'){
                    $status = 'RRR generated';
                }
                else
                {
                    $status = 'Failed';
                }
                return $status;
            }),
            array('db' => 'response_message', 'dt' => 10),
            array('db' => 'settlement_status', 'dt' => 11, 'formatter' => function($d, $row) {
                return $d==0?"Not Used":"Used";
            }),
            array('db' => 'transaction_id', 'dt' => 12, 'formatter' => function($d, $row) {
                $status = $this->getItemLabel('tbl_training_schedule','training_id',$d,'training_done')==0?'<p class="text-warning">NO</p>':'<p class="text-success">YES</p>';
                return $status;
            }),
            array('db' => 'created', 'dt' => 13),
            array(
                'db' => 'transaction_id', 'dt' => 14, 'formatter' => function ($d, $row) {
                    $id = base64_encode($d);
                    $approve_btn = "<a href='#' class='btn btn-info btn-sm' id='print-trans-receipt' onclick=\"window.open('receipts/payment.php?id=".$id."')\"><i class='fa fa-print'></i> Reprint Receipt</a> ";
                    if($row['response_code']!='0'&&$row['response_code']!='00')
                    {
                        $approve_btn .= "<a href='#' class='btn btn-warning btn-sm' id='requery-trans' onclick=\"requeryTransactionStatus('".$d."')\"><i class='fa fa-refresh'></i> Re-query Status</a> ";   
                    }
                    return $approve_btn;
                },
            ),
        );
        
        $filter = " AND trans_type !='ref_trn' ";
        $search = $data['searchby'];
        $keyword = $data['keyword'];
        // $search1 = $data['searchby1'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        $role_id = $_SESSION['pts_role_id_sess'];
        $username = trim($_SESSION['pts_username_sess']);
        $operator = trim($_SESSION['pts_license_operator']);
        
        $search == '' ? $filter .= "" : $filter .= " AND $search like '%" . $keyword . "%'";
        // $filter .= " AND created BETWEEN '$start_date' AND '$end_date'";
        // $search1 == '' ? $filter = "" : $filter .= "AND response_code = '$search1'";
        /*if ($role_id == '505') {
            $filter .= " AND owner_username = '$username'";
        } else */if ($role_id == '503') {
            $filter .= " AND source_acct = '$username'";
        } /*else if ($role_id == '501') {
            // $filter .= " AND reg_status = '1'";
        }*/ else {
            $filter .= "";
        }

        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
    }
    public function vehicleRevalidationList($data)
    {
        $table_name = "vehicle_tbl";
        $primary_key = "chassis_no";
        $reg_status = '';
        $columner = array(
            array('db' => 'chassis_no', 'dt' => 0),
            array('db' => 'chassis_no', 'dt' => 1, 'formatter' => function ($d, $row) {
                return "<div class='custom-control custom-checkbox'><input type='checkbox' name='chkopt[]' value='$row[chassis_no]' class='custom-control-input chk' id='$row[chassis_no]'><label class='custom-control-label' for='$row[chassis_no]'></label></div>";
            }),
            array('db' => 'chassis_no', 'dt' => 2),
            array('db' => 'plate_no', 'dt' => 3),
            array('db' => 'veh_side_no', 'dt' => 4),
            array('db' => 'veh_license_end_date', 'dt' => 5),
            array(
                'db' => 'chassis_no', 'dt' => 6, 'formatter' => function ($d, $row) {
                    $approve_btn = "<a href='#' class='btn btn-info btn-sm' data-toggle='modal' id='view-vehicle-info'  onclick=\"reValidateVehicle('$row[chassis_no]')\"><i class='fa fa-eye'></i> Re-certify Vehicle</a> ";
                    return " $approve_btn ";
                },
            ),
        );
        $filter = " AND veh_license_end_date <= CURDATE() OR veh_license_end_date IS NULL";
        $search = $data['searchby'];
        $keyword = $data['keyword'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        $role_id = $_SESSION['pts_role_id_sess'];
        $username = trim($_SESSION['pts_username_sess']);
        $operator = trim($_SESSION['pts_license_operator']);
        
        $search == '' ? $filter .= "" : $filter .= "AND $search like '%" . $keyword . "%'";
        // $filter .= " AND created BETWEEN '$start_date' AND '$end_date'";


        echo $this->generic_table_NoDate($data, $table_name, $columner, $filter, $primary_key);
    }
    public function trainingScheduleList($data)
    {
        $table_name = "tbl_training_schedule";
        $primary_key = "training_id";
        $reg_status = '';
        $columner = array(
            array('db' => 'training_id', 'dt' => 0),
            array('db' => 'training_date', 'dt' => 1, 'formatter' => function ($d, $row) {
                return date("l, jS \of F, Y ",strtotime($d));
            }),
            array('db' => 'COUNT(training_id)', 'dt' => 2),
            array('db' => 'training_date', 'dt' => 3, 'formatter' => function ($d, $row) {
                    $approve_btn = "<a href='#' onclick='downloadTrainingSchedule(".strtotime($d).")' class='btn btn-info btn-sm'id='download-training-schedule'><i class='fa fa-print'></i> Download Schedule</a> ";
                    return " $approve_btn ";
                },
            ),
        );
        $filter = " GROUP BY training_date";
        $search = $data['searchby'];
        $keyword = $data['keyword'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        /*$role_id = $_SESSION['pts_role_id_sess'];
        $username = trim($_SESSION['pts_username_sess']);
        $operator = trim($_SESSION['pts_license_operator']);*/
        
        $search == '' ? $filter .= "" : $filter .= "AND $search like '%" . $keyword . "%'";
        // $filter .= " AND created BETWEEN '$start_date' AND '$end_date'";


        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
    }
    public function rescheduleTrainingList($data)
    {
        $table_name = "tbl_training_schedule";
        $primary_key = "training_id";
        $reg_status = '';
        $columner = array(
            array('db' => 'training_id', 'dt' => 0),
            array('db' => 'training_id', 'dt' => 1),
            array('db' => 'training_id', 'dt' => 2, 'formatter' => function ($d, $row) {
                $pdetails = explode('~',$this->getItemLabel('transaction_table','transaction_id',$d,'tranx_desc'));
                return $pdetails[0];
            }),
            array('db' => 'training_date', 'dt' => 3),
            array('db' => 'reschedule_count', 'dt' => 4, 'formatter' => function ($d, $row) {
                    $status = '';
                    switch($d)
                    {
                        case 0:
                            $status = 'NO';
                            break;
                        case 1:
                            $status = 'ONCE';
                            break;
                        case 2:
                            $status = 'TWICE';
                            break;
                        default:
                            $status = 'SEVERALLY';
                            break;
                    }
                    return $status;
                }), 
            array('db' => 'training_id', 'dt' => 5, 'formatter' => function ($d, $row) {
                    $approve_btn = "<a href='#' onclick='reScheduleTraining(\"".$d."\")' class='btn btn-info btn-sm' id='reschedule-training'><i class='fa fa-refresh'></i> Re-schedule</a> ";
                    return " $approve_btn ";
                }),
        );
        $filter = " AND training_done = 0";
        $search = $data['searchby'];
        $keyword = $data['keyword'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        
        $search == '' ? $filter .= "" : $filter .= "AND $search like '%" . $keyword . "%'";
        // $filter .= " AND created BETWEEN '$start_date' AND '$end_date'";


        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
    }
    public function confirmTrainingList($data)
    {
        $table_name = "tbl_training_schedule";
        $primary_key = "training_id";
        $reg_status = '';
        $columner = array(
            array('db' => 'training_id', 'dt' => 0),
            array('db' => 'training_id', 'dt' => 1),
            array('db' => 'training_id', 'dt' => 2, 'formatter' => function ($d, $row) {
                $pdetails = explode('~',$this->getItemLabel('transaction_table','transaction_id',$d,'tranx_desc'));
                return $pdetails[0];
            }),
            array('db' => 'training_id', 'dt' => 3, 'formatter' => function ($d, $row) {
                    $payment_date = date("jS F Y",strtotime($this->getItemLabel('transaction_table','transaction_id',$d,'created')));
                    return $payment_date;
                }),
            array('db' => 'training_date', 'dt' => 4, 'formatter' => function ($d, $row) {
                    $payment_date = date("jS F Y",strtotime($d));
                    return $payment_date;
                }), 
            array('db' => 'expiry_date', 'dt' => 5, 'formatter' => function ($d, $row) {
                $validity = '<p class="text-danger">Expired</p>';
                if(strtotime($d)>strtotime(date('Y-m-d')))
                {
                    $validity = '<p class="text-success">Valid</p>';
                }
                return $validity;
            }),
            array('db' => 'training_id', 'dt' => 6, 'formatter' => function ($d, $row) {
                    $approve_btn = "<a href='#' onclick='validateApplicantEligibility(\"".$d."\")' class='btn btn-info btn-sm' id='validate-4-training'><i class='fa fa-question'></i> Validate Eligibility</a> ";
                    $exp_date = strtotime($this->getItemLabel('tbl_training_schedule','training_id',$d,'expiry_date'));
                    $drts_admin_roles = $this->getAdminRoles('drts'); 

                    if($exp_date>strtotime(date('Y-m-d'))||in_array($_SESSION['pts_role_id_sess'],$drts_admin_roles))///exempt for admin
                    {
                        $approve_btn .= "&nbsp|&nbsp;<a href='#' onclick='confirmApplicantTraining(\"".$d."\")' class='btn btn-warning btn-sm' id='confirm-training'><i class='fa fa-check'></i> Confirm Applicant Training</a> ";
                    }
                    return " $approve_btn ";
                }),
        );
        $filter = " AND training_done = 0";
        $search = $data['searchby'];
        $keyword = $data['keyword'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        
        $search == '' ? $filter .= "" : $filter .= "AND $search like '%" . $keyword . "%'";
        // $filter .= " AND created BETWEEN '$start_date' AND '$end_date'";


        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
    }
    public function trainingSessionSetupList($data)
    {
        $table_name = "tbl_training_setup";
        $primary_key = "id";
        $columner = array(
            array('db' => 'id', 'dt' => 0),
            array('db' => 'session_id', 'dt' => 1),
            array('db' => 'slated_time', 'dt' => 2),
            array('db' => 'capacity', 'dt' => 3),
            array('db' => 'id', 'dt' => 4, 'formatter' => function ($d, $row) {
                return "<a href='#' data-toggle='modal' id='edit-trn-sess' data-target='#trn-sess' class='btn btn-success btn-sm' onclick=\"editTrainingSession('$row[id]')\"><i class='fa fa-pencil-alt'></i> Edit</a>";
                },
            ),
        );
        $filter = " ";
        $search = $data['searchby'];
        $keyword = $data['keyword'];
        $start_date = (isset($data['start_date']) && $data['start_date'] != "")?$data['start_date']: date('Y-m-d', strtotime('- 6 years'));
        $end_date = (isset($data['end_date']) && $data['end_date'] != "")?$data['end_date']:date('Y-m-d');
        
        $search == '' ? $filter .= "" : $filter .= "AND $search like '%" . $keyword . "%'";
        // $filter .= " AND created BETWEEN '$start_date' AND '$end_date'";


        echo $this->generic_table_NoDate($data, $table_name, $columner, $filter, $primary_key);
    }
    public function certifiedApplicantsList($data)
    {
        $table_name = "tbl_training_schedule";
        $primary_key = "training_id";
        $reg_status = '';
        $columner = array(
            array('db' => 'training_id', 'dt' => 0),
            array('db' => 'training_id', 'dt' => 1),
            array('db' => 'training_date', 'dt' => 2),
            array('db' => 'session', 'dt' => 3),
            array('db' => 'confirmation_code', 'dt' => 4),
            array('db' => 'confirmed_date', 'dt' => 5),
            array('db' => 'confirmed_by', 'dt' => 6),
            array('db' => 'training_id', 'dt' =>7, 'formatter' => function ($d, $row) {
                    $pin = $this->getitemlabel('transaction_table','transaction_id',$d,'order_id');
                    $rec = $this->getRecordSet('tbl_riders','pin',$pin);
                    return count(array($rec))>0?"<span class=\"text-success\">YES</span>":"<span class=\"text-danger\">NO</span>";
                }), 
        );
        $filter = " AND training_done = 1 ";
        $search = $data['searchby'];
        $keyword = $data['keyword'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        
        $search == '' ? $filter .= "" : $filter .= "AND $search like '%" . $keyword . "%'";
        // $filter .= " AND created BETWEEN '$start_date' AND '$end_date'";


        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
    }
    public function printFarm($data)
    {
        $table_name = "tbl_riders";
        $primary_key = "rcn";
        $categories_4_permanent_card = "'rider_reg','rider_motorcycle','rider_tricycle'";
        $columner = array(
            array('db' => 'rcn', 'dt' => 0),
            array('db' => 'rcn', 'dt' => 1, 'formatter' => function ($d, $row) {
                return "<div class='custom-control custom-checkbox'><input type='checkbox' name='chkopt[]' value='$d' class='custom-control-input chk' id='$d'><label class='custom-control-label' for='$d'></label></div>";
            }),
            array('db' => 'rcn', 'dt' => 2),
            array('db' => 'nin', 'dt' => 3, 'formatter' => function ($d, $row) {
                      return $this->maskStr($d,4,8);
                  }),
            array('db' => 'title', 'dt' => 4),
            array('db' => 'surname', 'dt' => 5),
            array('db' => 'firstname', 'dt' => 6),
            array('db' => 'gender', 'dt' => 7),
            array('db' => 'phone_no', 'dt' => 8),
            array('db' => 'created', 'dt' => 9),
            array('db' => 'rcn', 'dt' => 10, 'formatter' => function ($d, $row) {
                    $id = base64_encode($d);
                    $approve_btn = "<a href='#' class='btn btn-dark btn-sm' id='print-rcc' onclick=\"markRCCAsPrinted('$d')\"><i class='fa fa-tasks'></i>Mark as Printed</a> ";
                    return $approve_btn ;
                },
            ),
        );
        
        $filter = " AND print_farm = 0 AND rider_category IN ($categories_4_permanent_card) ";
        $search = $data['searchby'];
        $keyword = $data['keyword'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        /*$role_id = $_SESSION['pts_role_id_sess'];
        $username = trim($_SESSION['pts_username_sess']);*/

        $search == '' ? $filter .= "" : $filter .= "AND $search like '%" . $keyword . "%'";

        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
    }
    public function referalList($data)
    {

        $table_name = "offenders";
        $primary_key = "id";
        $columner = array(
            array( 'db' => 'id', 'dt' => 0 ),
            array( 'db' => 'name',  'dt' => 1 ),
            array( 'db' => 'plate',  'dt' => 2 ),
            array( 'db' => 'nin',  'dt' => 3 ),
            array( 'db' => 'phone',   'dt' => 4),
            array( 'db' => 'address',   'dt' => 5 ),
            array( 'db' => 'gender',   'dt' => 6),
            array( 'db' => 'vehtype',   'dt' => 7),
            array( 'db' => 'location',   'dt' => 8 ),
            array( 'db' => 'date',   'dt' => 9)
        );
        
        $filter = "";
        $search = $data['searchby'];
        $keyword = $data['keyword'];

        $filter_btwn = 'date'; //please leave emp

        $filter .=  ($search == '') ? '': " AND $search like '%" . $keyword . "%'";

        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key, $filter_btwn);
    }
    public function reftransactionList($data)
    {
        $table_name = "transaction_table";
        $primary_key = "transaction_id";
        $columner = array(
            array('db' => 'transaction_id', 'dt' => 0),
            array('db' => 'transaction_id', 'dt' => 1, 'formatter' => function ($d, $row) {
                return "<div class='custom-control custom-checkbox'><input type='checkbox' name='chkopt[]' value='$row[transaction_id]' class='custom-control-input chk' id='$row[transaction_id]'><label class='custom-control-label' for='$row[transaction_id]'></label></div>";
            }),
            array('db' => 'transaction_id', 'dt' => 2),
            array('db' => 'rrr', 'dt' => 3),
            array('db' => 'tranx_desc', 'dt' => 4, 'formatter' => function($d, $row) {
                $content    = explode('~',$d);///payer's name
                return $content[0];
            }),
            array('db' => 'tranx_desc', 'dt' => 5, 'formatter' => function($d, $row) {
                $content    = explode('~',$d);///payer's number
                return $content[1];
            }),
            array('db' => 'transaction_desc', 'dt' => 6),
            array('db' => 'trans_type', 'dt' => 7, 'formatter' => function($d, $row) {
                return ucwords(str_replace('_',' ',$d));
            }),
            array('db' => 'transaction_amount', 'dt' => 8, 'formatter' => function($d, $row) {
                return number_format($d,2);
            }),
            array('db' => 'rrr', 'dt' => 9, 'formatter'=> function($d, $row){
                $sql = "SELECT * FROM offenders WHERE pin = '$d'";
                $res = $this->dbQuery($sql);
                return $res[0]['location'];
            }),
            array('db' => 'response_code', 'dt' => 10, 'formatter' => function($d, $row) {
                $status = '';
                if($d==99){
                    $status = 'Transaction Initiated';
                }
                else if($d==51){
                    $status = 'Insufficient Funds';
                }
                else if($d=='0'||$d=='00'){
                    $status = 'Successful';
                }
                else if($d=='200'){
                    $status = 'RRR generated';
                }
                else
                {
                    $status = 'Failed';
                }
                return $status;
            }),
            array('db' => 'response_message', 'dt' => 11),
            array('db' => 'settlement_status', 'dt' => 12, 'formatter' => function($d, $row) {
                return $d==0?"Not Used":"Used";
            }),
            array('db' => 'created', 'dt' => 13),
            array(
                'db' => 'transaction_id', 'dt' => 14, 'formatter' => function ($d, $row) {
                    $id = base64_encode($d);
                    $approve_btn = "<a href='#' class='btn btn-info btn-sm' id='print-trans-receipt' onclick=\"window.open('receipts/payment.php?id=".$id."')\"><i class='fa fa-print'></i> Reprint Receipt</a> ";
                    if($row['response_code']!='0'&&$row['response_code']!='00')
                    {
                        $approve_btn .= "<a href='#' class='btn btn-warning btn-sm' id='requery-trans' onclick=\"requeryTransactionStatus('".$d."')\"><i class='fa fa-refresh'></i> Re-query Status</a> ";   
                    }
                    return $approve_btn;
                },
            ),
        );
        
        $filter = "";
        $search = $data['searchby'];
        $keyword = isset($data['keyword']);
        $start_date = (isset($data['start_date']) && $data['start_date'] != "")?$data['start_date']: date('Y-m-d', strtotime('- 6 years'));
        $end_date = (isset($data['end_date']) && $data['end_date'] != "")?$data['end_date']:date('Y-m-d');
        $role_id = $_SESSION['pts_role_id_sess'];
        $username = trim($_SESSION['pts_username_sess']);
        $operator = trim($_SESSION['pts_license_operator']);
        
        $search == '' ? $filter = "" : $filter .= "AND response_code = '$search'";
        // $filter .= " AND created BETWEEN '$start_date' AND '$end_date'";

        /*if ($role_id == '505') {
            $filter .= " AND owner_username = '$username'";
        } else */if ($role_id == '503') {
            $filter .= " AND source_acct = '$username'";
        } /*else if ($role_id == '501') {
            // $filter .= " AND reg_status = '1'";
        }*/ else {
            $filter .= " AND trans_type = 'ref_trn'";
        }

        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
    }
    public function Incomplete($data)
    {
        $table_name = "tbl_riders";
        $primary_key = "rcn";
        $reg_status = '';
        $columner = array(
            array('db' => 'rcn', 'dt' => 0),
            array('db' => 'rcn', 'dt' => 1, 'formatter' => function($d, $row){
                if ($row['rcn'] == '' || $row['title'] == '' || $row['surname'] == '' || $row['firstname'] == '' || $row['gender'] == '' || $row['phone_no'] == '' || $row['native_lang'] == '' || $row['nin'] == '' || $row['othername'] == '' || $row['birthdate'] == '' || $row['blood_group'] == '' || $row['marital_status'] == '' || $row['nationality'] == '' || $row['edu_qual'] == '' || $row['contact_addr'] == '' || $row['email_address'] == '' || $row['pob'] == '' || $row['lga_origin'] == '' || $row['home_origin'] == '' || $row['state_origin'] == '' || $row['address_residence'] == '' || $row['birthcountry'] == '' || $row['birthlga'] == '' || $row['height'] == '' || $row['employment_status'] == '' || $row['profession'] == '' || $row['religion'] == '' || $row['residence_status'] == '' || $row['residence_town'] == '' || $row['residence_lga'] == '' || $row['residence_state'] == '' || $row['nok_spokenlang'] == '' || $row['nok_town'] == '' || $row['nok_firstname'] == '' || $row['nok_state'] == '' || $row['nok_surname'] == '' || $row['nok_middlename'] == '' || $row['nok_lga'] == '' || $row['nok_address1'] == '' || $row['nok_address2'] == '') {
                    return "$d | <a href='#' data-toggle='modal' id='edit-role' data-target='#modal' class='btn btn-warning btn-sm' onclick=\"getPage('incomplete_data_setup.php?rcn=$d','box')\"><i class='fa fa-pencil-alt'></i> Update Info</a>";
                } else {
                   return $d; 
                }
            }),
            array('db' => 'title', 'dt' => 2),
            array('db' => 'surname', 'dt' => 3),
            array('db' => 'firstname', 'dt' => 4),
            array('db' => 'gender', 'dt' => 5),
            array('db' => 'phone_no', 'dt' => 6),
            array('db' => 'license_no', 'dt' => 7),
            array('db' => 'license_expiry_date', 'dt' => 8),
            array('db' => 'native_lang', 'dt' => 9),
            array('db' => 'nin','dt' =>10),
            array('db' => 'othername','dt' =>11),
            array('db' => 'birthdate','dt' =>12),
            array('db' => 'blood_group','dt' =>13),
            array('db' => 'marital_status','dt' =>14),
            array('db' => 'nationality','dt' =>15),
            array('db' => 'edu_qual','dt' =>16),
            array('db' => 'contact_addr','dt' =>17),
            array('db' => 'email_address','dt' =>18),
            array('db' => 'pob','dt' =>19),
            array('db' => 'lga_origin','dt' =>20),
            array('db' => 'home_origin','dt' =>21),
            array('db' => 'state_origin','dt' =>22),
            array('db' => 'address_residence','dt' =>23),
            array('db' => 'birthcountry','dt' =>24),
            array('db' => 'birthlga','dt' =>25),
            array('db' => 'height','dt' =>26),
            array('db' => 'employment_status','dt' =>27),
            array('db' => 'profession','dt' =>28),
            array('db' => 'religion','dt' =>29),
            array('db' => 'residence_status','dt' =>30),
            array('db' => 'residence_town','dt' =>31),
            array('db' => 'residence_lga','dt' =>32),
            array('db' => 'residence_state','dt' =>33),
            array('db' => 'nok_spokenlang','dt' =>34),
            array('db' => 'nok_town','dt' =>35),
            array('db' => 'nok_firstname','dt' =>36),
            array('db' => 'nok_state','dt' =>37),
            array('db' => 'nok_surname','dt' =>38),
            array('db' => 'nok_middlename','dt' =>39),
            array('db' => 'nok_lga','dt' =>40),
            array('db' => 'nok_address1','dt' =>41),
            array('db' => 'nok_address2','dt' =>42)
        );
        
    
        echo $this->generic_table($data, $table_name, $columner, $filter="", $primary_key);
    }

    // Reconsilation report
    public function rcc_dcc_report($data)
    {
        // var_dump($data);
        // exit;
        $table_name = "transaction_table";
        $primary_key = "transaction_id";
        $columner = array(
            array('db' => 'transaction_id', 'dt' => 0),
            array('db' => 'transaction_id', 'dt' => 1, 'formatter' => function ($d, $row) {
                return "<div class='custom-control custom-checkbox'><input type='checkbox' name='chkopt[]' value='$row[transaction_id]' class='custom-control-input chk' id='$row[transaction_id]'><label class='custom-control-label' for='$row[transaction_id]'></label></div>";
            }),
            array('db' => 'transaction_id', 'dt' => 2),
            array('db' => 'rrr', 'dt' => 3),
            array('db' => 'tranx_desc', 'dt' => 4, 'formatter' => function($d, $row) {
                $content    = explode('~',$d);///payer's name
                return $content[0];
            }),
            array('db' => 'tranx_desc', 'dt' => 5, 'formatter' => function($d, $row) {
                $content    = explode('~',$d);///payer's number
                return $content[1];
            }),
            array('db' => 'transaction_desc', 'dt' => 6),
            array('db' => 'trans_type', 'dt' => 7, 'formatter' => function($d, $row) {
                return ucwords(str_replace('_',' ',$d));
            }),
            array('db' => 'transaction_amount', 'dt' => 8, 'formatter' => function($d, $row) {
                return number_format($d,2);
            }),
            array('db' => 'response_code', 'dt' => 9, 'formatter' => function($d, $row) {
                $status = '';
                if($d==99){
                    $status = 'Transaction Initiated';
                }
                else if($d==51){
                    $status = 'Insufficient Funds';
                }
                else if($d=='0'||$d=='00'){
                    $status = 'Successful';
                }
                else if($d=='200'){
                    $status = 'RRR generated';
                }
                else
                {
                    $status = 'Failed';
                }
                return $status;
            }),
            array('db' => 'response_message', 'dt' => 10),
            array('db' => 'settlement_status', 'dt' => 11, 'formatter' => function($d, $row) {
                return $d==0?"Not Used":"Used";
            }),
            array('db' => 'transaction_id', 'dt' => 12, 'formatter' => function($d, $row) {
                $status = $this->getItemLabel('tbl_training_schedule','training_id',$d,'training_done')==0?'<p class="text-warning">NO</p>':'<p class="text-success">YES</p>';
                return $status;
            }),
            array('db' => 'created', 'dt' => 13),
            
        );

        
        $searchVal = $data['searchby'];
        $keyVal = $data['keyword'];

        $filter = " AND trans_type !='ref_trn' AND response_code IN (0,00)";
        if ($data['searchby'] == 'trans_type') {
            $keyVal = strtolower($keyVal);
            if ($keyVal == 'commercial' || $keyVal == 'commercial drivers' || $keyVal == 'commercial driver') {
               $keyVal = 'comm_driv';
            }else if ($keyVal == 'tricycle' || $keyVal == 'tricycle riders' || $keyVal == 'tricycle rider') {
                $keyVal = 'rider_tricycle'; 
            }else if ($keyVal == 'e-hailing' || $keyVal == 'e-hailing drivers' || $keyVal == 'e-hailing driver' || $keyVal == 'ehailing') {
                $keyVal = 'EHAILING_CERT'; 
            }else if ($keyVal == 'motorcycle' || $keyVal == 'motorcycle riders' || $keyVal == 'motorcycle rider') {
                $keyVal = 'RIDER_MOTORCYCLE'; 
            }else if ($keyVal == 'dispatch' || $keyVal == 'dispatch riders' || $keyVal == 'dispatch rider') {
                $keyVal = 'RIDER_REG'; 
            }else if ($keyVal == 'vehicle' || $keyVal == 'vehicle registration' || $keyVal == 'vehicle reg') {
                $keyVal = 'VEHICLE_REG'; 
            }else if ($keyVal == 'rider renewal' || $keyVal == 'renewal' || $keyVal == 'renew' || $keyVal == 'rider') {
                $keyVal = 'RIDER_REN'; 
            }
        } else {
            $keyVal = $data['keyword'];
        }
        

        $search = isset($searchVal)? $searchVal: '';
        $keyword = isset($keyVal)? $keyVal: '';
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        $role_id = $_SESSION['pts_role_id_sess'];
        $username = trim($_SESSION['pts_username_sess']);
        $operator = trim($_SESSION['pts_license_operator']);
        
        $search == '' ? $filter .= "" : $filter .= " AND $search like '%" . $keyword . "%'";
        if ($role_id == '503') {
            $filter .= " AND source_acct = '$username'";
        } 
        $filter .= ($search !="")?" AND $search ='$keyword'":"";
        
        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);

   
    }
    
    public function referral_report($data)
    {
        $table_name = "transaction_table";
        $primary_key = "transaction_id";
        $columner = array(
            array('db' => 'transaction_id', 'dt' => 0),
            array('db' => 'transaction_id', 'dt' => 1, 'formatter' => function ($d, $row) {
                return "<div class='custom-control custom-checkbox'><input type='checkbox' name='chkopt[]' value='$row[transaction_id]' class='custom-control-input chk' id='$row[transaction_id]'><label class='custom-control-label' for='$row[transaction_id]'></label></div>";
            }),
            array('db' => 'transaction_id', 'dt' => 2),
            array('db' => 'rrr', 'dt' => 3),
            array('db' => 'tranx_desc', 'dt' => 4, 'formatter' => function($d, $row) {
                $content    = explode('~',$d);///payer's name
                return $content[0];
            }),
            array('db' => 'tranx_desc', 'dt' => 5, 'formatter' => function($d, $row) {
                $content    = explode('~',$d);///payer's number
                return $content[1];
            }),
            array('db' => 'transaction_desc', 'dt' => 6),
            array('db' => 'trans_type', 'dt' => 7, 'formatter' => function($d, $row) {
                return ucwords(str_replace('_',' ',$d));
            }),
            array('db' => 'transaction_amount', 'dt' => 8, 'formatter' => function($d, $row) {
                return number_format($d,2);
            }),
            array('db' => 'response_code', 'dt' => 9, 'formatter' => function($d, $row) {
                $status = '';
                if($d==99){
                    $status = 'Transaction Initiated';
                }
                else if($d==51){
                    $status = 'Insufficient Funds';
                }
                else if($d=='0'||$d=='00'){
                    $status = 'Successful';
                }
                else if($d=='200'){
                    $status = 'RRR generated';
                }
                else
                {
                    $status = 'Failed';
                }
                return $status;
            }),
            array('db' => 'response_message', 'dt' => 10),
            array('db' => 'settlement_status', 'dt' => 11, 'formatter' => function($d, $row) {
                return $d==0?"Not Used":"Used";
            }),
            
            array('db' => 'created', 'dt' => 12),
            
        );
        
        $filter = " AND trans_type ='ref_trn' AND response_code IN (0,00) ";
        $search = $data['searchby'];
        $keyword = $data['keyword'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        $role_id = $_SESSION['pts_role_id_sess'];
        $username = trim($_SESSION['pts_username_sess']);
        $operator = trim($_SESSION['pts_license_operator']);
        
        $search == '' ? $filter .= "" : $filter .= " AND $search like '%" . $keyword . "%'";
        if ($role_id == '503') {
            $filter .= " AND source_acct = '$username'";
        } 

        $filter .= ($search !="")?" AND $search ='$keyword'":"";

        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);
        // echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);

   
    }

    public function card_report($data)
    {
        $table_name = "tbl_riders";
        $primary_key = "rcn";
        $columner = array(
            array('db' => 'rcn', 'dt' => 0),
            array('db' => 'rcn', 'dt' => 1, 'formatter' => function ($d, $row) {
                return "<div class='custom-control custom-checkbox'><input type='checkbox' name='chkopt[]' value='$d' class='custom-control-input chk' id='$d'><label class='custom-control-label' for='$d'></label></div>";
            }),
            array('db' => 'rcn', 'dt' => 2),
            array('db' => 'nin', 'dt' => 3, 'formatter' => function ($d, $row) {
                      return $this->maskStr($d,4,8);
                  }),
            array('db' => 'title', 'dt' => 4),
            array('db' => 'surname', 'dt' => 5),
            array('db' => 'firstname', 'dt' => 6),
            array('db' => 'gender', 'dt' => 7),
            array('db' => 'phone_no', 'dt' => 8),
            array('db' => 'created', 'dt' => 9),
        );
        
        $filter = " AND print_farm = '0' ";
        $search = isset($data['searchby']) || $data['searchby'] != '' ?$data['searchby']: '';
        $keyword = $data['keyword'];
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];
        $role_id = $_SESSION['pts_role_id_sess'];
        $username = trim($_SESSION['pts_username_sess']);
        $operator = trim($_SESSION['pts_license_operator']);
        
        $search == '' ? $filter .= "" : $filter .= " AND $search like '%" . $keyword . "%'";
        file_put_contents();
        if ($role_id == '503') {
            $filter .= " AND source_acct = '$username'";
        } else {
            $filter .= "";
        }

        echo $this->generic_table($data, $table_name, $columner, $filter, $primary_key);

   
    }

    public function tcount($data)
    {
        $start_date = isset($data['start_date'])?$data['start_date']:date('Y-m-d');
        $end_date = isset($data['end_date'])?$data['end_date']:date('Y-m-d', strtotime('+5 days'));
        
        $searchby = isset($data['searchby'])? $data['searchby']: '' ;
        $keyword = isset($data['keyword'])? $data['keyword']: '' ;
        // file_put_contents('key.txt', $keyword);
        if ($searchby == 'trans_type') {
            // $keyword = strtolower(str_replace(' ','_',$data['keyword']));
            $keyword = strtolower($keyword);
            if ($keyword == 'commercial' || $keyword == 'commercial drivers' || $keyword == 'commercial driver') {
               $keyword = 'comm_driv';
            }else if ($keyword == 'tricycle' || $keyword == 'tricycle riders' || $keyword == 'tricycle rider') {
                $keyword = 'rider_tricycle'; 
            }else if ($keyword == 'e-hailing' || $keyword == 'e-hailing drivers' || $keyword == 'e-hailing driver' || $keyword == 'ehailing') {
                $keyword = 'EHAILING_CERT'; 
            }else if ($keyword == 'motorcycle' || $keyword == 'motorcycle riders' || $keyword == 'motorcycle rider') {
                $keyword = 'RIDER_MOTORCYCLE'; 
            }else if ($keyword == 'dispatch' || $keyword == 'dispatch riders' || $keyword == 'dispatch rider') {
                $keyword = 'RIDER_REG'; 
            }else if ($keyword == 'vehicle' || $keyword == 'vehicle registration' || $keyword == 'vehicle reg') {
                $keyword = 'VEHICLE_REG'; 
            }else if ($keyword == 'rider renewal' || $keyword == 'renewal' || $keyword == 'renew') {
                $keyword = 'RIDER_REN'; 
            }

        } else {
            $keyword = isset($data['keyword'])?$data['keyword']:"";
        }

        if ($keyword == '') {
          
        } else {
            $sql = "SELECT SUM(transaction_amount) AS total FROM transaction_table WHERE response_code IN (0,00) AND trans_type !='ref_trn' AND $searchby = '$keyword'";
            $stmt = $this->dbQuery($sql);
            file_put_contents('key.txt', $sql);
            if($stmt > 0){
                return json_encode(array('count'=>$stmt[0]['total']));
            }else{
                return json_encode(array('count'=>0));
            } 
        }
        
        
        $stmt = $this->dbQuery("SELECT SUM(transaction_amount) AS total FROM transaction_table WHERE response_code IN (0,00) AND trans_type !='ref_trn' AND (date(created) BETWEEN '$start_date' AND '$end_date')");

        if($stmt > 0){
            return json_encode(array('count'=>$stmt[0]['total']));
        }else{
            return json_encode(array('count'=>0));
        }

    }

    ///end class
    public function rcount($data)
    {
        $start_date = isset($data['start_date'])?$data['start_date']:date('Y-m-d');
        $end_date = isset($data['end_date'])?$data['end_date']:date('Y-m-d', strtotime('+5 days'));
        
        $searchby = isset($data['keyword'])?$data['keyword']:"";
        $keyword = isset($data['searchby'])?$data['searchby']:"";

        if ($keyword == '') {
            
        } else {
            $stmt = $this->dbQuery("SELECT SUM(transaction_amount) AS total FROM transaction_table WHERE response_code IN (0,00) AND trans_type ='ref_trn' AND $keyword = '$searchby'"); 
        
            if($stmt > 0){
                return json_encode(array('count'=>$stmt[0]['total']));
            }else{
                return json_encode(array('count'=>0));
            }
        }
        
        $stmt = $this->dbQuery("SELECT SUM(transaction_amount) AS total FROM transaction_table WHERE response_code IN (0,00) AND trans_type ='ref_trn' AND (date(created) BETWEEN '$start_date' AND '$end_date')");

        // file_put_contents('stmt.txt', $stmt);

        if($stmt > 0){
            return json_encode(array('count'=>$stmt[0]['total']));
        }else{
            return json_encode(array('count'=>0));
        }

    }

}


