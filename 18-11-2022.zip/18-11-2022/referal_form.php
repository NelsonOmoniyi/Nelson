<!-- new -->
<?php
include_once "lib/dbfunctions_new.php";
$dbobject = new dbobject();

$pin = isset($_REQUEST['pinVal'])?$_REQUEST['pinVal']:'';
$phone = isset($_REQUEST['phoneVal'])?$_REQUEST['phoneVal']:'';
$name = isset($_REQUEST['name'])?$_REQUEST['name']:'';
$nin = isset($_REQUEST['nin'])?$_REQUEST['nin']:'';
$plate = isset($_REQUEST['plate'])?$_REQUEST['plate']:'';
$dob = isset($_REQUEST['dob'])?$_REQUEST['dob']:'';
// echo $plate;

function call(){
    $ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://fctevregendpointdemo.fctevreg.com/drts_selfservice/offencesList");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$json = curl_exec($ch);
$err = curl_error($ch);
curl_close($ch);

$data2 = json_decode($json, true);

return $data2['data']['list'];

}

$arr1 = call();

$keys = array_keys($arr1);
$collected = [];

foreach ($keys as $value) {
    array_push($collected, $value);
}
$got = [];
foreach($collected as $bvalue){
    $stmt = $arr1[$bvalue];
//   asort($stmt);
    foreach ($stmt as $offen) {
        array_push($got,$offen[name]);
    }
}
sort($got);

$sql_veh = "SELECT veh_cat, veh_code FROM veh_cat ORDER BY veh_cat ASC";
$veh = $dbobject->dbQuery($sql_veh);

$sql_com = "SELECT * FROM `lga_tbl` WHERE state_id = 'NG-FC' ORDER BY lga ASC";
$com = $dbobject->dbQuery($sql_com);
// var_dump($veh);
// exit;
$op = isset($_REQUEST['op']) ? $_REQUEST['op'] : 'new';
if (!isset($_REQUEST['op'])) {

   $sql_type = "SELECT itemtype_id, payitem_id, payitem_name FROM tb_vregrate_tbl WHERE regcat_id = 'OFFEN' GROUP BY payitem_name ASC";
    $type = $dbobject->dbQuery($sql_type);

$id = 'cart';
$id = $id + 1;
}
?>


<script src="http://parsleyjs.org/dist/parsley.js"></script>
<script src="js/parsley.js"></script>
<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="fas fa-tasks bg-c-blue"></i>
                <div class="d-inline">
                    <h5>Referral List</h5>
                    <span>Add Referral</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="index.php"><i class="feather icon-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Dashboard</a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="main-body">
    <div class="page-wrapper">

        <div class="page-body">
            <div class="row">
                <div class="col-lg-12" id="info-card">
                    <div class="card" id="payment-card">
                        <div class="card-header ">
                            <h5 class="modal-title">Referral Form <i class="fas fa-bars"></i></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                               
                            </button>
                        </div>
                        <div class="card-body">
                            <form method="POST" id="form1" name="form1">
                                <!-- <input type="hidden" name="op" value="Referal.saveReferal"> -->
                                <input type="hidden" id="check" name="check" value="">
                                <input type="hidden" name="pin" value="<?php echo $pin ?>">
                                <input type="hidden" name="phone" value="<?php echo $phone ?>">
                               
                                <div class="form-group row">
                                    <div class="col-md-4">
                                        <label>Name</label>
                                        <input type="text" id="namev" class="form-control" name="name" value="<?php echo $name ?>" required>
                                    </div>
                                    <div class="col-md-4">
                                        <label>Gender</label>
                                        <select name="gender" class="form-control" required>
                                            <option hidden value="">:: SELECT GENDER::</option>
                                            <option value="male">Male</option>
                                            <option value="female">Female</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label>Address</label>
                                        <input type="text" required value="" name="address" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-md-4">
                                        <label>Nin</label>
                                        <input type="text" id="ninv" name="nin" class="form-control" maxlength='11' value="<?php echo $nin ?>" required>
                                    </div>
                                    <div class="col-md-4">
                                        <label>Date Of Birth</label>
                                        <input type="date" id="dobv" name="dob" class="form-control" value="<?php echo $dob ?>" required>
                                    </div>
                                    <div class="col-md-4">
                                        <label>Plate Number</label>
                                        <input name="plate" id="platev" class="form-control" maxlength='8' value="<?php echo $plate ?>" required>
                                    </div>
                                </div>
                                
                                <div class="form-group row">
                                    <div class="col-md-4">
                                        <label>Vehicle Type</label>
                                        <select name="VehType" class="form-control" required>
                                            <option hidden value="">:: SELECT VEHICLE TYPE::</option>
                                            <?php
                                                foreach ($veh as $value) {
                                                    echo '<option value="'.$value[veh_code].'">'.$value[veh_cat].'</option>';
                                                }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label>Any Other Info</label>
                                        <textarea name="others" cols="10" rows="1" class="form-control"></textarea>
                                    </div>
                                    <div class="col-md-4">
                                        <label>Location Of Violation</label>
                                        
                                        <select name="location" class="form-control" required>
                                            <option hidden value="">:: SELECT L.G.A OF VIOLATION::</option>
                                            <?php
                                                foreach ($com as $community) {
                                                    echo '<option value="'.$community['lga'].'">'.$community['lga'].'</option>';
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <!-- dynamic input field -->
                                <div id="newRow"></div>
                                <button id="addRow" type="button" class="btn btn-info btn-md" required><i class="fas fa-plus"></i> Add Violation</button>
                                <!-- end of dynamic feild input -->
                            </form>
                        </div>
                        <card class="card-footer">
                            <button type="button" class="btn btn-warning" onclick="checkValid('Referal', 'saveReferal', 'referal_list.php')">Save</button>
                        </card>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


    <script src="./js/referal_list.js"></script>                                        
<script>
        var counter = 0;
        var INCname = 0;

    // add row
    $("#addRow").click(function () {
         $("#check").val("1");
        counter++;
        name++;
        INCname++;
            var html = '';
            html += '<div class="row" id="row">';
            html += '<div class="col-lg-6">';
            html += '<div id="inputFormRow">';
            html += '<div class="input-group mb-3">';
            html += '<select name="offences[]" id="cart'+counter+'" class="form-control" required>';
            html += '<option hidden value="">:: SELECT VIOLATION ::</option>';
            html += '<?php
                    
                    foreach ($got as $offen) {
                       
                         echo "<option id=\'$idi\' value=\'$offen\' >$offen</option>";
                    }
             
            ?>
            ';
            html += '</select>';
            html += '<button id="removeRow" type="button" class="btn btn-danger btn-sm">Remove</button>';
            html += '</div>';
            html += '</div>';
            html += '</div>';
            html += '</div>';

            $('#newRow').append(html);
        });
       
        setTimeout(() => {

        if ($("#namev").val() == " " || $("#namev").val() == "null" || $("#namev").val() == "") {
            console.log('Name Field Does NOT Contain Data');
        } else {
            $("#namev").attr('readonly', true)
        }
        if ($("#ninv").val() == " " || $("#ninv").val() == "null" || $("#ninv").val() == "") {
            console.log('NIN Field Does NOT Contain Data');
        } else {
            $("#ninv").attr('readonly', true)
        }
        if ($("#platev").val() == " " || $("#platev").val() == "null" || $("#platev").val() == "") {
            console.log('Address Field Does NOT Contain Data');
        } else {
            $("#platev").attr('readonly', true)
        }
        if ($("#dobv").val() == " " || $("#dobv").val() == "null" || $("#dobv").val() == "") {
            console.log('Title Field Does NOT Contain Data');
        } else {
            $("#dobv").attr('readonly', true)
        }
        }, 1000);
            
</script>
