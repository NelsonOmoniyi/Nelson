<?php 
require_once("../lib/dbfunctions_new.php");
require_once("../classes/Training.php");
require('fpdf_print_module.php');
/*error_reporting(E_ALL);
ini_set('display_errors',1);*/
$dbobject   = new dbobject();

class Receipt extends FPDF
{
    private $customer_name='';
    private $transaction_id = '';
    private $portal_id;
    private $description;
    private $phone_no;
    private $response_code;
    private $pin;
    private $response_message;
    // Page header
    function Header()
    {
        // Logo
       $this->Image('../assets/img/receipt_bg.png', 0, 0, $this->w, $this->h);
       $this->Ln(18);

    }

    function setReceiptTitle($transaction_id) {
        $this->SetTitle('FCT PTMS Transaction Receipt - '. $transaction_id);

        $text = "Date: ". date("l, jS \of F, Y ");
        $this->SetFont('Times','B',12);
        $this->SetTextColor(0,0,0);
        $this->Cell(0,10,$text,0,0,'R');
        $this->Ln(15);

        //title
        $text = "Transaction Receipt";
        $this->SetFont('Times','BU',28);
        $this->SetTextColor(0,0,0);
        $this->Cell(0,10,$text,0,0,'C');
        $this->Ln(12);//10


        /*$text = "Please note that this Dealership Receipt is valid for a period of $this->validity_days days only.";
        $this->SetFont('Times','BI',10);
        $this->SetTextColor(0,0,0);
        $this->Cell(0,3,$text,0,0,'C');
        $this->Ln(5);*/

        $text = "This payment slip will be required to continue processing at the designated centre."; 
        $this->SetFont('Times','BI',12);
        $this->Cell(0,3,$text,0,0,'C');
        $this->Ln(12);  
    }

    function setCustomerDetails() {

        $text = "Payment Information";
        $this->SetFont('Times','I',20);
        $this->SetTextColor(0,100,0);
        $this->Cell(0,3,$text,0,0,'C');
        $this->Ln(15);

        $ft_text = 12;
        $ft_data = 14;
        $text = "Name: ";
        $this->SetFont('Times','B',$ft_text);
        $this->SetTextColor(0,0,0);
        $this->Cell(40,5,$text,0,0,'L');
        
        $this->SetFont('Times','B', $ft_data);
        $this->Cell(100, 5, ucwords($this->customer_name), 'B', 0, 'L');
        $this->Ln(12);

        $text = "Phone Number: ";
        $this->SetFont('Times','B',$ft_text);
        $this->SetTextColor(0,0,0);
        $this->Cell(40,5,$text,0,0,'L');
        
        $this->SetFont('Times','B', $ft_data);
        $this->Cell(100, 5, $this->phone_no, 0, 0, 'L');
        $this->Ln(7);

        $text = "Description: ";
        $this->SetFont('Times','B',$ft_text);
        $this->SetTextColor(0,0,0);
        $this->Cell(40,5,$text,0,0,'L');
        
        $this->SetFont('Times','B', $ft_data);
        $this->Cell(100, 5, $this->description, 0, 0, 'L');
        $this->Ln(8);
        
    }


    function setHeaderTitle($title) {
        $this->header_title = $title;
    }

    function setdynamicData($transaction_id, $customer_name, $phone_no, $description,$pin,$response_code,$response_message) {
        $this->transaction_id   = $transaction_id;
        $this->customer_name    = $customer_name;
        $this->phone_no         = $phone_no;
        $this->description      = $description;
        $this->response_code    = $response_code;
        $this->response_message = $response_message;
        $this->pin              = $pin;
    }

    // Page footer
    function Footer()
    {
        //Position at 1.0 cm from bottom
        $this->SetY(-10);
       
     
        // Page title
        $this->SetFont('Arial','I',8);
        $this->Cell(0,5,"FCT Public Transport Management System Portal",0,0,'C');
    }

    function summaryTable($title, $data, $total_amount)
    {
        //file_put_contents('aa.txt',json_encode($data)."\r\n".$total_amount);
        // Colors, line width and bold font
        $this->SetFillColor(129, 184, 31);
        $this->SetTextColor(0);
        $this->SetDrawColor(0,0,0);
        $this->SetLineWidth(.3);
        $this->SetFont('Times','B');

        // Header
        $this->Cell(190,7,$title,0,0,'L',true);
        $this->Ln();

        // Color and font restoration
        $this->SetFillColor(224,235,255);
        $this->SetTextColor(0);
        $this->SetFont('');
        // Data
        $fill = false;
        $w = array(140, 50);
        foreach($data as $key => $row)
        {
            $this->SetFont('Times','',10);
            $this->Cell($w[0], 10, $key, 0, 0, 'L', $fill);
            $this->SetFont('Times','B',10);
            $this->Cell($w[1], 10, $row, 0, 0, 'L', $fill);
            $this->Ln();
            $fill = !$fill;
        }
        // Closing line
        $this->Cell(array_sum($w),0,'','T');

        if($total_amount != "") {
            //total Amount
            $this->Ln();
            $this->SetFont('Times','B',13);
            $this->Cell($w[0],10,"Total: ",'',0,'R',$fill);
            $this->SetFont('Times','B',14);
            $this->Cell($w[1],10,$total_amount,'',0,'L',$fill);
            $this->Ln();
            // Closing line
            $this->Cell(array_sum($w),0,'','T');
        }

         $this->Ln(12);//20
    }

    function statusTable($title, $data, $state)
    {
        // Colors, line width and bold font
        $this->SetFillColor(217, 165, 0);
        $this->SetTextColor(0);
        $this->SetDrawColor(0,0,0);
        $this->SetLineWidth(.3);
        $this->SetFont('Times','B');

        // Header
        $this->Cell(190,7,$title,0,0,'L',true);
        $this->Ln();

        // Color and font restoration
        $this->SetFillColor(224,235,255);
        $this->SetTextColor(0);
        $this->SetFont('');
        // Data
        $fill = false;
        $w = array(50, 140);
        foreach($data as $key => $row)
        {
            if ($state == 'ref') {
                if ($key == 'Processing PIN') {
                    $key = 'Description';
                    $row = 'Referral';
                    $font_style = strtolower($key)=='processing pin'?'B':'';
                    $this->SetFont('Times','B',10);
                    $this->Cell($w[0],10,$key,0,0,'L',$fill);
                    $this->SetFont('Times',$font_style, 10);
                    $this->Cell($w[1],10,$row,0,0,'L',$fill);
                    $this->Ln();
                    $fill = !$fill;
                } else {
                    $font_style = strtolower($key)=='processing pin'?'B':'';
                    $this->SetFont('Times','B',10);
                    $this->Cell($w[0],10,$key,0,0,'L',$fill);
                    $this->SetFont('Times',$font_style, 10);
                    $this->Cell($w[1],10,$row,0,0,'L',$fill);
                    $this->Ln();
                    $fill = !$fill;
                }
                
            } else {
                $font_style = strtolower($key)=='processing pin'?'B':'';
                $this->SetFont('Times','B',10);
                $this->Cell($w[0],10,$key,0,0,'L',$fill);
                $this->SetFont('Times',$font_style, 10);
                $this->Cell($w[1],10,$row,0,0,'L',$fill);
                $this->Ln();
                $fill = !$fill;
            }
            
            file_put_contents('nelson.txt', $key.'=>'.$row, FILE_APPEND | LOCK_EX);
          
        }
        // Closing line
        $this->Cell(array_sum($w),0,'','T');
        $this->Ln(12);
    }
    function trainingTable($title, $data)
    {
        // Colors, line width and bold font
        $this->SetFillColor(0, 0, 0);
        $this->SetTextColor(255);
        $this->SetDrawColor(0,0,0);
        $this->SetLineWidth(.3);
        $this->SetFont('Times','B',14);

        // Header
        $this->Cell(190,7,$title,0,0,'L',true);
        $this->Ln();

        // Color and font restoration
        $this->SetFillColor(224,235,255);
        $this->SetTextColor(0);
        $this->SetFont('');
        // Data
        $fill = false;
        $w = array(50, 140);
        foreach($data as $key => $row)
        {
            if(strtolower($key)!='note')
            {
                //$font_style = strtolower($key)=='processing pin'?'B':'';
                $this->SetFont('Times','B',10);
                $this->Cell($w[0],10,$key,0,0,'L',$fill);
                $this->SetFont('Times','', 10);
                $this->Cell($w[1],10,$row,0,0,'L',$fill);
                $this->Ln();
                $fill = !$fill;
            }
        }
        // Footnote
        $this->SetFont('Times','BI',9);
        $this->Cell(array_sum($w),2,$data['note'],0,0,'L');
    }
    function generateContent($transaction_id, $summary, $status, $transaction_amount,$training,$response_code,$description) {
        
        $this->setReceiptTitle($transaction_id);
        $this->setCustomerDetails();

        $this->summaryTable(
            'Payment Details', 
            $summary, 
            'NGN'. number_format($transaction_amount, 2)
        );
        if($response_code=='0'||$response_code=='00')
        {
            // file_put_contents('nelson.txt', $status);
            $this->statusTable(
                "Payment Status",
                $status,
                'ref'
            );
        // file_put_contents('nelson.txt', $training);
            if(str_contains($description, 'Referral') || str_contains($description, 'Referal')){
                echo "   ";
            }else{
                $this->trainingTable(
                    "Training Details",
                    $training
                );
            }
        }else{
            $this->statusTable(
                "Payment Status",
                $status,
                'non'
            );
        }
        
        /*$this->SetX(30);
        $this->Cell(0,50,'Nxsndjn ',0,0,'L');*/
        
    }

}

    //BUILD THE QUERY
    $data_filter = $_REQUEST;
    //print_r($data_filter); exit;


    // start DATA
    $transaction_id = base64_decode(trim($_REQUEST['id']));
    // end DATA

try {
    
    $details = array();
    if($transaction_id != "") {
       

        
        $dt         = $dbobject->getitemlabelArr("transaction_table", array("transaction_id"), array($transaction_id), array("response_code", "transaction_desc",  "transaction_amount", "payment_mode", "tranx_desc", "created", "response_message", "order_id", "chargefee", "created","rrr","session_id"));
        $details    = $dt[0];
        //echo $transaction_id."  ".json_encode($details);
        $customer_details = explode('~',$details['tranx_desc']);
        //echo json_encode($customer_details);
    
        // PRINT TO SCREEN
        $Receipt = new Receipt();
        
       
        //$payload = json_decode($details['xml_data'], true); 
        $payment_details = array();
        // $breakdown =($details['service_feedback']) ? json_decode($details['service_feedback'], true) : array();
        $breakdown = array();

        //dynamic data from db
        $customer_name      = $customer_details[0];
        $phone_no           = $customer_details[1];
        $description        = $details['transaction_desc'];
        $response_code      = $details['response_code'];
        $response_message   = $details['response_message'];
        $rrr                = $dbobject->prepRRR($details['rrr']);
        $payment_mode       = str_replace('_',' ',$details['payment_mode']);

        $transaction_amount = $details['transaction_amount'];
        $chargefee = ($details['chargefee'] > 0) ? ' NGN '. number_format($details['chargefee'], 2) : ' Nil ';

        $summary = array(
                'Amount' => 'NGN '. number_format($transaction_amount,2)
            );
        
      

        $processing_status = 'Payment ';
        $processing_pin    = '';
        $evreg_pin         = '';
        if($details['response_code'] == '0' || $details['response_code'] == '00')
        {    $processing_status .=  'Successful ';
             $processing_pin     =  $details['order_id'];
             $evreg_pin          =  $details['session_id'];}
        elseif($details['response_code'] == '99') { $processing_status .= 'Pending '; }
        elseif($details['response_code'] == '100') { $processing_status .= 'Cancelled/Terminated '; }
        else { $processing_status .=  'Failed '; }
        $processing_status .= " ::||:: ".$details['response_message'];

       
        if($details['response_code']=='00'||$details['response_code']=='0')
        {
            $status = array(
                'Transaction Reference' => $transaction_id,
                'Processing Status' => $processing_status,
                'Payment Date' => $details['created'],
                'Processing PIN' => $processing_pin,
                'Payment Method' => $payment_mode
            );
            if(strtolower($details['payment_mode'])=='evreg_pin')
            {
                $status['eVreg PIN']        = $evreg_pin;
            }
            else
            {
                $status['Remita Reference'] = $rrr;
            }
        }
        else
        {
            $status = array(
                'Transaction Reference' => $transaction_id,
                'Processing Status' => $processing_status,
                'Payment Date' => $details['created']
            );
            if(strtolower($details['payment_mode'])!='evreg_pin')
            {
                $status['Remita Reference']        = $rrr;
            }
            if($details['rrr']!='')
            {
                $status['Remita Reference'] = $rrr;
            }
        }
        // if it is for referal then do not display training details
        // file_put_contents("Check.txt", $description);
        if($description=='Payment for Referral Fee'){
            echo "   ";
        }else{
            if($details['response_code']=='00'||$details['response_code']=='0'){
                /////set training details
                $training = new Training();
                $training   = $training->getTrainingDetails($transaction_id);
            }
        }
        $Receipt->setdynamicData($transaction_id, $customer_name, $phone_no, $description,$pin,$response_code,$response_message);
        $Receipt->AddPage('P');
        $Receipt->generateContent($transaction_id, $summary, $status, $transaction_amount,$training,$response_code, $description);
        
        $Receipt->Output('','PTMS Payment Receipt '.$transaction_id.'.pdf');
    }
    else { 
        $Receipt = new Receipt();
        $Receipt->AddPage('P');

        // //draw border
        $Receipt->SetDrawColor( 60,179,113);
        $Receipt->SetLineWidth(8);
        $Receipt->Rect(30, 30, 150, 100, 'D');
  
        $Receipt->SetFont('Times','I',24); 
        $Receipt->SetTextColor(255,0,0);  
        $Receipt->Cell(0,50,'No Data Found',0,1, 'C'); 
        

        $Receipt->Output('','PTMS Payment Receipt '.$transaction_id.'.pdf');

        //
    }
    
}
catch(Error $ex) {
   echo "<h1 style='text-align:center'>Oops! Something went wrong!</h1>".$ex;
}


?>
