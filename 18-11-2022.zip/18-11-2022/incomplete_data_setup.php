<?php
include_once "lib/dbfunctions_new.php";
$dbobject = new dbobject; 
$rcn_id = isset($_REQUEST['rcn']) ? $_REQUEST['rcn'] :'';

$sql = "SELECT * FROM tbl_riders WHERE rcn ='$rcn_id'";
$data = $dbobject->dbQuery($sql);
$info = $data[0];
// var_dump($data[0]);
?>

<link rel="stylesheet" href="assets/css/classic.css">
<style>
    .error {
        color: red !important;
        font-weight: bolder !important;
    }

    .font {
        font-size: 20px
    }
</style>
<form id="form1" >
    <div class="page-header card">
        <div class="row align-items-end">
            <div class="col-lg-8">
                <div class="page-header-title">
                    <i class="fas fa-taxi bg-c-blue"></i>
                    <div class="d-inline">
                        <h5>Incomplete NIN Details</h5>
                        <span>Fill In the Incomplete Data</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="page-header-breadcrumb">
                    <ul class=" breadcrumb breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="index.php"><i class="feather icon-home"></i></a>
                        </li>
                        <li class="breadcrumb-item"><a href="#">Dashboard</a> </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
       

    <div class="main-body">
        <div class="page-wrapper">

            <div class="page-body">
                <div class="row mr-20">
                    <div class="col-lg-12">
                        <!-- card -->
                        <div class="card" >
                            <div class="card-header">
                                <div class="col-lg-6">
                                    <i class="fa fa-arrow-left" onclick="getPage('update_data.php','box')" style="cursor: pointer; margin-right: 10px"></i>
                                    <h5 class="card-title">Update Incomplete NIN Data <i class="fas fa-car"></i></h5>
                                </div>
                            </div>
                            <div class="card-body font-weight-bold" >
                                <fieldset style="border-style: solid;">
                                    <legend class="text-success">NIN Information</legend>
                                    <div class="row">
                                        <input type="hidden" name="rcn" value="<?php echo $rcn_id; ?>">
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="title">Title</label>
                                                <input type="text" name="title" id="title" class="form-control field" value="<?php echo $info['title'];?>"  required>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="surname">Surname</label>
                                                <input type="text" name="surname" id="surname" class="form-control field" value="<?php echo $info['surname'];?>"  required>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="firstname">First Name</label>
                                                <input type="text" name="firstname" id="firstname" class="form-control field" value="<?php echo $info['firstname'];?>"  required>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="gender">Gender</label>
                                                <input type="text" name="gender" id="gender" class="form-control field" value="<?php echo $info['gender'];?>"  required>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="phonenumber">Phone Number</label>
                                                <input type="text" name="phone_no" id="phonenumber" class="form-control field" value="<?php echo $info['phone_no'];?>"  required>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="nativelang">Native Language</label>
                                                <input type="text" name="native_lang" id="nativelang" class="form-control field" value="<?php echo $info['native_lang'];?>" >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="nin">NIN</label>
                                                <input type="number" name="nin" id="nin" class="form-control field" value="<?php echo $info['nin'];?>"  required>
                                            </div>
                                        </div><div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="othernames">Other Names</label>
                                                <input type="text" name="othername" id="othernames" class="form-control field" value="<?php echo $info['othername'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="dob">Date Of Birth</label>
                                                <input type="date" name="birthdate" id="dob" class="form-control field" value="<?php echo $info['birthdate'];?>"  required>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="blood">Blood Group</label>
                                                <input type="text" name="blood_group" id="blood" class="form-control field" value="<?php echo $info['blood_group'];?>"  required>
                                            </div>
                                        </div><div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="marital">Marital Status</label>
                                                <input type="text" name="marital_status" id="marital" class="form-control field" value="<?php echo $info['marital_status'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="nationality">Nationality</label>
                                                <input type="text" name="nationality" id="nationality" class="form-control field" value="<?php echo $info['nationality'];?>"  required>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="edu_qual">Educational Qualifications</label>
                                                <input type="text" name="edu_qual" id="edu_qual" class="form-control field" value="<?php echo $info['edu_qual'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="contact_add">Contact Address</label>
                                                <input type="text" name="contact_addr" id="contact_add" class="form-control field" value="<?php echo $info['contact_addr'];?>" >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="emailemail">Email Address</label>
                                                <input type="text" name="email_address" id="email" class="form-control field" value="<?php echo $info['email_address'];?>"  required>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="pob">Place Of Birth</label>
                                                <input type="text" name="pob" id="pob" class="form-control field" value="<?php echo $info['pob'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="lga_origin">L.G.A of Origin</label>
                                                <input type="text" name="lga_origin" id="lga_origin" class="form-control field" value="<?php echo $info['lga_origin'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="home_origin">Home of Origin</label>
                                                <input type="text" name="home_origin" id="home_origin" class="form-control field" value="<?php echo $info['home_origin'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="state_origin">State of Origin</label>
                                                <input type="text" name="state_origin" id="state_origin" class="form-control field"state_origi fieldn value="<?php echo $info['state_origin'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="res_address">Residential Address</label>
                                                <input type="text" name="address_residence" id="res_address" class="form-control field" value="<?php echo $info['address_residence'];?>"  required>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="con_birth">Country of Birth</label>
                                                <input type="text" name="birthcountry" id="con_birth" class="form-control field" value="<?php echo $info['birthcountry'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="lga_birth">LGA of Birth</label>
                                                <input type="text" name="birthlga" id="lga_birth" class="form-control field" value="<?php echo $info['birthlga'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="height">Height</label>
                                                <input type="number" name="height" id="height" class="form-control field" value="<?php echo $info['height'];?>"  required>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="emp_status">Employment Status</label>
                                                <input type="text" name="employment_status" id="emp_status" class="form-control field" value="<?php echo $info['employment_status'];?>"  required>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="profession">Profession</label>
                                                <input type="text" name="profession" id="profession" class="form-control field" value="<?php echo $info['profession'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="religion">Religion</label>
                                                <input type="text" name="religion" id="religion" class="form-control field" value="<?php echo $info['religion'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="res_status">Residential Status</label>
                                                <input type="text" name="residence_status" id="res_status" class="form-control field" value="<?php echo $info['residence_status'];?>" >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="town_residence">Town of Residence</label>
                                                <input type="text" name="residence_town" id="town_residence" class="form-control field" value="<?php echo $info['residence_town'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="residence_lga">LGA of Residence</label>
                                                <input type="text" name="residence_lga" id="residence_lga" class="form-control field" value="<?php echo $info['residence_lga'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="state_residence">State of Residence</label>
                                                <input type="text" name="residence_state" id="state_residence" class="form-control field" value="<?php echo $info['residence_state'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="nok_spokenlang">Next of Kin Spoken Language</label>
                                                <input type="text" name="nok_spokenlang" id="nok_spokenlang" class="form-control field" value="<?php echo $info['nok_spokenlang'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="nok_town_res">Next of Kin Town of Residence</label>
                                                <input type="text" name="nok_town" id="nok_town_res" class="form-control field" value="<?php echo $info['nok_town'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="nok_firstname">Next of Kin First Name</label>
                                                <input type="text" name="nok_firstname" id="nok_firstname" class="form-control field" value="<?php echo $info['nok_firstname'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="nok_stateres">Next of Kin State of Residence</label>
                                                <input type="text" name="nok_state" id="nok_stateres" class="form-control field" value="<?php echo $info['nok_state'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="nok_surname">Next of Kin Surname</label>
                                                <input type="text" name="nok_surname" id="nok_surname" class="form-control field" value="<?php echo $info['nok_surname'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="nok_middlename">N.O.Kin Middle Name</label>
                                                <input type="text" name="nok_middlename" id="nok_middlename" class="form-control field" value="<?php echo $info['nok_middlename'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="nok_lga_res">N.O.Kin LGA of Residence</label>
                                                <input type="text" name="nok_lga" id="nok_lga_res" class="form-control field" value="<?php echo $info['nok_lga'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="nok_res_addr1">N.O.Kin Residential Address 1</label>
                                                <input type="text" name="nok_address1" id="nok_res_addr1" class="form-control field" value="<?php echo $info['nok_address1'];?>"  >
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-label" for="nok_res_addr1">N.O.Kin Residential Address 2</label>
                                                <input type="text" name="nok_address2" id="nok_res_addr1" class="form-control field" value="<?php echo $info['nok_address2'];?>"  >
                                            </div>
                                        </div>
                                    </div>
                                </fieldset>

                                <div class="row float-right">
                                    <button class="btn btn-submit btn-info" onclick="getPage('update_data.php','box')" type="button">Go Back</button>&nbsp;
                                    <button class="btn btn-submit btn-warning" onclick="checkValid('Update', 'updateMissingRecord', 'update_data.php')" type="button">Save</button>
                                </div>
                                
                            </div>
                        </div>
                        <!-- card end -->
                    </div>
                </div>
            </div>
        </div>

    </div>
</form>

<script>
$( document ).ready(function() {
    // console.log( "ready!" );
    setTimeout(() => {
        $(".field").each(function(){
        if($(this).val() =='' || $(this).val() =='****'|| $(this).val() =='0.0'){
            $(this).css("background", "1px solid red");
            // border: 1px solid red;
        }else{
            $(this).prop("readonly", true);
        }
    });
    }, 1000);

});
  
</script>