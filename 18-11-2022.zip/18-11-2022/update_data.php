<script src="http://parsleyjs.org/dist/parsley.js"></script>
<script src="js/parsley.js"></script>
<div class="page-header card">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <i class="fas fa-tasks bg-c-blue"></i>
                <div class="d-inline">
                    <h5>Update Incomplete Data</h5>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class=" breadcrumb breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="index.php"><i class="feather icon-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Dashboard</a> </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="main-body">
    <div class="page-wrapper">

        <div class="page-body">

            <div class="row">
                <div class="col-sm-12">

                    <div class="card" style="width: 100%; overflow: auto">
                        <div class="card-header">
                            <h5>Incomplete Data</h5>
                            <span>Add class of <code>.form-control</code> with <code>&lt;input&gt;</code> tag</span>
                        </div>
                        <div class="card-block">

                            <div class="row">
                                <div class="col-md-12">
                                    <table id="tb" class="table table-hover">
                                        <thead>
                                            <tr>
                                            <th>S/N</th>
                                            <th>RCN</th>
                                            <th>Title</th>
                                            <th>Surname</th>
                                            <th>First Name</th>
                                            <th>Gender</th>
                                            <th>Phone Number</th>
                                            <th>License Numer</th>
                                            <th>License Expiry Date</th>
                                            <th>Native Language</th>
                                            <th>NIN</th>
                                            <th>Other Names</th>
                                            <th>Birth Date</th>
                                            <th>Blood Group</th>
                                            <th>Marital Status</th>
                                            <th>Nationality</th>
                                            <th>Educational Qualifications</th>
                                            <th>Contact Address</th>
                                            <th>Email Address</th>
                                            <th>Place Of Birth</th>
                                            <th>LGA of Origin</th>
                                            <th>Home of Origin</th>
                                            <th>State of Origin</th>
                                            <th>Residential Address</th>
                                            <th>Country of Birth</th>
                                            <th>LGA of Birth</th>
                                            <th>Height</th>
                                            <th>Employment Status</th>
                                            <th>Profession</th>
                                            <th>Religion</th>
                                            <th>Residential Status</th>
                                            <th>Town of Residence</th>
                                            <th>LGA of Residence</th>
                                            <th>State of Residence</th>
                                            <th>N.O.Kin Spoken Language</th>
                                            <th>N.O.Kin Town of Residence</th>
                                            <th>N.O.Kin First Name</th>
                                            <th>N.O.Kin State of Residence</th>
                                            <th>N.O.Kin Surname</th>
                                            <th>N.O.Kin Middle Name</th>
                                            <th>N.O.Kin LGA of Residence</th>
                                            <th>N.O.Kin Residential Address 1</th>
                                            <th>N.O.Kin Residential Address 2</th>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="./js/update.js"></script>   