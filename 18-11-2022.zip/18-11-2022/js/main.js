function checkLogin(formurl, formurlconvert) {
  var uname = $("#uname").val();
  var pwd = $("#pwd").val();
  $.ajax({
    type: "POST",
    url: "utilities.php",
    data: "op=User.login&uname=" + uname + "&pwd=" + pwd,
    success: (response) => {
      console.log(response);
      var data = JSON.parse(response);
        //alert(response);
         //console.log('Response is '+data.response);
      if (data.response_code == "0") {
        $("#btn-login").prop("disabled", true);
        $("#error_label_login").css("background-color", "rgb(240,30,100");
        $("#error_label_login").css("color", "white");

        $("#btn-login").html(
          '<span class="spinner"><i class="fa fa-spinner fa-spin"></i></span> Logging in...'
        );

        setTimeout(() => {
          $("#form1").attr("action", formurl);
          $("#form1").submit();
        }, 1000);
      } 
      else if(data.response_code == "14")
      {
        $("#btn-login").prop("disabled", true);
        $("#error_label_login").css("background-color", "rgb(240,30,100");
        $("#error_label_login").css("color", "white");

        $("#btn-login").html(
          '<span class="spinner"><i class="fa fa-spinner fa-spin"></i></span> Logging in...'
        );
        setTimeout(() => {
          ////change password on logon
          window.location = 'change_password_logon.php?id='+btoa(uname);
        }, 1000);
      }
      else {
          $("#btn-login").prop("disabled", false);
          $("#error_label_login").html(data.response_message).show();
        }
    },
    error: (err) => {
      console.log(err);
    },
  });
  return false;
}

function ownerDriverLogin(formurl, formurlconvert) {
  var uname = $("#uname").val();
  var pwd = $("#pwd").val();

  $.ajax({
    type: "POST",
    url: "utilities.php",
    data: "op=User.ownerDriverLogin&uname=" + uname + "&pwd=" + pwd,
    success: (response) => {
      console.log(response);
      var data = JSON.parse(response);
      if (data.response_code == "0") {
        $("#portal-login").prop("disabled", true);
        $("#error_label_login").css("background-color", "rgb(240,30,100");
        $("#error_label_login").css("color", "white");

        $("#portal-login").html(
          '<span class="spinner"><i class="fa fa-spinner fa-spin"></i></span> Logging in...'
        );

        setTimeout(() => {
          $("#form1").attr("action", formurl);
          $("#form1").submit();
        }, 1000);
      } else {
        $("#portal-login").prop("disabled", false);
        $("#error_label_login").html(data.response_message).show();
      }
    },
    error: (err) => {
      console.log(err);
    },
  });
  return false;
}

function registerOwner(formurl) {
  var firstname = $("#fname").val();
  var lastname = $("#fname").val();
  var email = $("#email-addr").val();
  var phone = $("#phone-no").val();
  var pwd = $("#pd").val();

  $.ajax({
    type: "POST",
    url: "utilities.php",
    data: {
      op: `User.registerOwner`,
      username: `${email}`,
      firstname: `${firstname}`,
      lastname: `${lastname}`,
      email: `${email}`,
      mobile_phone: `${phone}`,
      password: `${pwd}`,
    },
    success: (response) => {
      // console.log(response);
      var data = JSON.parse(response);
      if (data.response_code == "0") {
        $("#register").prop("disabled", true);
        Swal.fire({
          title: "Success!",
          text: data.elem + " " + data.response_message,
          type: "success",
          confirmButtonText: "Ok",
        }).then((result) => {
          if (result.value) {
            location.href = "login.php";
          }
        });
      } else {
        $("#error_label_login")
          .html(data.elem + " " + data.response_message)
          .show();
      }
    },
    error: (err) => {
      console.log(err);
    },
  });
  return false;
}

function getPage(str, divid) {
  if (str != "#") {
    Swal.fire({
      title: "",
      html: "<b>Loading page, please wait...</b>",
      timer: 0,
      allowOutsideClick: false,
      allowEscapeKey: false,
      onBeforeOpen: () => {
        Swal.showLoading();
      },
    });

    $.ajax({
      type: "POST",
      url: str,
      data: "",
      error: (x, t, m) => {
        console.log("%c 1", "color: red");
        Swal.fire({
          title: "",
          html: "<b>Couldn't load page</b>",
          timer: 0,
          onBeforeOpen: () => {
            Swal.showLoading();
          },
        });

        Swal.close();
      },
      success: (msg) => {
        console.log("%c 1", "color: yellow");
        $("#" + divid)
          .html(msg)
          .animate();

        Swal.close();
      },
    });
  }
}

function callPage(page, page_to_redirect, div_id, uploadFile=false) {
  var data = getData();
  if (data != "error") {
    $.ajax({
      type: "POST",
      url: "utilities.php",
      data: "op=" + page + "&" + data,

      success: (msgContent) => {
        var msg = JSON.parse(msgContent);
        // console.dir(msg);
          //alert(msgContent);
        if (msg.response_code == 0) {
          serverResponse = 0;
          $("#display_message").show("slow");
          $("#display_message").html(msg.response_message);
          if(uploadFile)
          {
              uploadImages(page);   
          }
          // SweetAlert
          Swal.fire({
            title: "Success!",
            text: msg.elem + " " + msg.response_message,
            type: "success",
            confirmButtonText: "Ok",
          });

          setTimeout(() => {
            getPage(page_to_redirect, div_id);
          }, 3000);
          // doFilter();
        } else if (msg.response_code == 1) {
          Swal.fire({
            title: "Error!",
            text: msg.elem + " " + msg.response_message,
            type: "error",
            confirmButtonText: "Ok",
          });
        } else if (msg.response_code == 4) {
          Swal.fire({
            title: "Info!",
            text: msg.response_message,
            type: "info",
            confirmButtonText: "Ok",
          });
          setTimeout(() => {
            getPage(page_to_redirect, div_id);
          }, 3000);
        } else if (msg.response_code == 2) {
          Swal.fire({
            title: "Error!",
            text: msg.elem + " " + msg.response_message,
            type: "error",
            confirmButtonText: "Ok",
          });
        } else if (msg.response_code == -1) {
          Swal.fire({
            title: "Error!",
            text: msg.response_message,
            type: "error",
            confirmButtonText: "Ok",
          });
        } else if (msg.response_code == 23) {
          Swal.fire({
            title: "Error!",
            text: msg.elem + " " + msg.response_message,
            type: "error",
            confirmButtonText: "Ok",
          });
        } else {
          $("#display_message").html(msg.response_message);
          $("#display_message").show("fast");
          $("#display_message").click();
          if (msgContent.indexOf("Error") < 0) {
            if (page == "Roles.createRole") {
              getPage("role_list.php", "page");
            }
            if (page == "User.createUser") {
              // getPage("user_list.php", "page");
            }
            if (page == "Menu.create_menu") {
              getPage("menu_list.php", "page");
            }
          }
        }
      },
      error: (err) => {
        Swal.fire({
          title: "Error!",
          text: "An error occured, \nplease input valid details",
          type: "error",
          confirmButtonText: "Ok",
        });
        console.log("error " + err);
      },
    });
  }
}

function callPageWithImage(page, page_to_redirect, div_id) {
  let myForm = document.getElementById("form1");
  let driver_same_owner = $("#driver_same_owner").val();
  var formData = new FormData(myForm);
  var blob_file = document.querySelector("#doc_path").files[0];
  var blob_owner_file = document.querySelector("#owner_doc_path").files[1];
  formData.append("op", page);
  formData.append("doc_path", blob_file);
  formData.append("owner_doc_path", blob_owner_file);
  formData.append("driver_same_owner", driver_same_owner);
  var d = getData();
  if (d != "error") {
    $.ajax({
      type: "POST",
      url: "utilities.php",
      processData: false,
      cache: false,
      contentType: false,
      data: formData,
      success: (msgContent) => {
        var msg = JSON.parse(msgContent);
        // console.dir(msg);
        if (msg.response_code == 0) {
          $("#display_message").show("slow");
          $("#display_message").html(msg.response_message);

          // SweetAlert
          Swal.fire({
            title: "Success!",
            text: msg.elem + " " + msg.response_message,
            type: "success",
            confirmButtonText: "Ok",
          });

          setTimeout(() => {
            getPage(page_to_redirect, div_id);
          }, 3000);
          // doFilter();
        } else if (msg.response_code == 1) {
          Swal.fire({
            title: "Error!",
            text: msg.elem + " " + msg.response_message,
            type: "error",
            confirmButtonText: "Ok",
          });
        } else if (msg.response_code == 4) {
          Swal.fire({
            title: "Info!",
            text: msg.response_message,
            type: "info",
            confirmButtonText: "Ok",
          });
          setTimeout(() => {
            getPage(page_to_redirect, div_id);
          }, 3000);
        } else if (msg.response_code == 2) {
          Swal.fire({
            title: "Error!",
            text: msg.elem + " " + msg.response_message,
            type: "error",
            confirmButtonText: "Ok",
          });
        } else if (msg.response_code == -1) {
          Swal.fire({
            title: "Error!",
            text: msg.response_message,
            type: "error",
            confirmButtonText: "Ok",
          });
        } else if (msg.response_code == 23) {
          Swal.fire({
            title: "Error!",
            text: msg.elem + " " + msg.response_message,
            type: "error",
            confirmButtonText: "Ok",
          });
        } else {
          $("#display_message").html(msg.response_message);
          $("#display_message").show("fast");
          $("#display_message").click();
          if (msgContent.indexOf("Error") < 0) {
            if (page == "Roles.createRole") {
              getPage("role_list.php", "page");
            }
            if (page == "User.createUser") {
              // getPage("user_list.php", "page");
            }
            if (page == "Menu.create_menu") {
              getPage("menu_list.php", "page");
            }
          }
        }
      },
      error: (err) => {
        Swal.fire({
          title: "Error!",
          text: "An error occured, \nplease input valid details",
          type: "error",
          confirmButtonText: "Ok",
        });
        console.log("error " + err);
      },
    });
  }
}

function cancel(params) {
  switch (params) {
    case "pension":
      getPage("pension_matter.php", "page");
      break;
    case "tax":
      getPage("tax_matter.php", "page");
      break;
    case "vend":
      getPage("vendor_list.php", "page");
      break;
    case "user":
      getPage("user_data.php", "page");
      break;

    default:
      break;
  }
}

function doSearch(url) {
  var data = getData();
  getPage(url + "?" + data, "page");
}

function doSearch1(url, divid) {
  var data = getData();
  getPage(url + "?" + data, divid);
}

function goFirst(dpage) {
  var lpage = parseInt($("#tpages").val());
  var fpage = parseInt($("#fpage").val());
  if (fpage != 1) {
    $("#fpage").get(0).value = "1";
    $("#pageNo").get(0).value = 1;
    doSearch(dpage);
  } else {
    return false;
  }
}

function goLast(dpage) {
  var lpage = parseInt($("#tpages").val());
  var fpage = parseInt($("#fpage").val());
  if (lpage != fpage) {
    $("#fpage").get(0).value = lpage;
    $("#pageNo").get(0).value = lpage;
    doSearch(dpage);
  } else {
    return false;
  }
}

function goPrevious(dpage) {
  var lpage = parseInt($("#tpages").val());
  var fpage = parseInt($("#fpage").val());
  if (fpage != 1) {
    $("#fpage").get(0).value = fpage - 1;
    $("#pageNo").get(0).value = fpage - 1;
    doSearch(dpage);
  } else {
    return false;
  }
}

function goNext(dpage) {
  var lpage = parseInt($("#tpages").val());
  var fpage = parseInt($("#fpage").val());
  if (lpage > fpage) {
    $("#fpage").get(0).value = fpage + 1;
    $("#pageNo").get(0).value = fpage + 1;
    doSearch(dpage);
  } else {
    return false;
  }
}

function doClickAll(form) {
  var form = document.getElementById("form1");
  for (var i = 0; i < form.elements.length; i++) {
    if (form.elements[i].type == "checkbox") {
      if (!form.elements[i].checked) {
        form.elements[i].click();
      }
    }
  }
  return true;
}

function doUnClickAll(form) {
  for (var i = 0; i < form.elements.length; i++) {
    if (form.elements[i].type == "checkbox") {
      if (form.elements[i].checked) {
        form.elements[i].checked = false;
      }
    }
  }
  return true;
}

function checkSelected(form, url) {
  var parString = "";
  var delcount = 0;
  for (var i = 0; i < form.elements.length; ++i)
    if (
      (form.elements[i].type == "checkbox") &
      (form.elements[i].name == "chkopt")
    )
      if (form.elements[i].checked == true) {
        delcount++;
        parString = parString + "-" + form.elements[i].value + "-, ";
      }

  if (parString == "") {
    window.alert("Select record(s) to continue...");
    return false;
  } else {
    //delcount = delcount - 1;
    form.var1.value = parString;
    form.op.value = "del";
    ans = window.confirm(
      "You have selected " + delcount + " record(s), Are your sure ?"
    );
    if (ans == 1) {
      doSearch(url);
      return false;
    } else return false;
  }
}

function checkSelected1(form, url, divid) {
  var parString = "";
  var delcount = 0;
  for (var i = 0; i < form.elements.length; ++i)
    if (
      (form.elements[i].type == "checkbox") &
      (form.elements[i].name == "chkopt")
    )
      if (form.elements[i].checked == true) {
        delcount++;
        parString = parString + "-" + form.elements[i].value + "-, ";
      }

  if (parString == "") {
    window.alert("Check Friend(s) to continue...");
    return false;
  } else {
    form.var1.value = parString;
    form.op.value = "del";
    ans = window.confirm(
      "You have selected " + delcount + " Friend(s), Are your sure ?"
    );
    if (ans == 1) {
      doSearch1(url, divid);
      return false;
    } else return false;
  }
}

function printDiv(seldiv) {
  var divToPrint = document.getElementById(seldiv);
  var newWin = window.open();
  newWin.document.open();
  newWin.document.write(
    "<html><body>" + divToPrint.innerHTML + "</body></html>"
  );
  newWin.document.close();
}

function printReceipt(seldiv) {
  var divToPrint = document.getElementById(seldiv);
  var newWin = window.open();
  newWin.document.write(
    '<html><link rel="stylesheet" type="text/css" href="css/style.css"><body onload="window.print()">' +
      divToPrint.innerHTML +
      "</body></html>"
  );
  newWin.document.close();
}

function checkTextvalues(formElement) {
  if (trimInput(formElement.val()) == "") {
    $("#display_message").html(
      '<div class="alert alert-info">please enter value for ' +
        formElement.attr("title") +
        "</div>"
    );
    $("#display_message").show("fast");
    formElement.focus();
    $("#display_message").click();
    return false;
  } else return true;
}

function checkChkbox(formElement) {
  if (trimInput($(this).prop("checked") == false)) {
    $("#display_message").html(
      '<div class="alert alert-info">please enter value for ' +
        formElement.attr("title") +
        "</div>"
    );
    $("#display_message").show("fast");
    formElement.focus();
    $("#display_message").click();
    return false;
  } else return true;
}

function checkNumbers(formElement) {
  if (trimInput(formElement.val()) == "") {
    $("#display_message").html(
      '<div class="alert alert-info">please enter number for : ' +
        formElement.attr("title") +
        "</div>"
    );
    $("#display_message").show("fast");
    formElement.focus();
    $("#display_message").click();
    return false;
  }
  if (isNaN(formElement.val())) {
    $("#display_message").html(
      '<div class="alert alert-info">please enter number for : ' +
        formElement.attr("title") +
        "</div>"
    );
    $("#display_message").show("fast");
    formElement.focus();
    $("#display_message").click();
    return false;
  } else return true;
}

function checkEmail(formElement) {
  var emails = formElement.val();
  emailRegEx = new RegExp(
    /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
  );
  if (emails == "") return true;
  if (formElement.val().search(emailRegEx) == -1) {
    $("#display_message").html(
      '<div class="alert alert-info">please enter valid email for : ' +
        formElement.attr("title") +
        "</div>"
    );
    $("#display_message").show("fast");
    formElement.focus();
    $("#display_message").click();
    return false;
  } else return true;
}

function checkCaptcha(formElement) {
  var captcha = formElement.val();
  var captcha_sess = $("#captcha_sess").val();
  //alert(captcha);
  //alert(captcha_sess);
  if (captcha != captcha_sess) {
    $("#display_message").html(
      '<div class="alert alert-info">Please Enter Figures Displayed in ImageCaptcha into textbox above</div>'
    );
    $("#display_message").show("fast");
    formElement.focus();
    $("#display_message").click();
    return false;
  } else return true;
}

function checkPasswordAplhanumeric(formElement) {
  var f1 = /[A-Z]/;
  var f2 = /[a-z]/;
  var f3 = /[0-9]/;

  if (
    (f1.test(formElement.val()) || f2.test(formElement.val())) &&
    f3.test(formElement.val())
  ) {
    return true;
  } else {
    $("#display_message").html(
      '<div class="alert alert-info">please enter alphanumeric as password</div>'
    );
    $("#display_message").show("fast");
    //alert('failed');
    formElement.focus();
    $("#display_message").click();
    return false;
  }
}

function checkPassword(formElement) {
  var password = formElement.val();
  var errorval = "";
  var passed = validatePassword(password, {
    length: [6, 8],
    lower: 0,
    upper: 0,
    numeric: 0,
    special: 0,
    badWords: ["password", "steven", "levithan"],
    badSequenceLength: 4,
  });
  if (!chkpassword() || !passed) {
    $("#display_message").html(errorval);
    $("#display_message").show("fast");
    formElement.focus();
    $("#display_message").click();
    return false;
  }
}

function trimInput(inputString) {
  var removeChar = " ";
  var returnString = inputString;
  if (removeChar.length) {
    while ("" + returnString.charAt(0) == removeChar) {
      returnString = returnString.substring(1, returnString.length);
    }
    while ("" + returnString.charAt(returnString.length - 1) == removeChar) {
      returnString = returnString.substring(0, returnString.length - 1);
    }
  }
  return returnString;
}

function checkOption(obj) {
  if (obj.checked) {
    obj.value = "1";
  } else {
    obj.value = "0";
    obj.checked = false;
  }
}

function toggleVehicleCategory(element, category) {
  if (element.checked) {
    element.value = category;
  } else {
    element.value = "";
    element.checked = false;
  }
}

function ttoggleOption() {
  $.each($("input:checkbox"), function (i, v) {
    if ($(this).is(":checked")) {
      $(this).val("1");
    } else {
      $(this).val("0");
    }
  });
}

function getData() {
  var data = "";
  $("#form1").serialize();
  $.each($("input, select, textarea"), function (i, v) {
    var theTag = v.tagName;
    var theElement = $(v);
    var theName = theElement.attr("name");
    var theValue = escape(theElement.val());
    var classname = theElement.attr("class");
    if (theElement.hasClass("required-text")) {
      if (!checkTextvalues(theElement)) data = "error";
    }
    if (classname == "required-number") {
      if (!checkNumbers(theElement)) data = "error";
    }
    if (classname == "required-email") {
      if (!checkEmail(theElement)) data = "error";
    }
    if (classname == "not-required-email") {
      if (!checkEmail(theElement)) data = "error";
    }
    if (classname == "required-alphanumeric") {
      if (!checkPasswordAplhanumeric(theElement)) data = "error";
    }
    if (classname == "required-password") {
      if (!checkPassword(theElement)) data = "error";
    }
    if (classname == "required-captcha") {
      if (!checkCaptcha(theElement)) data = "error";
    }
    if (data != "error") {
      data = data + theName + "=" + theValue + "&";
    }
  });
  return data;
}

function loadRoles() {
  var data = escape($("#menu_id").val());
  $.ajax({
    type: "POST",
    url: "utilities.php",
    data: "op=MenuGroup.getNonExistentRole&menu_id=" + data,
    success: function (msg) {
      console.log(msg);
      $("#non_exist_role").html(msg);
    },
    error: function (err) {
      console.log(err);
    },
  });
  $.ajax({
    type: "POST",
    url: "utilities.php",
    data: "op=MenuGroup.getExistentRole&menu_id=" + data,
    success: function (msg) {
      $("#exist_role").html(msg);
    },
    error: function (err) {
      console.log(err);
    },
  });
}

function moveUpRole() {
  var listField = document.getElementById("exist_role");
  if (listField.length == -1) {
    // If the list is empty
    alert("There are no values which can be moved!");
  } else {
    var selected = listField.selectedIndex;
    if (selected == -1) {
      alert("You must select an entry to be moved!");
    } else {
      if (listField.length == 0) {
        // If there's only one in the list
        alert("There is only one entry!\nThe one entry will remain in place.");
      } else {
        // There's more than one in the list, rearrange the list order
        if (selected == 0) {
          alert("The first entry in the list cannot be moved up.");
        } else {
          // Get the text/value of the one directly above the hightlighted entry as
          // well as the highlighted entry; then flip them
          var moveText1 = listField[selected - 1].text;
          var moveText2 = listField[selected].text;
          var moveValue1 = listField[selected - 1].value;
          var moveValue2 = listField[selected].value;
          listField[selected].text = moveText1;
          listField[selected].value = moveValue1;
          listField[selected - 1].text = moveText2;
          listField[selected - 1].value = moveValue2;
          listField.selectedIndex = selected - 1; // Select the one that was selected before
        } // Ends the check for selecting one which can be moved
      } // Ends the check for there only being one in the list to begin with
    } // Ends the check for there being element selected
  } // Ends the check for there being none in the list
}

function moveDownRole() {
  var listField = document.getElementById("exist_role");
  if (listField.length == -1) {
    // If the list is empty
    alert("There are no values which can be moved!");
  } else {
    var selected = listField.selectedIndex;
    if (selected == -1) {
      alert("You must select an entry to be moved!");
    } else {
      // Element is selected
      if (listField.length == 0) {
        // If there's only one in the list
        alert("There is only one entry!\nThe one entry will remain in place.");
      } else {
        // There's more than one in the list, rearrange the list order
        if (selected == listField.length - 1) {
          alert("The last entry in the list cannot be moved down.");
        } else {
          // Get the text/value of the one directly below the hightlighted entry as
          // well as the highlighted entry; then flip them
          var moveText1 = listField[selected + 1].text;
          var moveText2 = listField[selected].text;
          var moveValue1 = listField[selected + 1].value;
          var moveValue2 = listField[selected].value;
          listField[selected].text = moveText1;
          listField[selected].value = moveValue1;
          listField[selected + 1].text = moveText2;
          listField[selected + 1].value = moveValue2;
          listField.selectedIndex = selected + 1; // Select the one that was selected before
        } // Ends the check for selecting one which can be moved
      } // Ends the check for there only being one in the list to begin with
    } // Ends the check for there being element selected
  } // Ends the check for there being none in the list
}

function addRole() {
  return !$("#non_exist_role option:selected").remove().appendTo("#exist_role");
}

function removeRole() {
  return !$("#exist_role option:selected").remove().appendTo("#non_exist_role");
}

function selectAllData() {
  $("#exist_role *").attr("selected", "selected");
}

function toggleOption() {
  $("input[type=checkbox]").each(function () {
    if ($(this).is(":checked")) {
      var idname = $(this).attr("id");
      $(this).val(idname);
      //alert($(this).val());
    } else {
      $(this).val("");
    }
  });
}

function resize(imgId, division_1, division_2) {
  var img = document.getElementById(imgId);
  var w = img.width,
    h = img.height;
  w /= division_1;
  h /= division_2;
  img.width = w;
  img.height = h;
}

function selectAllList(list) {
  $("#" + list + " *").attr("selected", "selected");
}

function pageLoader(str, divid) {
  var data = getData();
  if (data != "error") {
    $.ajax({
      type: "POST",
      url: str,
      data: data,
      success: function (msg) {
        $("#" + divid).html(msg);
      },
    });
  }
}

function moveUpList(listField) {
  if (listField.length == -1) {
    // If the list is empty
    alert("There are no values which can be moved!");
  } else {
    var selected = listField.selectedIndex;
    if (selected == -1) {
      alert("You must select an entry to be moved!");
    } else {
      // Element is selected
      if (listField.length == 0) {
        // If there's only one in the list
        alert("There is only one entry!\nThe one entry will remain in place.");
      } else {
        // There's more than one in the list, rearrange the list order
        if (selected == 0) {
          alert("The first entry in the list cannot be moved up.");
        } else {
          // Get the text/value of the one directly above the hightlighted entry as
          // well as the highlighted entry; then flip them
          var moveText1 = listField[selected - 1].text;
          var moveText2 = listField[selected].text;
          var moveValue1 = listField[selected - 1].value;
          var moveValue2 = listField[selected].value;
          listField[selected].text = moveText1;
          listField[selected].value = moveValue1;
          listField[selected - 1].text = moveText2;
          listField[selected - 1].value = moveValue2;
          listField.selectedIndex = selected - 1; // Select the one that was selected before
        } // Ends the check for selecting one which can be moved
      } // Ends the check for there only being one in the list to begin with
    } // Ends the check for there being element selected
  } // Ends the check for there being none in the list
  return false;
}

function moveDownList(listField) {
  if (listField.length == -1) {
    // If the list is empty
    alert("There are no values which can be moved!");
  } else {
    var selected = listField.selectedIndex;
    if (selected == -1) {
      alert("You must select an entry to be moved!");
    } else {
      // Element is selected
      if (listField.length == 0) {
        // If there's only one in the list
        alert("There is only one entry!\nThe one entry will remain in place.");
      } else {
        // There's more than one in the list, rearrange the list order
        if (selected == listField.length - 1) {
          alert("The last entry in the list cannot be moved down.");
        } else {
          // Get the text/value of the one directly below the hightlighted entry as
          // well as the highlighted entry; then flip them
          var moveText1 = listField[selected + 1].text;
          var moveText2 = listField[selected].text;
          var moveValue1 = listField[selected + 1].value;
          var moveValue2 = listField[selected].value;
          listField[selected].text = moveText1;
          listField[selected].value = moveValue1;
          listField[selected + 1].text = moveText2;
          listField[selected + 1].value = moveValue2;
          listField.selectedIndex = selected + 1; // Select the one that was selected before
        } // Ends the check for selecting one which can be moved
      } // Ends the check for there only being one in the list to begin with
    } // Ends the check for there being element selected
  } // Ends the check for there being none in the list
  return false;
}

$(document).on("change", "#product_file", function (evt) {
  handleFileSelect(evt);
});

//  var file = document.querySelector('#files > input[type="file"]').files[0];
//  getBase64(file); // prints the base64 string
// Check for the File API support.
if (window.File && window.FileReader && window.FileList && window.Blob) {
  //	document.getElementById('files').addEventListener('change', handleFileSelect, false);
} else {
  alert("The File APIs are not fully supported in this browser.");
}

function handleFileSelect(evt, opt) {
  var f = evt.target.files[0]; // FileList object
  var reader = new FileReader();
  // Closure to capture the file information.
  reader.onload = (function (theFile) {
    return function (e) {
      var binaryData = e.target.result;
      //Converting Binary Data to base 64
      var base64String = window.btoa(binaryData);
      //showing file converted to base64
      document.getElementById("base_64_container").value =
        "data:image/jpg;base64," + base64String;

      var getElem = document.getElementById("base_64_container").value;
      var hold_img = document.querySelector("#hold_img");
      hold_img.src = getElem;

      // alert('File converted to base64 successfuly!\nCheck in Textarea');
    };
  })(f);
  // Read in the image file as a data URL.
  reader.readAsBinaryString(f);
}

function dump(obj, opt) {
  var out = "";
  for (var i in obj) {
    out += i + ": " + obj[i] + "\n";
  }
  switch (opt) {
    case "alert":
      alert(out);
      break;
    case "log":
      console.log(out);
      break;
    case "dir":
      console.dir(out);
      break;

    default:
      break;
  }

  // or, if you wanted to avoid alerts...

  var pre = document.createElement("pre");
  pre.innerHTML = out;
  document.body.appendChild(pre);
}

$(document).on("click", ".save_content", function (ev) {
  var formdata = new FormData();
  formdata.append("product_file", $("#base_64_container").val());
  formdata.append("op", "Products.doProduct");
  formdata.append("product_id", $("#product_id").val());
  formdata.append("product_name", $("#product_name").val());
  formdata.append("product_description", $("#product_description").val());
  formdata.append("created_at", $("#created-at").val());
  console.log(formdata);
  $.ajax(
    {
      type: "POST",
      url: "utilities.php",
      processData: false,
      contentType: false,
      cache: false,
      data: formdata,
      success: function (response) {
        if (response == 1) {
          getPage("view_product.php", "page");
        } else {
          console.log("error");
        }
      },
    },
    (error) => {
      console.log(error);
    }
  );
});

function loadPassportNos() {
  var data = escape($("#entry-officer").val());
  $.ajax({
    type: "POST",
    url: "utilities.php",
    data: "op=Passport.getUnassignedPassport&officer=" + data,
    success: function (msg) {
      console.log(msg);
      $("#unassigned-p-no").html(msg);
    },
    error: function (err) {
      console.log(err);
    },
  });

  $.ajax({
    type: "POST",
    url: "utilities.php",
    data: "op=Passport.getAssignedPassport&officer=" + data,
    success: function (msg) {
      $("#assigned-p-no").html(msg);
    },
    error: function (err) {
      console.log(err);
    },
  });
}

function addPassportNo() {
  return !$("#unassigned-p-no option:selected")
    .remove()
    .appendTo("#assigned-p-no");
}

function removePassportNo() {
  return !$("#assigned-p-no option:selected")
    .remove()
    .appendTo("#unassigned-p-no");
}

function selectAllPassportNos() {
  $("#assigned-p-no *").attr("selected", "selected");
}

function fireSwal(
  title = "Swal",
  html = "Some text",
  type = "success",
  showCancelBtn = false,
  confirmBtnColor = "#3085d6",
  cancelBtnColor = "#d33",
  confirmButtonText = "Yes",
  cancelButtonText = "No"
) {
  return Swal.fire({
    title: title,
    html: html,
    type: type,
    showCancelButton: showCancelBtn,
    confirmButtonColor: confirmBtnColor,
    cancelButtonColor: cancelBtnColor,
    confirmButtonText: confirmButtonText,
    cancelButtonText: cancelButtonText,
    onClose: () => {
      Swal.close();
    },
  });
}

function printModalDiv(
  seldiv,
  title = "Report List",
  linkToUse = "",
  moreElementsToHide = []
) {
  elementsToHide = moreElementsToHide.join(",");

  var divToPrint = document.getElementById(seldiv);
  var newWin = window.open();
  newWin.document.open();
  newWin.document.write(
    `<html><head><title>${title}</title><style>tr:not(.visible),
    .dataTables_length,
    .dataTables_filter,
    .dataTables_info,
    .dataTables_paginate,
    .paging_simple_numbers, ${elementsToHide} {
        display: none !important;
    }</style></head><link rel="stylesheet" href="assets/css/classic.css"><link rel="stylesheet" href="${linkToUse}"><body><h3 id="title">${title}</h3>${divToPrint.innerHTML}</body></html>`
  );
  // newWin.document.close();
}

function guardedPrint(moreElementsToHide = []) {
  // elementsToHide = [
  //   // ".dataTables_length",
  //   // ".dataTables_filter",
  //   // ".dataTables_info",
  //   // ".dataTables_paginate",
  //   // ".paging_simple_numbers",
  //   // "th:nth-child(2)",
  //   // "td:nth-child(2)",
  //   // "th:nth-child(12)",
  //   // "td:nth-child(12)",
  // ];

  // elementsToHide.forEach((element) => {
  //   $(element).css({ display: "none" });
  // });

  moreElementsToHide.forEach((element) => {
    $(element).css({ display: "none" });
  });
}

function validateNIN(nin) {
  if (nin === "") {
    return "NIN is empty";
  } else if (nin.length !== "17") {
    return "Invalid NIN length";
  } else {
    return true;
  }
}


///Tosin's addition 16-12-2021
function  uploadImages(filetag)
{
    /*const url = 'process_multiple_images.php?id='+pid;
    //const files = document.querySelector('[type=file]').files;
    const formData = new FormData();
     /* for (let i = 0; i < files.length; i++) {
        let file = files[i]

         formData.append('files[]', file);
      }

      fetch(url, {
        method: 'POST',
        body: formData,
      }).then((response) => {
        console.log(response)
      });*/
    const url = 'ajax/process_files.php?tag='+filetag;
    const files = document.querySelector('[type=file]').files;
    const formData = new FormData();
    $("[type='file']").each(function(){
        var fid  = $(this).attr("id");
        var file = $(this)[0].files[0];
         formData.append('files['+fid+']', file);
        //console.log(fid+"   "+file);
    });
    fetch(url, {
        method: 'POST',
        body: formData,
      }).then((response) => {
        console.log(response)
      });
}
function getValidPhoneNumber(value)
{
    value = $.trim(value).replace(/\D/g, '');

    if (value.substring(0, 1) != '0') {
        return false;//value = value.substring(1);
    }

    if (value.length == 11) {

        return true;
    }

    return false;
}
