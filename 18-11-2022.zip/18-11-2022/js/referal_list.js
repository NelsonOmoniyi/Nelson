var counter = 0;
    var INCname = 0;
    $(document).ready(() => {
        datatable_init('tb', 'referalList');
        table.order([5, 'ASC']).draw();

        $('#keyword, #searchby').keydown(() => {
            doFilter();
        })
        $('#keyword, #searchby').blur(() => {
            doFilter();
        })
    })

    $('#new-referal').click(() => {
        $("#referal_id").val($('#h-id').val());
        $("#phone").val("");
    })
        // remove row
        $(document).on('click', '#removeRow', function () {
            $(this).closest('#row').remove();
        });
  
