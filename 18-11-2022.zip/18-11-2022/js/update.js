$(document).ready(() => {
    datatable_init('tb', 'Incomplete');
    table.order([5, 'ASC']).draw();

    $('#keyword, #searchby').keydown(() => {
        doFilter();
    })
    $('#keyword, #searchby').blur(() => {
        doFilter();
    })
});