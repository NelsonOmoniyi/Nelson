function checkPP(className, method, fileToReturn, div = "box",uploadFile=false) {

  if ($("#form1").parsley().isValid()) {
    var dd = $("#form1").serialize();
    // var pin = $("#pin").val();
    // var phone = $("#phone").val();
    if (dd != "error") {
      pin = $("#pin").val();
       phone = $("#phone").val();
      //  alert('Pin=='+pin+',  &&&  Phone Number =='+phone)
      $.ajax({
        type: "post",
        url: "ajax/valref.php",
        data: { info: dd},
        success: function (response) {
          re = JSON.parse(response);
          console.log(re);
          if (re.response_code == 20) {
            var name = re.name;
            var dob = re.dob;
            var nin = re.nin;
            var plate = re.plate;

            $("#close").click();
            callPage(className + "." + method, fileToReturn+'?pinVal='+pin+'&phoneVal='+phone+'&name='+name+'&nin='+nin+'&dob='+dob+'&plate='+plate, div,uploadFile);
          } else if(re.response_code == 0){
            pin = $("#pin").val();
            phone = $("#phone").val();

            $("#close").click();
            callPage(className + "." + method, fileToReturn+'?pinVal='+pin+'&phoneVal='+phone, div,uploadFile);

            
          }else{
            Swal.fire({
              title: "Error!",
              text: "Invalid Phone Number Or PIN",
              type: "info",
              confirmButtonText: "Ok",
            });
          }
        },
      });
    }
  } else {
    Swal.fire({
      title: "Error!",
      text: "Invalid data entered, please check input fields",
      type: "info",
      confirmButtonText: "Ok",
    });
    $("#form1").parsley().validate();
  }

}

function checkValid(className, method, fileToReturn, div = "box",uploadFile=false) {
  if ($("#form1").parsley().isValid()) {
    var data = $("#form1").serialize();
    if (data != "error") {
      // $("#close").click();
      if ($("#check").val() != '') {
        $("#close").click();
        callPage(className + "." + method, fileToReturn, div,uploadFile);
      }else{
      // window.alert("Not FINE");
        Swal.fire({
          title: "Error!",
          text: "Violation Section Cannot Be Empty, Pls Add Violation",
          type: "info",
          confirmButtonText: "Ok",
        });
        $("#form1").parsley().validate();
      }
    }else{
      Swal.fire({
        title: "Error!",
        text: "Violation Section Cannot Be Empty, Pls Add Violation",
        type: "info",
        confirmButtonText: "Ok",
      });
      $("#form1").parsley().validate();
    }
  }else{
    Swal.fire({
      title: "Error!",
      text: "Invalid data entered, please check input fields",
      type: "info",
      confirmButtonText: "Ok",
    });
    $("#form1").parsley().validate();
  }
}

function checkValidWithImage(className, fileToReturn, div = "box") {
  if ($("#form1").parsley().isValid()) {
    var data = $("#form1").serialize();
    if (data != "error") {
      $("#close").click();
      callPageWithImage(className, fileToReturn, div);
    }
  } else {
    Swal.fire({
      title: "Error!",
      text: "Invalid data entered, please check input fields",
      type: "info",
      confirmButtonText: "Ok",
    });
    // $("#form1").parsley().validate();
  }
}
/**
 * Menu actions
 * @param {int} menu__id
 */
function editMenu(menu__id) {
  Swal.fire({
    title: "",
    html: "<b>Loading page, please wait...</b>",
    timer: 0,
    allowOutsideClick: false,
    allowEscapeKey: false,
    onBeforeOpen: () => {
      Swal.showLoading();
    },
  });
  $.ajax({
    type: "post",
    url: "ajax/ajax_edit_menu.php",
    data: { menuID: menu__id },
    success: function (response) {
      Swal.close();
      data = JSON.parse(response);
      if (data.response_code == 0) {
        $("#menu-id").val(data.menu_id);
        $("#menu-id").prop("disabled", true);

        $("#menu-name").val(data.menu_name);

        $("#url").val(data.menu_url);

        $("#parent-menu").val(data.parent_menu);

        $("#icon").val(data.icon);
      } else {
        $("#menu-id").val("");
        $("#menu-name").val("");
        $("#url").val("");
        $("#parent-menu").val("");
      }
    },
  });
}

function deleteMenu(menu__id) {
  Swal.fire({
    title: "Confirm operation",
    text: "Are you sure you want to delete menu?",
    type: "question",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
  }).then((result) => {
    if (result.value) {
      $.ajax({
        type: "post",
        url: "ajax/ajax_del_menu.php",
        data: { menuID: menu__id },
        success: function (response) {
          data = JSON.parse(response);
          if (data.response_code == 0) {
            doFilter();
            Swal.fire({
              title: "Success!",
              text: data.response_message,
              type: "success",
              confirmButtonText: "Ok",
            });
          } else {
            Swal.fire({
              title: "Error!",
              text: data.response_message,
              type: "error",
              confirmButtonText: "Ok",
            });
          }
        },
      });
    }
  });
}
/**
 * Menu actions end
 * @param {*} menu__id
 */

/**
 * Role actions
 * @param {*} role__id
 */
function saveRole(role__id) {
  Swal.fire({
    title: "",
    html: "<b>Loading page, please wait...</b>",
    timer: 0,
    allowOutsideClick: false,
    allowEscapeKey: false,
    onBeforeOpen: () => {
      Swal.showLoading();
    },
  });
  $.ajax({
    type: "post",
    url: "ajax/ajax_edit_role.php",
    data: { roleID: role__id },
    success: function (response) {
      data = JSON.parse(response);
      Swal.close();
      if (data.response_code == 0) {
        $("#role_id").val(data.role_id);
        $("#role_id").prop("disabled", true);

        $("#role_name").val(data.role_name);
      } else {
        $("#role_id").val("");
        $("#role_name").val("");
      }
    },
  });
}

function deleteRole(role__id) {
  Swal.fire({
    title: "Confirm operation",
    text: "Are you sure you want to delete role?",
    type: "question",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
  }).then((result) => {
    if (result.value) {
      $.ajax({
        type: "post",
        url: "ajax/ajax_del_role.php",
        data: { roleID: role__id },
        success: function (response) {
          data = JSON.parse(response);
          if (data.response_code == 0) {
            doFilter();
            Swal.fire({
              title: "Success!",
              text: data.response_message,
              type: "success",
              confirmButtonText: "Ok",
            });
          } else {
            Swal.fire({
              title: "Error!",
              text: data.response_message,
              type: "error",
              confirmButtonText: "Ok",
            });
          }
        },
      });
    }
  });
}
/**
 * Role actions end
 * @param {*} role__id
 */

/**
 * User actions
 * @param {*} username
 */
function editUser(username) {
  $("#operation").val("edit");
  Swal.fire({
    title: "",
    html: "<b>Loading page, please wait...</b>",
    timer: 0,
    allowOutsideClick: false,
    allowEscapeKey: false,
    onBeforeOpen: () => {
      Swal.showLoading();
    },
  });
  $.ajax({
    type: "post",
    url: "ajax/ajax_edit_user.php",
    data: { userID: username },
    success: function (response) {
      let data = JSON.parse(response);
      Swal.close();
      if (data.response_code == 0) {
        $("#username").val(data.un);
        $("#username").prop("disabled", true);
        $("#role_id").val(data.r_id);
        $("#license_operator").val(data.license_operator);
        $("#firstname").val(data.fn);
        $("#lastname").val(data.ln);
        $("#password").val(data.pwd);
        $("#npswd").val(data.pwd);
        $("#email").val(data.email);
        $("#mobile_phone").val(data.phone);
        $("#address").val(data.address);
        $("#council").val(data.council);

        $("#user_locked").prop("checked", data.user_locked);
        $("#user_disabled").prop("checked", data.user_disabled);
        $("#day_1").prop("checked", data.d_val[0]);
        $("#day_2").prop("checked", data.d_val[1]);
        $("#day_3").prop("checked", data.d_val[2]);
        $("#day_4").prop("checked", data.d_val[3]);
        $("#day_5").prop("checked", data.d_val[4]);
        $("#day_6").prop("checked", data.d_val[5]);
        $("#day_7").prop("checked", data.d_val[6]);
      } else {
        $("#username").val("");
        $("#role_id").val("");
        $("#license_operator").val("");
        $("#firstname").val("");
        $("#lastname").val("");
        $("#password").val("");
        $("#npswd").val("");
        $("#email").val("");
        $("#mobile_phone").val("");
        $("#address").val("");
        $("#council").val("");

        $("#user_locked").val("");
        $("#user_disabled").val("");
        $("#day_1").val("");
        $("#day_2").val("");
        $("#day_3").val("");
        $("#day_4").val("");
        $("#day_5").val("");
        $("#day_6").val("");
        $("#day_7").val("");
        $("#user_locked").prop("checked", false);
        $("#user_disabled").prop("checked", false);
        $("#day_1").prop("checked", false);
        $("#day_2").prop("checked", false);
        $("#day_3").prop("checked", false);
        $("#day_4").prop("checked", false);
        $("#day_5").prop("checked", false);
        $("#day_6").prop("checked", false);
        $("#day_7").prop("checked", false);
      }
    },
  });
}

function disableUser(username) {
  Swal.fire({
    title: "Disable User?",
    text: "Are you sure you want to delete menu",
    type: "question",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
  }).then((result) => {
    if (result.value) {
      $.ajax({
        type: "post",
        url: "ajax/ajax_action_user.php",
        data: { user: username },
        success: function (response) {
          data = JSON.parse(response);
          if (data.response_code == 0) {
            Swal.close();
            getPage("menu_list.php", "box");
            Swal.fire({
              title: "Success!",
              text: data.response_message,
              type: "success",
              confirmButtonText: "Ok",
            });
          } else {
            Swal.fire({
              title: "Error!",
              text: data.response_message,
              type: "error",
              confirmButtonText: "Ok",
            });
          }
        },
      });
    }
  });
}
/**
 * Role actions end
 * @param {*} username
 */

/**
 * Vehicle actions
 * @param {number} cat_id
 */
function editVehicleCat(cat_id) {
  $("#operation").val("edit");
  Swal.fire({
    title: "",
    html: "<b>Loading page, please wait...</b>",
    timer: 0,
    allowOutsideClick: false,
    allowEscapeKey: false,
    onBeforeOpen: () => {
      Swal.showLoading();
    },
  });
  $.ajax({
    type: "post",
    url: "ajax/ajax_edit_vehicle_cat.php",
    data: { vehicleCatId: cat_id },
    success: function (response) {
      let data = JSON.parse(response);
      Swal.close();
      if (data.response_code == 0) {
        $("#veh_cat_id").val(data.veh_cat_id);
        $("#veh_cat").val(data.veh_cat);
        $("#veh-code").val(data.veh_code);
      } else {
        $("#veh_cat_id").val("");
        $("#veh_cat").val("");
        $("#veh-code").val(data.veh_code);
      }
    },
  });
}

function deleteVehicleCat(veh_cat_id) {
  Swal.fire({
    title: "Confrim operation",
    text: "Are you sure you want to delete category?",
    type: "question",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
  }).then((result) => {
    if (result.value) {
      $.ajax({
        type: "post",
        url: "ajax/ajax_del_veh_cat.php",
        data: { vehCatId: veh_cat_id },
        success: function (response) {
          data = JSON.parse(response);
          if (data.response_code == 0) {
            doFilter();
            Swal.fire({
              title: "Success!",
              text: data.response_message,
              type: "success",
              confirmButtonText: "Ok",
            });
          } else {
            Swal.fire({
              title: "Error!",
              text: data.response_message,
              type: "error",
              confirmButtonText: "Ok",
            });
          }
        },
      });
    }
  });
}
/**
 * Vehicle category actions end
 * @param {number} cat_id
 */

function enable_disable(username) {
  $.ajax({
    type: "post",
    url: "ajax/enable_disable.php",
    data: {
      uname: username,
    },
    success: function (response) {
      doFilter();
      data = JSON.parse(response);
      if (data.response_code == 0) {
        Swal.fire({
          title: "Success!",
          text: data.msg,
          type: "success",
          confirmButtonText: "Ok",
        });
      } else if (data.response_code == 10) {
        Swal.fire({
          title: "Success!",
          text: data.msg,
          type: "success",
          confirmButtonText: "Ok",
        });
      }
    },
    error: function (err) {
      console.log(err);
    },
  });
}

function deleteVehicleList(veh_id) {
  Swal.fire({
    title: "Confirm operation",
    text: "Are you sure you want to delete vehicle?",
    type: "question",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
  }).then((result) => {
    if (result.value) {
      $.ajax({
        type: "post",
        url: "ajax/ajax_del_vehicle.php",
        data: { vehicleID: veh_id },
        success: function (response) {
          data = JSON.parse(response);
          if (data.response_code == 0) {
            doFilter();
            Swal.fire({
              title: "Success!",
              text: data.response_message,
              type: "success",
              confirmButtonText: "Ok",
            });
          } else {
            Swal.fire({
              title: "Error!",
              text: data.response_message,
              type: "error",
              confirmButtonText: "Ok",
            });
          }
        },
      });
    }
  });
}

function confirmRegStatus(veh_id) {
  Swal.fire({
    title: "Confirm vehicle registration?",
    text: "Are you sure you want to activate this vehicle?",
    type: "question",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
  }).then((result) => {
    if (result.value) {
      $.ajax({
        type: "post",
        url: "ajax/ajax_confirm_vehicle.php",
        data: { vehicleID: veh_id },
        success: function (response) {
          data = JSON.parse(response);
          if (data.response_code == 0) {
            doFilter();
            Swal.fire({
              title: "Success!",
              text: data.response_message,
              type: "success",
              confirmButtonText: "Ok",
            });
          } else {
            Swal.fire({
              title: "Error!",
              text: data.response_message,
              type: "error",
              confirmButtonText: "Ok",
            });
          }
        },
      });
    }
  });
}

function declineVehicleReg(veh_id) {
  Swal.fire({
    title: "Decline vehicle registration?",
    text: "Are you sure you want to decline this vehicle?",
    type: "question",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
  }).then((result) => {
    if (result.value) {
      $.ajax({
        type: "post",
        url: "ajax/ajax_decline_vehicle.php",
        data: { vehicleID: veh_id },
        success: function (response) {
          data = JSON.parse(response);
          if (data.response_code == 0) {
            doFilter();
            Swal.fire({
              title: "Success!",
              text: data.response_message,
              type: "success",
              confirmButtonText: "Ok",
            });
          } else {
            Swal.fire({
              title: "Error!",
              text: data.response_message,
              type: "error",
              confirmButtonText: "Ok",
            });
          }
        },
      });
    }
  });
}

function viewVehicleInfo(veh_id) {
  $.ajax({
    type: "post",
    url: "ajax/ajax_view_vehicle_info.php",
    data: { vehicleID: veh_id },
    success: function (response) {
      data = JSON.parse(response);
      if (data.response_code == 0)
      {
        $("#owner").text(data.owner);
        //$("#email").text(data.email);
        //$("#driver_same_as_owner").text(data.driver_same_as_owner);
        $("#vin").text(data.vin);
        $("#flag-status").text(data.flag_status);
        $("#chassis-number").text(data.chassis_no);
        $("#plate-number").text(data.plate_no);
        $("#vehicle-make").text(data.veh_make);
        $("#vehicle-model").text(data.veh_model);
        $("#vehicle-color").text(data.veh_color);
        $("#vehicle-purpose").text(data.veh_purpose);
        $("#license-operator").text(data.license_operator);
        $("#vehicle-side-no").html(data.veh_side_no);
        if(data.veh_side_no.includes('FCT/'))
         {
            $('#generate-side-no').css('display','none');
         }
        else
        {
            $('#generate-side-no').css('display','block');
        }
      }
      else
      {
          Swal.fire({
            title: "",
            html: "Vehicle information loading error",
            timer: 0,
            allowOutsideClick: false,
            allowEscapeKey: false,
            onBeforeOpen: () => {
              Swal.showLoading();
            },
          });
      }
    },
  });
}

function generateSideNumber() {
  fireSwal(
    "Generate side number?",
    "Please click yes to generate a side number",
    "question",
    true,
    "#3085d6",
    "#d33",
    "Yes"
    // "No, I want to enter side number"
  ).then((result) => {
    if (result.value) {
      $.ajax({
        type: "post",
        url: "ajax/ajax_generate_side_no.php",
        data: { vin: $("#chassis-number").text() },//, email: $("#email").text()
        success: function (response) {
            //alert(response);
          data = JSON.parse(response);
          if (data.response_code == 0) {
            $("#vehicle-side-no").html(data.veh_side_no);
            Swal.fire({
              title: "Success!",
              text: data.response_message,
              type: "success",
              confirmButtonText: "Ok",
            });
            $('#generate-side-no').hide();
          }
          else
            {
                Swal.fire({
              title: "Error!",
              text: data.response_message,
              type: "error",
              confirmButtonText: "Ok",
            });
            }
        },
      });
    }
  });
}

/**
 * License operator actions
 * @param {*} operator__id
 */
function editLicenseOperator(operator__id) {
  console.clear();
  Swal.fire({
    title: "",
    html: "<b>Loading page, please wait...</b>",
    timer: 0,
    allowOutsideClick: false,
    allowEscapeKey: false,
    onBeforeOpen: () => {
      Swal.showLoading();
    },
  });
  $.ajax({
    type: "post",
    url: "ajax/ajax_edit_license_operator.php",
    data: { operatorID: operator__id },
    success: function (response) {
      Swal.close();
      data = JSON.parse(response);
      console.log(data);
      if (data.response_code == 0) {
        $("#operation").val("edit");
        $("#h-id").val(data.operator_id);
        $("#operator-name").val(data.name);
        $("#rc-no").val(data.rc_no);
        $("#email").val(data.email);
        $("#phone-no").val(data.phone_no);
        $("#council").val(data.council);
        $("#address").val(data.address);
        $("#license_no").val(data.license_no);
        $("#contact_info").val(data.contact_info);
        // data.raw_vehicle_cat.forEach((item, value) => {
        //   $(`#vehicle-${item}`).val()
        // });

        // $("#vehicle-101").prop("checked", data.vehicle_101);
        // $("#vehicle-102").prop("checked", data.vehicle_102);
        // $("#vehicle-104").prop("checked", data.vehicle_104);
      } else {
        $("#form1 .form-control").each(function (index, element) {
          element.value = "";
        });
      }
    },
  });
  console.clear();
}

console.clear();

function enableLicenseOperator(operator__id, operator_name) {
  fireSwal(
    "Enable License Operator",
    "Are you sure you want to enable license operator?",
    "question",
    true,
    "#3085d6",
    "#d33",
    "Yes",
    "No"
  ).then((result) => {
    if (result.value) {
      $.ajax({
        type: "POST",
        url: "ajax/enable_license_operator.php",
        data: {
          operatorID: operator__id,
        },
        success: function (response) 
        {
          doFilter();
          data = JSON.parse(response);
          if (data.response_code == 0) 
          {
            $(`#${operator__id}`).prop("checked", true);
            Swal.fire({
              title: "Success!",
              text: data.msg,
              type: "success",
              confirmButtonText: "Ok",
            });
          } 
          else if (data.response_code == 1) 
          {
                Swal.fire({
                  title: "Error",
                  text: data.msg,
                  type: "error",
                  confirmButtonText: "Ok",
                });
          }
        },
        error: function (err) {
          console.log(err);
        },
      });
    } 
    else 
    {
      $(`#${operator_name}`).prop("checked", false);
    }
  });
}

function disableLicenseOperator(operator__id, operator_name) {
  fireSwal(
    "Disable License Operator",
    "Are you sure you want to disable license operator?",
    "question",
    true,
    "#3085d6",
    "#d33",
    "Yes",
    "No"
  ).then((result) => {
    if (result.value) {
      $.ajax({
        type: "POST",
        url: "ajax/disable_license_operator.php",
        data: {
          operatorID: operator__id,
        },
        success: function (response)
          {
              doFilter();
              data = JSON.parse(response);
              if (data.response_code == 0)
              {
                $(`#${operator__id}`).prop("checked", false);
                Swal.fire({
                  title: "Success!",
                  text: data.msg,
                  type: "success",
                  confirmButtonText: "Ok",
                });
              } 
              else if (data.response_code == 1) 
              {
                Swal.fire({
                  title: "Error",
                  text: data.msg,
                  type: "error",
                  confirmButtonText: "Ok",
                });
              }
        },
        error: function (err) {
          console.log(err);
        },
      });
    } else {
      $(`#${operator_name}`).prop("checked", true);
    }
  });
}


////start of Tosin Toba's work 16-11-2020
function saveCentre(station_code) {
  Swal.fire({
    title: "",
    html: "<b>Loading page, please wait...</b>",
    timer: 0,
    allowOutsideClick: false,
    allowEscapeKey: false,
    onBeforeOpen: () => {
      Swal.showLoading();
    },
  });
  $.ajax({
    type: "post",
    url: "ajax/ajax_edit_centre.php",
    data: { stationCode: station_code },
    success: function (response) {
      data = JSON.parse(response);
      Swal.close();
      if (data.response_code == 0) {
        $("#station_code").val(data.station_code);
        $("#station_code").prop("disabled", true);

        $("#station_name").val(data.station_name);
      } else {
        $("#station_code").val("");
        $("#station_name").val("");
      }
    },
  });
}
function deleteCentre(station_code) {
  Swal.fire({
    title: "Confirm operation",
    text: "Are you sure you want to delete this centre?",
    type: "question",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
  }).then((result) => {
    if (result.value) {
      $.ajax({
        type: "post",
        url: "ajax/ajax_del_centre.php",
        data: { stationCode: station_code },
        success: function (response) {
          data = JSON.parse(response);
          if (data.response_code == 0) {
            doFilter();
            Swal.fire({
              title: "Success!",
              text: data.response_message,
              type: "success",
              confirmButtonText: "Ok",
            });
          } else {
            Swal.fire({
              title: "Error!",
              text: data.response_message,
              type: "error",
              confirmButtonText: "Ok",
            });
          }
        },
      });
    }
  });
}

/*Tosin starts here*/
function assignRider2Vehicle() {
  fireSwal(
    "Assign "+$('#name').val()+" ["+$('#rcn').val()+"] to "+$('#veh_side_no').val()+"?",
    "Please click yes to proceed with action",
    "question",
    true,
    "#3085d6",
    "#d33",
    "Yes"
  ).then((result) => {
      callPage('Vehicle.assignVehicle','vehicle_rider_assignment_list.php','box');
  });
}
function viewRiderInfo(rcn) {
  $.ajax({
    type: "post",
    url: "ajax/ajax_view_rider_info.php",
    data: { rcn: rcn },
    success: function (response) {
      data = JSON.parse(response);
      if (data.response_code == 0)
      {
          //alert('got here'+response);
        $("#title").text(data.title);
        $("#surname").text(data.surname);
        $("#firstname").text(data.firstname);
        $("#phone-no").text(data.phone_no);
        $("#nin").text(data.nin);
        $("#birth-country").text(data.birthcountry);
        $("#birth-state").text(data.birthstate);
        $("#birth-lga").text(data.birthlga);
        $("#residence-state").text(data.residence_state);
        $("#residence-town").text(data.residence_town);
        $("#address-residence").text(data.address_residence);
        $("#state-origin").text(data.state_origin);
        $("#home-origin").text(data.home_origin);
        $("#lga-origin").html(data.lga_origin);
        $("#license-operator").text(data.license_operator);
        $("#license-operator2").text(data.license_operator);
        $("#nok-surname").html(data.nok_surname);
        $("#nok-firstname").text(data.nok_firstname);
        $("#nok-middlename").text(data.nok_middlename);
        $("#license-no").text(data.license_no);
        $("#license-expiry-date").text(data.license_expiry_date);
        $("#gender").text(data.gender);
        $("#height").text(data.height);
        $("#native-lang").text(data.native_lang);
        $("#edu-qual").text(data.edu_qual);
        $("#religion").text(data.religion);
        $("#marital-status").text(data.marital_status);
        $("#rider-status").text(data.rider_status);
        if(data.status_int==1)
        {
            $("#rider-status").addClass('badge badge-success');
        }
        else
        {
            $("#rider-status").addClass('badge badge-danger');
        }
      }
      else
      {
          Swal.fire({
            title: "",
            html: "Rider information loading error",
            timer: 0,
            allowOutsideClick: false,
            allowEscapeKey: false,
            onBeforeOpen: () => {
              Swal.showLoading();
            },
          });
      }
    },
  });
}
function approveRider(rcn) {
  Swal.fire({
    title: "Confirm rider activation?",
    text: "Are you sure you want to activate this rider?",
    type: "question",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
  }).then((result) => {
    if (result.value) {
      $.ajax({
        type: "post",
        url: "ajax/ajax_approve_rider.php",
        data: { rcn: rcn },
        success: function (response) {
          data = JSON.parse(response);
          if (data.response_code == 0) {
            doFilter();
            Swal.fire({
              title: "Success!",
              text: data.response_message,
              type: "success",
              confirmButtonText: "Ok",
            });
          } else {
            Swal.fire({
              title: "Error!",
              text: data.response_message,
              type: "error",
              confirmButtonText: "Ok",
            });
          }
        },
      });
    }
  });
}
function disApproveRider(rcn) {
  Swal.fire({
    title: "Confirm rider deactivation?",
    text: "Are you sure you want to deactivate this rider?",
    type: "question",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
  }).then((result) => {
    if (result.value) {
      $.ajax({
        type: "post",
        url: "ajax/ajax_disapprove_rider.php",
        data: { rcn: rcn },
        success: function (response) {
          data = JSON.parse(response);
          if (data.response_code == 0) {
            doFilter();
            Swal.fire({
              title: "Success!",
              text: data.response_message,
              type: "success",
              confirmButtonText: "Ok",
            });
          } else {
            Swal.fire({
              title: "Error!",
              text: data.response_message,
              type: "error",
              confirmButtonText: "Ok",
            });
          }
        },
      });
    }
  });
}
$('#claim-veh').click(() => {
    deAssignVehicle($('#reason_id').val());
});
function deAssignVehicle(chassis) {
   Swal.fire({
    title: "Confirm vehicle un-assignment from current driver?",
    text: "Are you sure you want to claim this vehicle from its current rider?",
    type: "question",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
  }).then((result) => {
    if (result.value) {
      $.ajax({
        type: "post",
        url: "ajax/ajax_deassign_vehicle.php",
        data: { chassis: chassis,
                reason : $('#reason').val()},
        success: function (response) {
          data = JSON.parse(response);
          if (data.response_code == 0) {
              $('#close').click();
            doFilter();
            Swal.fire({
              title: "Success!",
              text: data.response_message,
              type: "success",
              confirmButtonText: "Ok",
            });
          } else {
            Swal.fire({
              title: "Error!",
              text: data.response_message,
              type: "error",
              confirmButtonText: "Ok",
            });
          }
        },
      });
    }
  });
}

function reValidateVehicle(chassis_no)
{
    $.ajax({
    type: "post",
    url: "ajax/ajax_revalidate_vehicle.php",
    data: { vid: chassis_no },
    success: function (response) {
      data = JSON.parse(response);
      if (data.response_code == 0)
      {
          Swal.fire({
              title: "Success!",
              text: data.message,
              type: "success",
              confirmButtonText: "Ok",
            });
      }
      else
      {
           Swal.fire({
              title: "Error!",
              text: data.message,
              type: "error",
              confirmButtonText: "Ok",
            });     
      }
    },
  });
}
function markRCCAsPrinted(d) {
  $.ajax({
    type: "post",
    url: "ajax/ajax_mark_rcc_print.php",
    data: {
      rcn: d,
    },
    success: function (response) {
      doFilter();
      data = JSON.parse(response);
      if (data.response_code == 0) {
        Swal.fire({
          title: "Print Farm Action",
          text: data.response_message,
          type: "success",
          confirmButtonText: "Ok",
        });
      } 
      else {
        Swal.fire({
          title: "Print Farm Action",
          text: data.response_message,
          type: "error",
          confirmButtonText: "Ok",
        });
      }
    },
    error: function (err) {
      console.log(err);
    },
  });
}
function resetUserPassword(username) {
  Swal.fire({
    title: "Confirm action",
    text: "Are you sure you want to reset the password of user: "+username+"?",
    type: "question",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
  }).then((result) => {
    if (result.value) {
        $.ajax({
          type: "post",
          url: "ajax/reset_password.php",
          data: {
            uname: username,
          },
          success: function (response) {
            doFilter();
            data = JSON.parse(response);
            if (data.response_code == 0) {
              Swal.fire({
                title: "Success!",
                text: data.msg,
                type: "success",
                confirmButtonText: "Ok",
              });
            } else if (data.response_code == 10) {
              Swal.fire({
                title: "Success!",
                text: data.msg,
                type: "success",
                confirmButtonText: "Ok",
              });
            }
          },
          error: function (err) {
            console.log(err);
          },
        });
      }
    });
}
function chkpassword(){
	if($("#userpassword").val() != $("#confirm_userpassword").val()){
		$("#display_message").html('Passwords do not match');
	}else{
		callPage('User.ChangePasswordLogon','home.php');//callPage(page, page_to_redirect, div_id, uploadFile=false)
	}
}
$('#change_password_logon').click(()=>
{
  if($("#new_password").val() != $("#confirm_password").val())
  {
		$("#display_message").removeClass('alert alert-success').addClass('alert alert-danger').html('Passwords do not match');
	}
  else
  {
		$.ajax({
      type: "post",
      url: "ajax/ajax_change_password_logon.php",
      data: {
        username: $('#userpassword').val(),
        old_password: $('#old_password').val(),
        new_password: $('#new_password').val(),
        confirm_password: $('#confirm_password').val(),
      },
      success: function (response) {
        //alert(response);
        data = JSON.parse(response);
        if (data.response_code == 0) {
          $("#display_message").removeClass('alert alert-danger').addClass('alert alert-success');
          $("#display_message").html('Successful');
          setTimeout(function(){
            window.location = 'login.php';
          },3000);
        } else  {
          $("#display_message").removeClass('alert alert-success').addClass('alert alert-warning');
          $("#display_message").html(data.msg);
        }
      },
      error: function (err) {
        console.log(err);
      },
    });
	}
  
});
